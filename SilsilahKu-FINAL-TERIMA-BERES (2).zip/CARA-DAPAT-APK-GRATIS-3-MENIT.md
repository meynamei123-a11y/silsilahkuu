
# CARA DAPAT APK SIAP INSTALL TANPA ANDROID STUDIO - 3 MENIT JADI

Kamu sudah punya project lengkap, tapi untuk jadi APK butuh Android SDK.
Aku sudah bikinin jalan pintas otomatis pakai GitHub (GRATIS, gak perlu install apa-apa).

### LANGKAH TERIMA BERES:

1. **Buat repo baru di GitHub** (github.com/new) - namanya SilsilahKu

2. **Upload project ini ke GitHub:**
   - Di halaman repo baru, pilih "uploading an existing file"
   - Drag & drop semua file dari zip ini
   - Commit

3. **Otomatis ke-build!**
   - Masuk ke tab "Actions" di GitHub repo kamu
   - Lihat workflow "Build SilsilahKu APK" lagi jalan
   - Tunggu 3-5 menit

4. **Download APK:**
   - Kalau sudah selesai (centang hijau), buka run-nya
   - Scroll bawah, ada bagian "Artifacts"
   - Download "SilsilahKu-APK-SiAP-Install"
   - Extract zip artifact, di dalamnya ada app-debug.apk -> INI YANG BISA LANGSUNG KAMU INSTALL DI HP!

### Cara Install di HP:
- Kirim app-debug.apk ke HP via WA/Telegram/Google Drive
- Buka file di HP, izinkan "Install dari sumber tidak dikenal"
- Install -> Jadi!

### Mau jadi APK Release untuk Play Store?
Artifact kedua "SilsilahKu-APK-Release" adalah versi release. Nanti tinggal di-sign.

---

Jika kamu punya Android Studio di laptop, cara manualnya tetap sama:
Build > Build APK(s) > Build APK(s)

Package: com.silsilahku.app
Version: 1.0.0
