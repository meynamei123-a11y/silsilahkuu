package com.silsilahku.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
