import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rootDir = path.resolve(__dirname, '..');
const publicDir = path.resolve(rootDir, 'public');
const masterZipPath = path.join(publicDir, 'SilsilahKu-Master-Project.zip');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

console.log('📦 Starting creation of SATU ZIP PROJECT LENGKAP (SilsilahKu-Master-Project.zip)...');

const pythonScript = `
import zipfile, os

zip_path = '${masterZipPath}'
if os.path.exists(zip_path):
    os.remove(zip_path)

include_files = [
    'config.xml',
    'capacitor.config.json',
    'AndroidManifest.xml',
    'build-apk.sh',
    'BUILD-APK.bat',
    'README-APK.md',
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'metadata.json',
    '.env.example',
    'index.html',
    '.gitignore'
]

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # 1. Root configuration files
    for file in include_files:
        if os.path.exists(file):
            zipf.write(file, file)
            print(f'Added root file: {file}')
            
    # Also add root AndroidManifest.xml if in android folder
    if os.path.exists('android/app/src/main/AndroidManifest.xml'):
        zipf.write('android/app/src/main/AndroidManifest.xml', 'AndroidManifest.xml')
        print('Added top-level AndroidManifest.xml')

    # 2. Add src folder
    for root, dirs, files in os.walk('src'):
        for file in files:
            full_path = os.path.join(root, file)
            zipf.write(full_path, full_path)
            
    # 3. Add public folder (excluding zips)
    for root, dirs, files in os.walk('public'):
        for file in files:
            full_path = os.path.join(root, file)
            if not file.endswith('.zip'):
                zipf.write(full_path, full_path)

    # 4. Add android folder
    if os.path.exists('android'):
        for root, dirs, files in os.walk('android'):
            for file in files:
                full_path = os.path.join(root, file)
                zipf.write(full_path, full_path)

    # 5. Add pre-compiled dist folder
    if os.path.exists('dist'):
        for root, dirs, files in os.walk('dist'):
            for file in files:
                full_path = os.path.join(root, file)
                if not file.endswith('.zip'):
                    zipf.write(full_path, full_path)
                    # Also include compiled assets at root level for flat HTML APK builders
                    flat_name = os.path.relpath(full_path, 'dist')
                    if not flat_name.startswith('dist'):
                        try:
                            zipf.write(full_path, flat_name)
                        except Exception:
                            pass

print('✅ Master ZIP generated successfully! File size:', os.path.getsize(zip_path), 'bytes')
`;

try {
  execSync(`python3 -c "${pythonScript.replace(/"/g, '\\"')}"`, { stdio: 'inherit' });
  console.log(`🎉 Master Project Package: ${masterZipPath}`);
} catch (error) {
  console.error('Packaging failed:', error);
  process.exit(1);
}
