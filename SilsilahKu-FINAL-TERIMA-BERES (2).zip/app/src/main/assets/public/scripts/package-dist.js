import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rootDir = path.resolve(__dirname, '..');
const distDir = path.resolve(rootDir, 'dist');
const publicDir = path.resolve(rootDir, 'public');
const outZip = path.join(publicDir, 'SilsilahKu-App-Ready.zip');

if (!fs.existsSync(distDir)) {
  console.error('❌ dist folder does not exist. Run npm run build first.');
  process.exit(1);
}

const pythonScript = `
import zipfile, os

dist_dir = '${distDir}'
zip_path = '${outZip}'

if os.path.exists(zip_path):
    os.remove(zip_path)

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(dist_dir):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, dist_dir)
            zipf.write(file_path, arcname)
            print(f"Added to Dist App: {arcname}")

print(f"✅ Success! Dist App Archive generated at: {zip_path} ({os.path.getsize(zip_path)} bytes)")
`;

try {
  execSync(`python3 -c "${pythonScript.replace(/"/g, '\\"')}"`, {
    stdio: 'inherit',
    cwd: rootDir,
  });
} catch (e) {
  console.error('Packaging dist error:', e);
}
