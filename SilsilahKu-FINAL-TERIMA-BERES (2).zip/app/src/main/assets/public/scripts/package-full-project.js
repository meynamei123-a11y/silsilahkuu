import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rootDir = path.resolve(__dirname, '..');
const publicDir = path.resolve(rootDir, 'public');
const targetZip = path.join(publicDir, 'SilsilahKu-Capacitor-Android-FullProject.zip');
const masterZip = path.join(publicDir, 'SilsilahKu-Master-Project.zip');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

console.log('📦 Starting FULL PROJECT packaging for Capacitor Android Native Pipeline...');

const pythonScript = `
import zipfile, os, json

target_zip = '${targetZip}'
master_zip = '${masterZip}'

for z in [target_zip, master_zip]:
    if os.path.exists(z):
        try:
            os.remove(z)
        except Exception:
            pass

root_files = [
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'capacitor.config.ts',
    'capacitor.config.json',
    'config.xml',
    'index.html',
    'metadata.json',
    '.env.example',
    '.gitignore',
    'build-apk.sh',
    'BUILD-APK.bat',
    'README-APK.md'
]

folders_to_include = ['src', 'public', 'android', 'scripts']

# Build ZIP
total_files = 0
total_uncompressed = 0
file_list = []

with zipfile.ZipFile(target_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
    for rf in root_files:
        if os.path.exists(rf):
            zipf.write(rf, rf)
            total_files += 1
            sz = os.path.getsize(rf)
            total_uncompressed += sz
            file_list.append(rf)

    for folder in folders_to_include:
        if os.path.exists(folder):
            for root, dirs, files in os.walk(folder):
                for file in files:
                    full_path = os.path.join(root, file)
                    # Skip existing zips inside public or build artifacts
                    if file.endswith('.zip') or '.git' in full_path or 'node_modules' in full_path:
                        continue
                    zipf.write(full_path, full_path)
                    total_files += 1
                    sz = os.path.getsize(full_path)
                    total_uncompressed += sz
                    file_list.append(full_path)

# Also copy to master_zip
import shutil
shutil.copyfile(target_zip, master_zip)

zip_size = os.path.getsize(target_zip)

print("--- AUDIT RESULTS ---")
print(f"Total Files in ZIP: {total_files}")
print(f"Compressed ZIP Size: {zip_size} bytes ({zip_size / (1024*1024):.2f} MB)")
print(f"Uncompressed Size: {total_uncompressed} bytes ({total_uncompressed / (1024*1024):.2f} MB)")
`;

try {
  execSync(`python3 -c "${pythonScript.replace(/"/g, '\\"')}"`, { stdio: 'inherit' });
  console.log(`✅ Success! Archive generated at: ${targetZip}`);
} catch (err) {
  console.error('Packaging script failed:', err);
  process.exit(1);
}
