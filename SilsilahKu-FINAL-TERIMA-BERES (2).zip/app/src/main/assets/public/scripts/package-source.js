import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

/**
 * Script function to package all source files into SilsilahKu-Final-Source.zip
 */
export function packageProjectSource() {
  const rootDir = process.cwd();
  const publicDir = path.join(rootDir, 'public');
  const zipPath = path.join(publicDir, 'SilsilahKu-Final-Source.zip');

  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  console.log('📦 Starting project source packaging...');

  const pythonScript = `
import zipfile, os

zip_path = '${zipPath}'
if os.path.exists(zip_path):
    os.remove(zip_path)

include_files = [
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'metadata.json',
    '.env.example',
    'index.html',
    '.gitignore',
    'config.xml',
    'capacitor.config.json',
    'build-apk.sh',
    'BUILD-APK.bat',
    'README-APK.md'
]

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for file in include_files:
        if os.path.exists(file):
            zipf.write(file, file)
            print(f'Added file: {file}')
    
    for folder in ['src', 'public', 'android']:
        if os.path.exists(folder):
            for root, dirs, files in os.walk(folder):
                for file in files:
                    full_path = os.path.join(root, file)
                    if 'SilsilahKu-Final-Source.zip' in full_path or 'node_modules' in full_path or '.git' in full_path or 'dist' in full_path:
                        continue
                    zipf.write(full_path, full_path)
                    print(f'Added: {full_path}')

print('Packaging complete. Size:', os.path.getsize(zip_path), 'bytes')
`;

  try {
    execSync(`python3 -c "${pythonScript.replace(/"/g, '\\"')}"`, { stdio: 'inherit' });
    console.log(`✅ Success! Archive generated at: ${zipPath}`);
    return zipPath;
  } catch (error) {
    console.error('Packaging failed:', error);
    throw error;
  }
}

// Run if called directly
if (import.meta.url.endsWith(process.argv[1]) || process.argv[1]?.includes('package-source')) {
  packageProjectSource();
}
