export type AppMode = 'preview' | 'editor';

export type LanguageCode = 'id' | 'en' | 'ar' | 'zh' | 'ru';

export type CardSize = 'kecil' | 'sedang' | 'besar';
export type CardColorTheme = 'paper' | 'slate' | 'clean' | 'emerald' | 'amber';
export type BlurLevel = 0 | 5 | 10 | 15 | 20;
export type FontFamilyType = 'plus-jakarta' | 'playfair' | 'cinzel' | 'lora' | 'typewriter' | 'amiri';
export type FontSizePreset = 'kecil' | 'sedang' | 'besar';

export type ComponentType = 
  | 'vertical_card'       // Kolom memanjang vertikal di halaman utama
  | 'button'              // Tombol aksi umum
  | 'text_block'          // Blok teks judul / paragraf / kutipan
  | 'heading'             // Judul teks besar
  | 'card_item'           // Kartu konten umum
  | 'image'               // Gambar / Avatar
  | 'icon'                // Ikon grafis
  | 'input_field'         // Input formulir
  | 'container'           // Wadah / Panel / Box
  | 'tab_bar'             // Tab navigasi
  | 'dropdown'            // Menu dropdown
  | 'search_bar'          // Kolom pencarian
  | 'custom_component'    // Komponen kustom HTML/CSS
  | 'badge'               // Label penanda
  | 'separator';          // Garis pemisah

export type ComponentActionType = 
  | 'navigate'            // Berpindah ke targetPageId
  | 'none'                // Tidak ada fungsi (tombol tetap tampil, fungsi dilepas)
  | 'toast'               // Memunculkan notifikasi kustom
  | 'edit_profile'        // Membuka modal/halaman edit profil
  | 'open_person_detail'  // Membuka popup biodata tokoh tertentu
  | 'open_url'            // Membuka link eksternal
  | 'back'                // Kembali ke halaman sebelumnya
  | 'open_popup'          // Menampilkan popup modal kustom
  | 'custom_js';          // Menjalankan kode JavaScript kustom

export type ComponentPosition = 'left' | 'center' | 'right' | 'justify' | 'top_right' | 'top_left' | 'default';

export interface ElementStyleConfig {
  width?: string;                 // 'auto', '100%', '50%', '320px', etc.
  height?: string;                // 'auto', '48px', '120px', etc.
  marginTop?: number;             // px (0-64)
  marginBottom?: number;          // px (0-64)
  marginLeft?: number;            // px (0-64)
  marginRight?: number;           // px (0-64)
  paddingTop?: number;            // px (0-64)
  paddingBottom?: number;         // px (0-64)
  paddingLeft?: number;           // px (0-64)
  paddingRight?: number;          // px (0-64)
  textAlign?: 'left' | 'center' | 'right' | 'justify';
  fontFamily?: FontFamilyType;
  fontSize?: number;              // px (10-36)
  fontWeight?: 'normal' | 'medium' | 'semibold' | 'bold' | 'extrabold';
  textColor?: string;             // Hex (#ffffff)
  backgroundColor?: string;       // Hex (#1c1917)
  transparency?: number;          // 0 - 100%
  borderWidth?: number;           // 0 - 8px
  borderColor?: string;           // Hex (#b45309)
  borderStyle?: 'solid' | 'dashed' | 'dotted' | 'none';
  borderRadius?: number;          // 0 - 40px
  shadow?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | 'glow';
  zIndex?: number;                // 0 - 50
  hideOnMobile?: boolean;         // Responsif: Sembunyikan di layar kecil
  fullWidthMobile?: boolean;      // Responsif: 100% lebar di mobile
}

export interface UIComponent {
  id: string;
  name: string;
  subtitle?: string;
  description?: string;
  placeholder?: string;
  type: ComponentType;
  icon?: string;                  // Nama icon (e.g., 'Compass', 'Network', 'User', etc.)
  imageUrl?: string;              // URL gambar jika type === 'image'
  position: ComponentPosition;
  order: number;
  size: CardSize;
  style?: ElementStyleConfig;     // Konfigurasi visual detail lengkap
  color?: string;                 // Hex warna teks/aksen
  backgroundColor?: string;       // Hex background kustom
  borderColor?: string;
  fontFamily?: FontFamilyType;
  fontSize?: number;
  transparency?: number;          // 0 - 100
  isVisible: boolean;             // Tampil / sembunyi
  isEnabled: boolean;             // Aktif / nonaktif fungsi
  actionType: ComponentActionType;
  targetPageId?: string;          // ID halaman tujuan jika actionType === 'navigate'
  actionPayload?: string;         // Pesan notifikasi, parameter, atau URL
  customJsCode?: string;          // Script JS kustom jika actionType === 'custom_js'
  targetPersonId?: string;        // ID tokoh jika actionType === 'open_person_detail'
  htmlCode?: string;              // Custom HTML code jika type === 'custom_component'
  cssCode?: string;               // Custom CSS code
  jsCode?: string;                // Custom JS code
  isGlobalDependency?: boolean;   // Penanda kode global dependency
  metadata?: Record<string, any>; // Data tambahan dinamis
}

export type PageLayoutType = 
  | '5_vertical_cards'            // 5 kolom memanjang satu layar penuh
  | 'flow_list'                   // Daftar vertikal dengan scrolling
  | 'grid'                        // Grid 2/3 kolom responsif
  | 'detail_content'              // Halaman konten teks & komponen
  | 'custom_canvas';              // Halaman kanvas bebas

export interface AppPage {
  id: string;
  title: string;
  slug: string;
  description: string;
  layoutType: PageLayoutType;
  isHomePage?: boolean;
  components: UIComponent[];
  customBackground?: string;
  customBlur?: BlurLevel;
  parentPageId?: string | null;   // Untuk hierarki pohon halaman (misal Adam -> Anak Adam)
  customStyles?: {
    containerWidth?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
    backgroundColor?: string;
    textColor?: string;
    fontFamily?: FontFamilyType;
    padding?: number;
  };
  htmlCode?: string;
  cssCode?: string;
  jsCode?: string;
  isGlobalDependency?: boolean;
}

export interface UserProfile {
  name: string;
  title: string;
  bio: string;
  photoUrl: string;
  familyBranch: string;
  generationTitle: string;
  location: string;
  lastUpdated: string;
  position: 'top_right' | 'top_left' | 'inside_menu' | 'hidden';
  size: 'kecil' | 'sedang' | 'besar';
  isVisible: boolean;
  colorTheme: string;
  clickAction: ComponentActionType;
  targetPageId?: string;
}

export interface AppLockConfig {
  isEnabled: boolean;
  passcode: string;
  hint?: string;
}

// 7. Pengaturan Tampilan Silsilah
export interface GenealogyDisplayConfig {
  orientation: 'vertical' | 'horizontal' | 'outline_tree';
  maxDepth: number | 'all';               // 1, 2, 3, 4, 5, atau 'all'
  showSpouse: boolean;
  showChildrenCount: boolean;
  showYears: boolean;
  showPhoto: boolean;
  showRelation: boolean;
  nameSize: 'kecil' | 'sedang' | 'besar';
  nodeSize: 'compact' | 'normal' | 'spacious';
  generationSpacing: number;              // Jarak antar generasi dalam px (16-64)
  branchSpacing: number;                  // Jarak antar cabang dalam px (8-48)
  defaultExpandedLevel: number;           // Jumlah generasi awal yang terbuka (1-5)
  lineColor: string;                      // Hex warna garis hubungan
  nodeBgColor?: string;                   // Hex background node
  nodeBorderColor?: string;               // Hex border node
  textColor?: string;                     // Hex warna teks
  backgroundColor?: string;               // Hex background
  transparency: number;                   // 0-100
  fontFamily: FontFamilyType;
  fontSize: number;
}

// 11. Database Dinamis: Custom Fields
export interface CustomPersonField {
  id: string;
  key: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'textarea' | 'select' | 'boolean';
  options?: string[];
  category: 'general' | 'historical' | 'source' | 'other';
  order: number;
  isVisible: boolean;
  isReadOnly: boolean;
  placeholder?: string;
}

// 13. Preset / Default Buatan Sendiri
export interface AppPreset {
  id: string;
  name: string;
  description: string;
  isBuiltIn: boolean;
  createdAt: string;
  globalTheme: RootApkConfig['globalTheme'];
  genealogyConfig: GenealogyDisplayConfig;
}

export interface RootApkConfig {
  appTitle: string;
  appSubtitle: string;
  appIcon: string;
  version: string;
  language: LanguageCode;
  homePageId: string;
  appLock: AppLockConfig;
  globalTheme: {
    primaryColor: string;
    primaryColorName: string;
    cardColorTheme: CardColorTheme;
    cardOpacity: number;
    cardSize: CardSize;
    fontFamily: FontFamilyType;
    fontSizePreset: FontSizePreset;
    fontSizeValue: number;
    wallpaper: string;
    wallpaperName: string;
    blur: BlurLevel;
    customTextColor?: string;
    customBgColor?: string;
    customBorderColor?: string;
  };
  genealogyDisplay: GenealogyDisplayConfig;
  customPersonFields: CustomPersonField[];
  customPresets: AppPreset[];
  pages: AppPage[];
  profile: UserProfile;
}

// Data Anggota Silsilah Lengkap
export interface FamilyMember {
  id: string;
  name: string;
  altNames?: string[];                    // Nama alternatif / julukan
  title?: string;                         // Gelar / peran kehormatan
  gender: 'Laki-laki' | 'Perempuan';
  generation: number;
  relation: string;
  birthYear: string;
  deathYear: string | null;
  birthPlace: string;
  residence: string;
  lineageBranch: 'Patrilineal (Garis Ayah)' | 'Matrilineal (Garis Ibu)';
  notes: string;
  biography?: string;                     // Biografi & cerita sejarah
  sources?: string[];                     // Sumber pustaka / naskah
  references?: string[];                  // Referensi catatan
  fatherId: string | null;
  motherId: string | null;
  spouseId: string | null;
  spouseIds?: string[];                   // Pasangan ganda jika ada
  childrenIds?: string[];                 // Relasi otomatis anak
  occupation?: string;
  photoUrl?: string;
  customFieldValues?: Record<string, any>; // Field dinamis kustom
}
