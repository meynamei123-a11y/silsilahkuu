import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ChevronDown, ChevronRight, Eye, Sliders } from 'lucide-react';
import { GenealogyTreeOverview } from '../components/GenealogyTreeOverview';
import { DEFAULT_GENEALOGY_CONFIG } from '../data/initialData';

export const GenealogyView: React.FC = () => {
  const {
    familyMembers,
    rootConfig,
    updateRootConfig,
    showToast,
    isFocusMode,
    toggleFocusMode,
    t,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'tree' | 'info' | 'generations'>('tree');
  const [openCanvasSubmenu, setOpenCanvasSubmenu] = useState<string | null>(null);
  const [isCanvasDropdownOpen, setIsCanvasDropdownOpen] = useState(false);
  const [selectedGen, setSelectedGen] = useState<number | 'all'>('all');

  const config = {
    ...DEFAULT_GENEALOGY_CONFIG,
    ...(rootConfig.genealogyDisplay || {}),
  };

  const defaultRootMember = familyMembers.find((m) => m.id === 'yakub') || familyMembers[0];

  const generations = [
    { gen: 1, title: 'Generasi I (Leluhur Pendahulu)', era: '1890 - 1974' },
    { gen: 2, title: 'Generasi II (Perintis Kemerdekaan)', era: '1920 - 2015' },
    { gen: 3, title: 'Generasi III (Pembangunan Bangsa)', era: '1955 - Sekarang' },
    { gen: 4, title: 'Generasi IV (Generasi Pengarsip)', era: '1985 - Sekarang' },
    { gen: 5, title: 'Generasi V (Tunas Muda Penerus)', era: '2015 - Sekarang' },
  ];

  const filteredMembers =
    selectedGen === 'all'
      ? familyMembers
      : familyMembers.filter((m) => m.generation === selectedGen);

  const toggleCanvasSubmenu = (key: string) => {
    setOpenCanvasSubmenu((prev) => (prev === key ? null : key));
  };

  return (
    <div className="w-full h-full flex flex-col overflow-hidden relative text-stone-100 select-none bg-stone-950">
      {/* 1. SINGLE ULTRA-THIN TOP BAR (MAX 38px HEIGHT - ONLY WHEN NOT IN FOCUS MODE) */}
      {!isFocusMode && (
        <nav
          className="w-full h-9 bg-stone-950/98 border-b border-stone-800/80 px-2 sm:px-4 z-40 relative flex items-center justify-between gap-2 shrink-0 shadow-md text-xs"
          aria-label="Navigasi Silsilah"
        >
          {/* Left: SINGLE Person Name Indicator (NO Duplication!) */}
          {defaultRootMember && (
            <div className="flex items-center gap-1.5 font-bold text-stone-200 shrink-0 truncate max-w-[140px] sm:max-w-[220px]">
              <span className="text-[10px] font-mono text-amber-400 font-bold px-1.5 py-0.2 bg-amber-950/70 border border-amber-500/40 rounded">
                G{defaultRootMember.generation}
              </span>
              <span className="text-stone-100 truncate">{defaultRootMember.name}</span>
            </div>
          )}

          {/* Center: Text-Only Tabs (Info Profil | Canvas Pohon ⌄ | Statistik & Generasi) */}
          <div className="flex items-center gap-3 sm:gap-5 text-xs font-bold shrink-0">
            {/* Info Profil */}
            <button
              type="button"
              onClick={() => {
                setActiveTab((prev) => (prev === 'info' ? 'tree' : 'info'));
                setIsCanvasDropdownOpen(false);
              }}
              className={`pb-0.5 border-b-2 transition-all cursor-pointer ${
                activeTab === 'info'
                  ? 'border-amber-400 text-amber-300 font-extrabold'
                  : 'border-transparent text-stone-400 hover:text-stone-200'
              }`}
            >
              Info Profil
            </button>

            {/* Canvas Pohon (Text Dropdown Trigger) */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('tree');
                  setIsCanvasDropdownOpen((prev) => !prev);
                }}
                className={`pb-0.5 border-b-2 transition-all cursor-pointer flex items-center gap-0.5 ${
                  activeTab === 'tree'
                    ? 'border-amber-400 text-amber-300 font-extrabold'
                    : 'border-transparent text-stone-400 hover:text-stone-200'
                }`}
              >
                <span>Canvas Pohon</span>
                <ChevronDown
                  className={`w-3 h-3 transition-transform ${
                    isCanvasDropdownOpen ? 'rotate-180 text-amber-400' : 'text-stone-500'
                  }`}
                />
              </button>

              {/* Dropdown Options for Canvas Pohon */}
              {isCanvasDropdownOpen && (
                <div
                  className="absolute left-0 top-full mt-1 z-50 w-60 sm:w-64 bg-stone-950/98 border border-amber-500/40 rounded-xl shadow-2xl p-2 backdrop-blur-xl animate-in fade-in duration-150 space-y-1 text-xs"
                  style={{ maxHeight: '70vh', overflowY: 'auto' }}
                >
                  <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400 px-2 py-1 border-b border-stone-800 mb-1 flex items-center justify-between">
                    <span>Pengaturan Canvas</span>
                    <button
                      type="button"
                      onClick={() => setIsCanvasDropdownOpen(false)}
                      className="text-stone-500 hover:text-stone-300 text-[10px]"
                    >
                      ×
                    </button>
                  </div>

                  {/* Submenu: Tampilan Pohon */}
                  <div>
                    <button
                      type="button"
                      onClick={() => toggleCanvasSubmenu('tampilan_pohon')}
                      className="w-full text-left py-1 px-2 rounded-lg hover:bg-stone-900 text-stone-200 font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>Tampilan Pohon</span>
                      {openCanvasSubmenu === 'tampilan_pohon' ? (
                        <ChevronDown className="w-3 h-3 text-amber-400" />
                      ) : (
                        <ChevronRight className="w-3 h-3 text-stone-500" />
                      )}
                    </button>

                    {openCanvasSubmenu === 'tampilan_pohon' && (
                      <div className="ml-2 pl-2 border-l border-amber-500/30 my-1 space-y-0.5">
                        {[
                          { id: 'vertical', label: '⬇ Vertikal (Bawah)' },
                          { id: 'horizontal', label: '➡ Horisontal (Samping)' },
                          { id: 'outline_tree', label: '├── Pohon Naskah (ASCII)' },
                        ].map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => {
                              updateRootConfig({
                                genealogyDisplay: { ...config, orientation: item.id as any },
                              });
                              showToast(`Orientasi: ${item.label}`);
                            }}
                            className={`w-full text-left px-2 py-1 rounded-md text-xs font-semibold cursor-pointer ${
                              config.orientation === item.id
                                ? 'bg-amber-950/60 text-amber-300 font-bold border border-amber-500/40'
                                : 'text-stone-300 hover:bg-stone-850'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Submenu: Generasi */}
                  <div>
                    <button
                      type="button"
                      onClick={() => toggleCanvasSubmenu('generasi')}
                      className="w-full text-left py-1 px-2 rounded-lg hover:bg-stone-900 text-stone-200 font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>Generasi (Kedalaman)</span>
                      {openCanvasSubmenu === 'generasi' ? (
                        <ChevronDown className="w-3 h-3 text-amber-400" />
                      ) : (
                        <ChevronRight className="w-3 h-3 text-stone-500" />
                      )}
                    </button>

                    {openCanvasSubmenu === 'generasi' && (
                      <div className="ml-2 pl-2 border-l border-amber-500/30 my-1 flex flex-wrap gap-1">
                        {['1', '2', '3', '4', '5', 'all'].map((depth) => (
                          <button
                            key={depth}
                            type="button"
                            onClick={() => {
                              updateRootConfig({
                                genealogyDisplay: {
                                  ...config,
                                  maxDepth: depth === 'all' ? 'all' : Number(depth),
                                },
                              });
                              showToast(`Kedalaman: ${depth === 'all' ? 'Semua' : `${depth} Gen`}`);
                            }}
                            className={`px-1.5 py-0.5 rounded text-[11px] font-semibold cursor-pointer border ${
                              String(config.maxDepth) === depth
                                ? 'bg-amber-600 text-stone-950 font-bold border-amber-400'
                                : 'bg-stone-900 text-stone-300 border-stone-800'
                            }`}
                          >
                            {depth === 'all' ? 'Semua' : `${depth} Gen`}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Submenu: Ukuran Node */}
                  <div>
                    <button
                      type="button"
                      onClick={() => toggleCanvasSubmenu('ukuran_node')}
                      className="w-full text-left py-1 px-2 rounded-lg hover:bg-stone-900 text-stone-200 font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>Ukuran Node</span>
                      {openCanvasSubmenu === 'ukuran_node' ? (
                        <ChevronDown className="w-3 h-3 text-amber-400" />
                      ) : (
                        <ChevronRight className="w-3 h-3 text-stone-500" />
                      )}
                    </button>

                    {openCanvasSubmenu === 'ukuran_node' && (
                      <div className="ml-2 pl-2 border-l border-amber-500/30 my-1 flex gap-1">
                        {['compact', 'normal', 'spacious'].map((sz) => (
                          <button
                            key={sz}
                            type="button"
                            onClick={() => {
                              updateRootConfig({
                                genealogyDisplay: { ...config, nodeSize: sz as any },
                              });
                            }}
                            className={`px-2 py-0.5 rounded text-[11px] font-semibold cursor-pointer border ${
                              config.nodeSize === sz
                                ? 'bg-amber-600 text-stone-950 font-bold border-amber-400'
                                : 'bg-stone-900 text-stone-300 border-stone-800'
                            }`}
                          >
                            {sz}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Statistik & Generasi */}
            <button
              type="button"
              onClick={() => {
                setActiveTab('generations');
                setIsCanvasDropdownOpen(false);
              }}
              className={`pb-0.5 border-b-2 transition-all cursor-pointer ${
                activeTab === 'generations'
                  ? 'border-amber-400 text-amber-300 font-extrabold'
                  : 'border-transparent text-stone-400 hover:text-stone-200'
              }`}
            >
              Statistik & Generasi
            </button>
          </div>

          {/* Right: FOCUS MODE TOGGLE EYE ICON 👁️ */}
          <button
            type="button"
            onClick={toggleFocusMode}
            className="p-1 rounded-lg text-amber-400 hover:text-amber-300 hover:bg-stone-900 transition-colors cursor-pointer shrink-0"
            title="Aktifkan Mode Fokus (Sembunyikan seluruh UI)"
          >
            <Eye className="w-4 h-4" />
          </button>
        </nav>
      )}

      {/* FOCUS MODE FLOATING EXIT EYE BUTTON 👁️ (Visible ONLY in Focus Mode) */}
      {isFocusMode && (
        <button
          type="button"
          onClick={toggleFocusMode}
          className="fixed top-3 right-3 z-50 p-2 rounded-full bg-stone-900/90 border border-amber-500/50 text-amber-400 hover:scale-110 shadow-2xl backdrop-blur-md cursor-pointer transition-all"
          title="Keluar dari Mode Fokus"
        >
          <Eye className="w-5 h-5" />
        </button>
      )}

      {/* INFO PROFIL SUMMARY DRAWER (Non-overlapping minimal panel) */}
      {!isFocusMode && activeTab === 'info' && defaultRootMember && (
        <div className="w-full bg-stone-950/95 border-b border-stone-800 px-4 py-2.5 text-xs animate-in slide-in-from-top duration-150 z-30 shadow-xl flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 font-bold flex items-center justify-center shrink-0">
              G{defaultRootMember.generation}
            </div>
            <div>
              <span className="font-extrabold text-stone-100 text-xs block">
                {defaultRootMember.name}
              </span>
              <p className="text-[10px] text-stone-400">
                Lahir {defaultRootMember.birthYear || '-'} · {defaultRootMember.gender} · {defaultRootMember.relation}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveTab('tree')}
            className="px-3 py-1 rounded-lg bg-amber-600 text-stone-950 font-bold cursor-pointer text-xs"
          >
            Tutup Info ×
          </button>
        </div>
      )}

      {/* MAIN VIEWPORT CANVAS AREA (Priority 100% Canvas Space) */}
      <div className="flex-1 w-full h-full overflow-hidden relative">
        {activeTab === 'generations' && !isFocusMode ? (
          /* STATISTIK & GENERASI VIEW */
          <div className="w-full h-full overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div className="p-3 rounded-xl bg-stone-900/80 border border-stone-800 text-center">
                <span className="text-xl font-bold text-amber-400 font-mono">5</span>
                <span className="text-[11px] text-stone-400 block mt-0.5">Generasi</span>
              </div>
              <div className="p-3 rounded-xl bg-stone-900/80 border border-stone-800 text-center">
                <span className="text-xl font-bold text-stone-100 font-mono">
                  {familyMembers.length}
                </span>
                <span className="text-[11px] text-stone-400 block mt-0.5">Total Tokoh</span>
              </div>
              <div className="p-3 rounded-xl bg-stone-900/80 border border-stone-800 text-center">
                <span className="text-xl font-bold text-stone-100 font-mono">134</span>
                <span className="text-[11px] text-stone-400 block mt-0.5">Tahun Rentang</span>
              </div>
              <div className="p-3 rounded-xl bg-stone-900/80 border border-stone-800 text-center">
                <span className="text-xl font-bold text-emerald-400 font-mono">100%</span>
                <span className="text-[11px] text-stone-400 block mt-0.5">Terverifikasi</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-stone-400">
                Pilih Generasi:
              </span>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setSelectedGen('all')}
                  className={`px-3 py-1 rounded-xl text-xs font-semibold cursor-pointer ${
                    selectedGen === 'all'
                      ? 'bg-amber-600 text-stone-950 font-bold'
                      : 'bg-stone-900 text-stone-300 border border-stone-800'
                  }`}
                >
                  Semua ({familyMembers.length})
                </button>
                {generations.map((g) => {
                  const count = familyMembers.filter((m) => m.generation === g.gen).length;
                  return (
                    <button
                      key={g.gen}
                      type="button"
                      onClick={() => setSelectedGen(g.gen)}
                      className={`px-2.5 py-1 rounded-xl text-xs font-semibold cursor-pointer ${
                        selectedGen === g.gen
                          ? 'bg-amber-600 text-stone-950 font-bold'
                          : 'bg-stone-900 text-stone-300 border border-stone-800'
                      }`}
                    >
                      Gen {g.gen} ({count})
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {filteredMembers.map((member) => (
                <div
                  key={member.id}
                  className="p-3 rounded-xl bg-stone-900/70 border border-stone-800 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 font-bold text-xs flex items-center justify-center shrink-0">
                      G{member.generation}
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="font-bold text-stone-100 text-xs block truncate">
                        {member.name}
                      </span>
                      <p className="text-[11px] text-stone-400 truncate mt-0.5">
                        {member.birthYear} — {member.deathYear ? member.deathYear : 'Kini'}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* CANVAS POHON (Maximum Viewport Space) */
          <GenealogyTreeOverview />
        )}
      </div>
    </div>
  );
};
