import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Camera,
  Edit3,
  Save,
  X,
  User,
  MapPin,
  Calendar,
  Layers,
  Sparkles,
  Sliders,
  Palette,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  KeyRound,
  ShieldCheck,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';

export const ProfileView: React.FC = () => {
  const {
    profile,
    updateProfile,
    setAvatarFromFile,
    goBack,
    rootConfig,
    isUnlocked,
    isAppLocked,
    lockNow,
    openPasscodePrompt,
    enableAppLock,
    disableAppLock,
    changePasscode,
    showToast,
  } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: profile.name,
    title: profile.title,
    bio: profile.bio,
    familyBranch: profile.familyBranch,
    generationTitle: profile.generationTitle,
    location: profile.location,
    position: profile.position,
    size: profile.size,
    isVisible: profile.isVisible,
    colorTheme: profile.colorTheme || '#b45309',
    clickAction: profile.clickAction,
  });

  // App Lock Form States
  const [isLockSectionOpen, setIsLockSectionOpen] = useState(true);
  const [lockSubView, setLockSubView] = useState<'idle' | 'activate' | 'change' | 'disable'>('idle');
  const [currentCodeInput, setCurrentCodeInput] = useState('');
  const [newCodeInput, setNewCodeInput] = useState('');
  const [confirmCodeInput, setConfirmCodeInput] = useState('');
  const [hintInput, setHintInput] = useState(rootConfig.appLock?.hint || '');
  const [showCode, setShowCode] = useState(false);
  const [lockError, setLockError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleOpenPicker = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploading(true);
      await setAvatarFromFile(file);
      setIsUploading(false);
    }
    e.target.value = '';
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      name: profile.name,
      title: profile.title,
      bio: profile.bio,
      familyBranch: profile.familyBranch,
      generationTitle: profile.generationTitle,
      location: profile.location,
      position: profile.position,
      size: profile.size,
      isVisible: profile.isVisible,
      colorTheme: profile.colorTheme || '#b45309',
      clickAction: profile.clickAction,
    });
    setIsEditing(false);
  };

  const handleActivateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLockError(null);
    if (!newCodeInput.trim()) {
      setLockError('Kode sandi tidak boleh kosong!');
      return;
    }
    if (newCodeInput !== confirmCodeInput) {
      setLockError('Konfirmasi sandi tidak sesuai!');
      return;
    }
    enableAppLock(newCodeInput.trim(), hintInput.trim());
    setLockSubView('idle');
    setNewCodeInput('');
    setConfirmCodeInput('');
  };

  const handleChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLockError(null);
    if (!currentCodeInput.trim()) {
      setLockError('Masukkan kode sandi saat ini!');
      return;
    }
    if (!newCodeInput.trim()) {
      setLockError('Kode sandi baru tidak boleh kosong!');
      return;
    }
    if (newCodeInput !== confirmCodeInput) {
      setLockError('Konfirmasi sandi baru tidak cocok!');
      return;
    }
    const success = changePasscode(currentCodeInput.trim(), newCodeInput.trim());
    if (success) {
      setLockSubView('idle');
      setCurrentCodeInput('');
      setNewCodeInput('');
      setConfirmCodeInput('');
    } else {
      setLockError('Kode sandi saat ini salah!');
    }
  };

  const handleDisableSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLockError(null);
    if (!currentCodeInput.trim()) {
      setLockError('Masukkan kode sandi saat ini!');
      return;
    }
    const success = disableAppLock(currentCodeInput.trim());
    if (success) {
      setLockSubView('idle');
      setCurrentCodeInput('');
    } else {
      setLockError('Kode sandi salah! Gagal menonaktifkan kunci.');
    }
  };

  return (
    <div className="w-full h-full overflow-y-auto p-3 sm:p-5 flex flex-col">
      {/* Hidden Real File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
        aria-label="Pilih Foto Profil dari Perangkat"
      />

      <div className="w-full bg-stone-900/90 border border-stone-800/80 rounded-2xl shadow-xl backdrop-blur-md p-4 sm:p-6 animate-in fade-in duration-200">
        {/* Top Header of Card */}
        <div className="flex items-center justify-between pb-5 border-b border-stone-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-100 flex items-center gap-2">
              <User className="w-6 h-6 text-amber-400" />
              <span>Profil Pengguna (Data & Konfigurasi)</span>
            </h2>
            <p className="text-xs sm:text-sm text-stone-400 mt-0.5">
              Identitas pemilik arsip, posisi widget di layar, warna, dan foto profil
            </p>
          </div>

          <div className="flex items-center gap-2">
            {!isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-semibold text-xs sm:text-sm shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                <Edit3 className="w-4 h-4" />
                <span>Edit Profil & Posisi</span>
              </button>
            ) : (
              <button
                onClick={handleCancel}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs sm:text-sm transition-all"
              >
                <X className="w-4 h-4" />
                <span>Batal</span>
              </button>
            )}
          </div>
        </div>

        {/* Avatar Section & Working File Picker */}
        <div className="flex flex-col sm:flex-row items-center gap-6 py-6 border-b border-stone-800/80">
          <div className="relative group shrink-0">
            <img
              src={profile.photoUrl}
              alt={profile.name}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-full object-cover border-4 shadow-xl"
              style={{ borderColor: profile.colorTheme || '#b45309' }}
              referrerPolicy="no-referrer"
            />

            {/* Quick Change Photo Button over Avatar */}
            <button
              type="button"
              onClick={handleOpenPicker}
              disabled={isUploading}
              className="absolute bottom-1 right-1 p-2.5 rounded-full bg-amber-500 hover:bg-amber-400 text-stone-950 shadow-xl transition-transform active:scale-90 group-hover:scale-110 cursor-pointer"
              title="Ganti Foto Profil (Buka Galeri/File)"
              aria-label="Ganti Foto Profil"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          <div className="text-center sm:text-left flex-1 min-w-0">
            <h3 className="text-xl sm:text-2xl font-bold text-stone-100 truncate">
              {profile.name}
            </h3>
            <p className="text-sm font-medium text-amber-400 mt-0.5">
              {profile.title}
            </p>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-2 text-xs text-stone-400">
              <span className="flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-stone-500" />
                {profile.generationTitle}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-stone-500" />
                {profile.location}
              </span>
            </div>

            {/* Explicit Ganti Foto Action Button */}
            <div className="mt-3.5 flex flex-wrap gap-2 justify-center sm:justify-start">
              <button
                type="button"
                onClick={handleOpenPicker}
                disabled={isUploading}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 text-xs font-medium transition-colors cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5 text-amber-400" />
                <span>{isUploading ? 'Memproses Foto...' : 'Ganti Foto Profil'}</span>
              </button>
              <span className="text-[11px] text-stone-400 self-center">
                Membuka file picker lokal
              </span>
            </div>
          </div>
        </div>

        {/* Content Section: View vs Edit Form */}
        {!isEditing ? (
          <div className="py-6 space-y-6">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-amber-400 block mb-1.5">
                Deskripsi & Informasi Singkat
              </label>
              <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800/80 text-sm leading-relaxed text-stone-300">
                {profile.bio}
              </div>
            </div>

            {/* Configured Properties */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-stone-950/40 border border-stone-800">
                <span className="text-[11px] font-semibold text-stone-400 block uppercase tracking-wider">
                  Cabang Trah / Keluarga
                </span>
                <span className="text-sm font-medium text-stone-100 mt-1 block">
                  {profile.familyBranch}
                </span>
              </div>

              <div className="p-4 rounded-xl bg-stone-950/40 border border-stone-800">
                <span className="text-[11px] font-semibold text-stone-400 block uppercase tracking-wider">
                  Posisi Widget di Header
                </span>
                <span className="text-sm font-medium text-amber-400 mt-1 block capitalize">
                  {profile.position.replace('_', ' ')}
                </span>
              </div>

              <div className="p-4 rounded-xl bg-stone-950/40 border border-stone-800">
                <span className="text-[11px] font-semibold text-stone-400 block uppercase tracking-wider">
                  Domisili / Wilayah Arsip
                </span>
                <span className="text-sm font-medium text-stone-100 mt-1 block">
                  {profile.location}
                </span>
              </div>

              <div className="p-4 rounded-xl bg-stone-950/40 border border-stone-800">
                <span className="text-[11px] font-semibold text-stone-400 block uppercase tracking-wider">
                  Status Penyimpanan
                </span>
                <span className="text-sm font-medium text-emerald-400 mt-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  {profile.lastUpdated}
                </span>
              </div>
            </div>
          </div>
        ) : (
          /* Editable Form */
          <form onSubmit={handleSave} className="py-6 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Nama Lengkap
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Gelar / Peran dalam Silsilah
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Deskripsi / Informasi Singkat
              </label>
              <textarea
                rows={3}
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none leading-relaxed"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1">
                  Cabang Trah / Marga
                </label>
                <input
                  type="text"
                  value={formData.familyBranch}
                  onChange={(e) => setFormData({ ...formData, familyBranch: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1">
                  Tingkat Generasi
                </label>
                <input
                  type="text"
                  value={formData.generationTitle}
                  onChange={(e) => setFormData({ ...formData, generationTitle: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Posisi, Ukuran & Warna Komponen Profil */}
            <div className="p-4 rounded-2xl bg-stone-950/80 border border-amber-600/40 space-y-3">
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                Konfigurasi Posisi & Tampilan Profil
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-stone-300 text-xs font-medium mb-1">
                    Posisi Komponen
                  </label>
                  <select
                    value={formData.position}
                    onChange={(e) => setFormData({ ...formData, position: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  >
                    <option value="top_right">Pojok Kanan Atas (Header)</option>
                    <option value="top_left">Pojok Kiri Atas (Header)</option>
                    <option value="inside_menu">Hanya di Menu ☰</option>
                    <option value="hidden">Sembunyikan Widget</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-300 text-xs font-medium mb-1">
                    Ukuran Profil
                  </label>
                  <select
                    value={formData.size}
                    onChange={(e) => setFormData({ ...formData, size: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  >
                    <option value="kecil">Kecil</option>
                    <option value="sedang">Sedang</option>
                    <option value="besar">Besar</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-300 text-xs font-medium mb-1">
                    Aksi Klik Profil
                  </label>
                  <select
                    value={formData.clickAction}
                    onChange={(e) => setFormData({ ...formData, clickAction: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  >
                    <option value="navigate">Buka Halaman Profil</option>
                    <option value="toast">Tampilkan Notifikasi Saja</option>
                    <option value="none">Tanpa Aksi</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="pt-4 flex items-center justify-end gap-3 border-t border-stone-800">
              <button
                type="button"
                onClick={handleCancel}
                className="px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-sm font-medium transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-semibold text-sm shadow-xl transition-all active:scale-95 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Perubahan Profil</span>
              </button>
            </div>
          </form>
        )}

        {/* ========================================================= */}
        {/* BAGIAN BARU: 🔐 KUNCI APLIKASI (PENGATURAN KODE/SANDI) */}
        {/* ========================================================= */}
        <div className="mt-6 pt-6 border-t border-stone-800">
          <div className="p-5 sm:p-6 rounded-3xl bg-stone-950/80 border-2 border-amber-600/30 shadow-xl space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-100 flex items-center gap-2">
                    <span>🔐 Kunci Aplikasi</span>
                    {rootConfig.appLock?.isEnabled ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        Aktif
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide bg-stone-800 text-stone-400 border border-stone-700">
                        Nonaktif
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-stone-400">
                    Kunci proteksi sandi untuk Pengaturan Root APK & perubahan struktur aplikasi
                  </p>
                </div>
              </div>

              {/* Session State Badge & Quick Action */}
              {rootConfig.appLock?.isEnabled && (
                <div className="flex items-center gap-2">
                  {isUnlocked ? (
                    <button
                      type="button"
                      onClick={lockNow}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all cursor-pointer"
                      title="Kunci kembali Pengaturan Root sekarang"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Kunci Sekarang</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() =>
                        openPasscodePrompt({
                          title: 'Buka Pengaturan Root APK',
                          description: 'Masukkan kode untuk membuka akses Root & struktur aplikasi.',
                        })
                      }
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-stone-950 font-bold text-xs shadow transition-all cursor-pointer"
                      title="Buka Kunci Pengaturan Root"
                    >
                      <Unlock className="w-3.5 h-3.5" />
                      <span>Buka Sandi</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="text-xs text-stone-300 leading-relaxed bg-stone-900/60 p-3.5 rounded-2xl border border-stone-800/80">
              💡 <strong>Fungsi Kunci:</strong> Mengunci Pengaturan Root APK / Advanced Settings agar struktur aplikasi, penambahan/penghapusan kolom & tombol, serta struktur silsilah tidak dapat diubah oleh sembarang orang. Pengguna biasa tetap dapat menggunakan aplikasi dan mengubah pengaturan dasar (Profil, Wallpaper, Tema Warna, Font).
            </div>

            {/* Error Feedback */}
            {lockError && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-medium animate-in fade-in duration-150">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{lockError}</span>
              </div>
            )}

            {/* Main Action Buttons */}
            {lockSubView === 'idle' && (
              <div className="pt-2 flex flex-wrap gap-2.5">
                {!rootConfig.appLock?.isEnabled ? (
                  <button
                    type="button"
                    onClick={() => {
                      setLockError(null);
                      setNewCodeInput('');
                      setConfirmCodeInput('');
                      setHintInput('');
                      setLockSubView('activate');
                    }}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-stone-950 text-xs font-bold shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Aktifkan Kunci Aplikasi</span>
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setLockError(null);
                        setCurrentCodeInput('');
                        setNewCodeInput('');
                        setConfirmCodeInput('');
                        setLockSubView('change');
                      }}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      <KeyRound className="w-4 h-4 text-amber-400" />
                      <span>Ubah Kode / Sandi</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setLockError(null);
                        setCurrentCodeInput('');
                        setLockSubView('disable');
                      }}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 border border-rose-800/50 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      <ShieldAlert className="w-4 h-4 text-rose-400" />
                      <span>Nonaktifkan Kunci Aplikasi</span>
                    </button>
                  </>
                )}
              </div>
            )}

            {/* SubView: Aktifkan Kunci / Buat Sandi Baru */}
            {lockSubView === 'activate' && (
              <form onSubmit={handleActivateSubmit} className="p-4 rounded-2xl bg-stone-900/90 border border-stone-700/70 space-y-3.5 animate-in fade-in duration-200">
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Buat Kode / Sandi Kunci Baru
                  </h4>
                  <button
                    type="button"
                    onClick={() => setLockSubView('idle')}
                    className="text-stone-400 hover:text-stone-100 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-300 text-xs font-medium mb-1">
                      Kode / Sandi Baru
                    </label>
                    <div className="relative">
                      <input
                        type={showCode ? 'text' : 'password'}
                        required
                        value={newCodeInput}
                        onChange={(e) => setNewCodeInput(e.target.value)}
                        placeholder="Contoh: 1234"
                        className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs font-mono focus:border-amber-400 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCode(!showCode)}
                        className="absolute right-2.5 top-2 text-stone-400 hover:text-stone-200"
                      >
                        {showCode ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-300 text-xs font-medium mb-1">
                      Konfirmasi Kode / Sandi
                    </label>
                    <input
                      type={showCode ? 'text' : 'password'}
                      required
                      value={confirmCodeInput}
                      onChange={(e) => setConfirmCodeInput(e.target.value)}
                      placeholder="Ketik ulang sandi baru"
                      className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs font-mono focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-stone-300 text-xs font-medium mb-1">
                    Petunjuk Sandi (Opsional)
                  </label>
                  <input
                    type="text"
                    value={hintInput}
                    onChange={(e) => setHintInput(e.target.value)}
                    placeholder="Contoh: Tahun berdirinya trah keluarga"
                    className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setLockSubView('idle')}
                    className="px-3.5 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs transition-colors"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-stone-950 font-bold text-xs transition-colors shadow cursor-pointer"
                  >
                    Simpan & Aktifkan Kunci
                  </button>
                </div>
              </form>
            )}

            {/* SubView: Ubah Kode/Sandi */}
            {lockSubView === 'change' && (
              <form onSubmit={handleChangeSubmit} className="p-4 rounded-2xl bg-stone-900/90 border border-stone-700/70 space-y-3.5 animate-in fade-in duration-200">
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Ubah Kode / Sandi Pengaturan
                  </h4>
                  <button
                    type="button"
                    onClick={() => setLockSubView('idle')}
                    className="text-stone-400 hover:text-stone-100 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div>
                  <label className="block text-stone-300 text-xs font-medium mb-1">
                    Kode / Sandi Saat Ini (Lama)
                  </label>
                  <input
                    type="password"
                    required
                    value={currentCodeInput}
                    onChange={(e) => setCurrentCodeInput(e.target.value)}
                    placeholder="Masukkan sandi saat ini"
                    className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs font-mono focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-300 text-xs font-medium mb-1">
                      Kode / Sandi Baru
                    </label>
                    <div className="relative">
                      <input
                        type={showCode ? 'text' : 'password'}
                        required
                        value={newCodeInput}
                        onChange={(e) => setNewCodeInput(e.target.value)}
                        placeholder="Sandi baru"
                        className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs font-mono focus:border-amber-400 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCode(!showCode)}
                        className="absolute right-2.5 top-2 text-stone-400 hover:text-stone-200"
                      >
                        {showCode ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-300 text-xs font-medium mb-1">
                      Konfirmasi Kode / Sandi Baru
                    </label>
                    <input
                      type={showCode ? 'text' : 'password'}
                      required
                      value={confirmCodeInput}
                      onChange={(e) => setConfirmCodeInput(e.target.value)}
                      placeholder="Ketik ulang sandi baru"
                      className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs font-mono focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setLockSubView('idle')}
                    className="px-3.5 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs transition-colors"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs transition-colors shadow cursor-pointer"
                  >
                    Perbarui Sandi
                  </button>
                </div>
              </form>
            )}

            {/* SubView: Nonaktifkan Kunci */}
            {lockSubView === 'disable' && (
              <form onSubmit={handleDisableSubmit} className="p-4 rounded-2xl bg-rose-950/30 border border-rose-800/60 space-y-3.5 animate-in fade-in duration-200">
                <div className="flex items-center justify-between pb-2 border-b border-rose-900/40">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-rose-300">
                    Nonaktifkan Kunci Aplikasi
                  </h4>
                  <button
                    type="button"
                    onClick={() => setLockSubView('idle')}
                    className="text-stone-400 hover:text-stone-100 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-xs text-stone-300">
                  Setelah dinonaktifkan, Pengaturan Root APK dan struktur aplikasi dapat diakses langsung oleh siapa saja tanpa sandi.
                </p>

                <div>
                  <label className="block text-stone-300 text-xs font-medium mb-1">
                    Masukkan Kode / Sandi Saat Ini untuk Konfirmasi
                  </label>
                  <input
                    type="password"
                    required
                    value={currentCodeInput}
                    onChange={(e) => setCurrentCodeInput(e.target.value)}
                    placeholder="Sandi saat ini"
                    className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-rose-700 text-stone-100 text-xs font-mono focus:border-rose-500 focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setLockSubView('idle')}
                    className="px-3.5 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs transition-colors"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-stone-100 font-bold text-xs transition-colors shadow cursor-pointer"
                  >
                    Konfirmasi Nonaktifkan
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Bottom Back Button */}
        <div className="pt-4 mt-2 border-t border-stone-800/80 flex items-center justify-between">
          <button
            onClick={goBack}
            className="flex items-center gap-2 text-xs sm:text-sm text-stone-400 hover:text-amber-300 transition-colors"
          >
            <span>← Kembali</span>
          </button>
          <span className="text-[11px] text-stone-500">
            Data tersimpan permanen di penyimpanan lokal
          </span>
        </div>
      </div>
    </div>
  );
};
