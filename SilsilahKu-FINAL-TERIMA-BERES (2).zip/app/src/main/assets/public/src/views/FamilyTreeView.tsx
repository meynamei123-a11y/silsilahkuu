import React from 'react';
import { GenealogyTreeOverview } from '../components/GenealogyTreeOverview';

export const FamilyTreeView: React.FC = () => {
  return (
    <div className="w-full h-full flex flex-col overflow-hidden relative">
      <GenealogyTreeOverview />
    </div>
  );
};
