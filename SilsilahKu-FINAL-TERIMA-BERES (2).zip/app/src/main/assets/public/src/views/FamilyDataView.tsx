import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  BookMarked,
  Search,
  Plus,
  Trash2,
  X,
  Save,
  Filter,
  Lock,
  Sparkles,
  Sliders,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';
import { FamilyMember } from '../types';
import { PersonDetailModal } from '../components/PersonDetailModal';
import { NoteImportModal } from '../components/NoteImportModal';

export const FamilyDataView: React.FC = () => {
  const {
    goBack,
    familyMembers,
    addFamilyMember,
    deleteFamilyMember,
    isAppLocked,
    openPasscodePrompt,
    rootConfig,
    updateRootConfig,
    showToast,
    t,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterGender, setFilterGender] = useState<'all' | 'Laki-laki' | 'Perempuan'>('all');
  const [filterGen, setFilterGen] = useState<number | 'all'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isNoteImportOpen, setIsNoteImportOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null);

  // Field Settings Section Expand State (Contextual Settings Requirement 8)
  const [isFieldSettingsOpen, setIsNoteFieldSettingsOpen] = useState(false);
  const [newFieldLabel, setNewFieldLabel] = useState('');
  const [newFieldType, setNewFieldType] = useState<'text' | 'number' | 'textarea'>('text');

  // Form state for adding new member
  const [newMember, setNewMember] = useState({
    name: '',
    gender: 'Laki-laki' as 'Laki-laki' | 'Perempuan',
    generation: 4,
    relation: 'Kerabat Keluarga',
    birthYear: '1995',
    deathYear: '',
    birthPlace: 'Yogyakarta',
    residence: 'Yogyakarta',
    lineageBranch: 'Patrilineal (Garis Ayah)' as 'Patrilineal (Garis Ayah)' | 'Matrilineal (Garis Ibu)',
    notes: '',
    occupation: '',
  });

  // Filtered members list
  const filtered = familyMembers.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.relation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.birthPlace.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGender = filterGender === 'all' || m.gender === filterGender;
    const matchesGen = filterGen === 'all' || m.generation === filterGen;
    return matchesSearch && matchesGender && matchesGen;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMember.name.trim()) return;

    addFamilyMember({
      name: newMember.name,
      gender: newMember.gender,
      generation: Number(newMember.generation),
      relation: newMember.relation,
      birthYear: newMember.birthYear,
      deathYear: newMember.deathYear.trim() ? newMember.deathYear : null,
      birthPlace: newMember.birthPlace,
      residence: newMember.residence,
      lineageBranch: newMember.lineageBranch,
      notes: newMember.notes || 'Catatan silsilah ditambahkan pada prototype.',
      fatherId: null,
      motherId: null,
      spouseId: null,
      occupation: newMember.occupation,
    });

    setIsAddModalOpen(false);
    setNewMember({
      name: '',
      gender: 'Laki-laki',
      generation: 4,
      relation: 'Kerabat Keluarga',
      birthYear: '1995',
      deathYear: '',
      birthPlace: 'Yogyakarta',
      residence: 'Yogyakarta',
      lineageBranch: 'Patrilineal (Garis Ayah)',
      notes: '',
      occupation: '',
    });
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Yakin ingin menghapus data anggota "${name}"?`)) {
      deleteFamilyMember(id);
      if (selectedMember?.id === id) {
        setSelectedMember(null);
      }
    }
  };

  const handleAddField = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFieldLabel.trim()) return;

    const existingFields = rootConfig.customPersonFields || [];
    const newField = {
      id: `field_${Date.now()}`,
      key: newFieldLabel.toLowerCase().replace(/\s+/g, '_'),
      label: newFieldLabel.trim(),
      type: newFieldType,
      category: 'general' as const,
      order: existingFields.length + 1,
      isVisible: true,
      isReadOnly: false,
    };

    updateRootConfig({
      customPersonFields: [...existingFields, newField],
    });

    setNewFieldLabel('');
    showToast(`✅ Field baru "${newField.label}" ditambahkan`);
  };

  return (
    <div className="w-full h-full overflow-y-auto p-3 sm:p-5 flex flex-col text-stone-100">
      <div className="w-full bg-stone-900/90 border border-stone-800/80 rounded-2xl shadow-xl backdrop-blur-md p-4 sm:p-6 animate-in fade-in duration-200 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-100 flex items-center gap-2">
              <BookMarked className="w-6 h-6 text-amber-400" />
              <span>{t('familyData')}</span>
            </h2>
            <p className="text-xs sm:text-sm text-stone-400 mt-0.5">
              Kelola daftar anggota keluarga, pencarian, dan struktur data
            </p>
          </div>

          <button
            onClick={goBack}
            className="text-xs sm:text-sm text-stone-400 hover:text-stone-100 transition-colors cursor-pointer"
          >
            {t('back')}
          </button>
        </div>

        {/* Action & Search Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama anggota, hubungan, atau tempat lahir..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Contextual Data Field Settings Button */}
            <button
              type="button"
              onClick={() => setIsNoteFieldSettingsOpen((p) => !p)}
              className="flex items-center justify-center gap-1 px-3 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold text-xs transition-colors cursor-pointer"
              title={t('fieldConfig')}
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">{t('fieldConfig')}</span>
            </button>

            {/* Note Import Button */}
            {!isAppLocked ? (
              <button
                type="button"
                onClick={() => setIsNoteImportOpen(true)}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs sm:text-sm shadow transition-all active:scale-95 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>+ {t('noteImport')}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() =>
                  openPasscodePrompt({
                    title: t('noteImport'),
                    description: t('lockAppDescription'),
                    onSuccess: () => setIsNoteImportOpen(true),
                  })
                }
                className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-850 text-amber-400 border border-amber-600/40 text-xs font-semibold shadow cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>+ {t('noteImport')}</span>
              </button>
            )}

            {/* Standard Add Member Button */}
            {!isAppLocked ? (
              <button
                type="button"
                onClick={() => setIsAddModalOpen(true)}
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-semibold text-xs sm:text-sm shadow transition-all active:scale-95 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{t('add')}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() =>
                  openPasscodePrompt({
                    title: 'Tambah Anggota',
                    description: t('lockAppDescription'),
                    onSuccess: () => setIsAddModalOpen(true),
                  })
                }
                className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-stone-900 text-amber-300 border border-amber-600/40 font-semibold text-xs cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>{t('add')}</span>
              </button>
            )}
          </div>
        </div>

        {/* EXPANDABLE DATA FIELD SETTINGS (Requirement 8 - Contextual Settings) */}
        {isFieldSettingsOpen && (
          <div className="p-4 rounded-2xl bg-stone-950/90 border border-stone-800 space-y-3 animate-in fade-in duration-150 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-stone-800">
              <span className="font-bold text-amber-400 uppercase tracking-wider">
                {t('fieldConfig')} (Kustomisasi Struktur Data)
              </span>
              <button
                type="button"
                onClick={() => setIsNoteFieldSettingsOpen(false)}
                className="text-stone-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* List Existing Fields */}
            <div className="space-y-1">
              {(rootConfig.customPersonFields || []).map((field) => (
                <div key={field.id} className="p-2 rounded-lg bg-stone-900 border border-stone-800 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-stone-200">{field.label}</span>
                    <span className="text-[10px] text-stone-500 font-mono ml-2">({field.type})</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-stone-800 text-stone-400">
                    {field.isVisible ? 'Tampil' : 'Sembunyi'}
                  </span>
                </div>
              ))}
            </div>

            {/* Add New Custom Field Form */}
            <form onSubmit={handleAddField} className="pt-2 border-t border-stone-800 flex items-center gap-2">
              <input
                type="text"
                required
                value={newFieldLabel}
                onChange={(e) => setNewFieldLabel(e.target.value)}
                placeholder="Nama Field Baru (misal: Gelar Adat)..."
                className="flex-1 px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-amber-500 focus:outline-none"
              />
              <select
                value={newFieldType}
                onChange={(e) => setNewFieldType(e.target.value as any)}
                className="px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-amber-500 focus:outline-none"
              >
                <option value="text">Teks Ringkas</option>
                <option value="number">Angka / Tahun</option>
                <option value="textarea">Teks Panjang</option>
              </select>
              <button
                type="submit"
                className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold cursor-pointer"
              >
                + Tambah
              </button>
            </form>
          </div>
        )}

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 text-xs pt-1">
          <span className="text-stone-400 flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5" /> Filter:
          </span>

          <button
            onClick={() => setFilterGender('all')}
            className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
              filterGender === 'all'
                ? 'bg-amber-600 text-stone-950 font-bold'
                : 'bg-stone-950 border border-stone-800 text-stone-300'
            }`}
          >
            Semua
          </button>
          <button
            onClick={() => setFilterGender('Laki-laki')}
            className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
              filterGender === 'Laki-laki'
                ? 'bg-blue-600 text-white font-bold'
                : 'bg-stone-950 border border-stone-800 text-stone-300'
            }`}
          >
            Pria
          </button>
          <button
            onClick={() => setFilterGender('Perempuan')}
            className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
              filterGender === 'Perempuan'
                ? 'bg-pink-600 text-white font-bold'
                : 'bg-stone-950 border border-stone-800 text-stone-300'
            }`}
          >
            Wanita
          </button>
        </div>

        {/* Members Table / List */}
        <div className="divide-y divide-stone-800 border border-stone-800 rounded-2xl overflow-hidden bg-stone-950/60">
          {filtered.length === 0 ? (
            <div className="p-8 text-center text-stone-400 text-sm">
              Tidak ada data anggota silsilah yang cocok dengan pencarian Anda.
            </div>
          ) : (
            filtered.map((member) => (
              <div
                key={member.id}
                className="p-4 hover:bg-stone-850 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 group"
              >
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-full bg-stone-800 border border-stone-700 flex items-center justify-center font-bold text-amber-400 text-xs shrink-0 mt-0.5">
                    G{member.generation}
                  </div>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm font-bold text-stone-100 group-hover:text-amber-400 transition-colors">
                        {member.name}
                      </h4>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-stone-800 text-amber-300">
                        {member.relation}
                      </span>
                    </div>

                    <div className="text-xs text-stone-400 mt-1 flex flex-wrap items-center gap-3">
                      <span>{member.birthYear} — {member.deathYear || 'Kini'}</span>
                      <span>·</span>
                      <span>{member.birthPlace}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    type="button"
                    onClick={() => setSelectedMember(member)}
                    className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs transition-colors cursor-pointer"
                  >
                    Pilih Tokoh
                  </button>

                  {!isAppLocked && (
                    <button
                      type="button"
                      onClick={() => handleDelete(member.id, member.name)}
                      className="p-1.5 rounded-lg text-stone-500 hover:text-red-400 hover:bg-stone-800 transition-colors cursor-pointer"
                      title="Hapus Data"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Full Rich Person Detail Modal */}
        <PersonDetailModal
          person={selectedMember}
          onClose={() => setSelectedMember(null)}
          onSelectPerson={(p) => setSelectedMember(p)}
        />

        {/* Note Import Modal (+ Tambah dari Catatan) */}
        <NoteImportModal
          isOpen={isNoteImportOpen}
          onClose={() => setIsNoteImportOpen(false)}
        />

        {/* Add Member Modal */}
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
            <div className="w-full max-w-lg bg-stone-900 border border-stone-700 rounded-3xl p-6 shadow-2xl space-y-4 my-8">
              <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                <h3 className="text-lg font-bold text-stone-100 flex items-center gap-2">
                  <Plus className="w-5 h-5 text-amber-400" />
                  <span>Tambah Anggota Silsilah Baru</span>
                </h3>
                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="p-1 rounded-lg text-stone-400 hover:text-stone-100 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleAddSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">
                    Nama Lengkap *
                  </label>
                  <input
                    type="text"
                    required
                    value={newMember.name}
                    onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                    placeholder="Contoh: Raden Mas Danang Sutowijoyo"
                    className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">
                      Jenis Kelamin
                    </label>
                    <select
                      value={newMember.gender}
                      onChange={(e) =>
                        setNewMember({
                          ...newMember,
                          gender: e.target.value as 'Laki-laki' | 'Perempuan',
                        })
                      }
                      className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 focus:border-amber-500 focus:outline-none"
                    >
                      <option value="Laki-laki">Laki-laki</option>
                      <option value="Perempuan">Perempuan</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">
                      Tingkat Generasi
                    </label>
                    <select
                      value={newMember.generation}
                      onChange={(e) =>
                        setNewMember({ ...newMember, generation: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 focus:border-amber-500 focus:outline-none"
                    >
                      <option value={1}>Generasi 1</option>
                      <option value={2}>Generasi 2</option>
                      <option value={3}>Generasi 3</option>
                      <option value={4}>Generasi 4</option>
                      <option value={5}>Generasi 5</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">
                      Hubungan Silsilah
                    </label>
                    <input
                      type="text"
                      value={newMember.relation}
                      onChange={(e) => setNewMember({ ...newMember, relation: e.target.value })}
                      placeholder="Contoh: Adik Kandung, Paman, Sepupu"
                      className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">
                      Tahun Lahir
                    </label>
                    <input
                      type="text"
                      value={newMember.birthYear}
                      onChange={(e) =>
                        setNewMember({ ...newMember, birthYear: e.target.value })
                      }
                      placeholder="1995"
                      className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-800 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-stone-800 text-stone-300 text-xs font-medium hover:bg-stone-700 cursor-pointer"
                  >
                    {t('cancel')}
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 text-xs font-bold shadow-lg cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{t('save')}</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-4 border-t border-stone-800 flex items-center justify-between">
          <button
            onClick={goBack}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs sm:text-sm font-medium transition-colors cursor-pointer"
          >
            <span>{t('back')}</span>
          </button>
          <span className="text-xs text-stone-500 font-mono">
            Total {familyMembers.length} {t('familyData')}
          </span>
        </div>
      </div>
    </div>
  );
};
