import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { History, MapPin, Calendar, Scroll, Milestone, BookOpen } from 'lucide-react';

export const AncestryView: React.FC = () => {
  const { goBack, familyMembers } = useApp();
  const [activeEra, setActiveEra] = useState<'all' | 'pra-1945' | '1945-1980' | 'modern'>('all');

  const eras = [
    {
      id: 'pra-1945',
      name: 'Era Pra-Kemerdekaan (1892 - 1945)',
      description: 'Zaman perintisan tradisi keluarga, penulisan naskah babad, dan pengabdian abdi dalem.',
      ancestors: familyMembers.filter((m) => parseInt(m.birthYear) < 1945),
    },
    {
      id: '1945-1980',
      name: 'Era Perjuangan & Pendidikan (1945 - 1980)',
      description: 'Generasi pejuang kemerdekaan, pendidik sekolah rakyat, dan perpindahan ke kota modern.',
      ancestors: familyMembers.filter(
        (m) => parseInt(m.birthYear) >= 1945 && parseInt(m.birthYear) < 1980
      ),
    },
    {
      id: 'modern',
      name: 'Era Kontemporer & Digital (1980 - Sekarang)',
      description: 'Konservasi arsip silsilah keluarga dalam bentuk digital interaktif untuk generasi penerus.',
      ancestors: familyMembers.filter((m) => parseInt(m.birthYear) >= 1980),
    },
  ];

  const displayedEras = activeEra === 'all' ? eras : eras.filter((e) => e.id === activeEra);

  return (
    <div className="w-full h-full overflow-y-auto p-3 sm:p-5 flex flex-col">
      <div className="w-full bg-stone-900/90 border border-stone-800/80 rounded-2xl shadow-xl backdrop-blur-md p-4 sm:p-6 animate-in fade-in duration-200 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-5 border-b border-stone-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-100 flex items-center gap-2">
              <History className="w-6 h-6 text-amber-400" />
              <span>Ancestry (Jejak & Sejarah Leluhur)</span>
            </h2>
            <p className="text-xs sm:text-sm text-stone-400 mt-0.5">
              Kronologi masa lalu, tanah tumpah darah, dan warisan nilai dari para pendahulu
            </p>
          </div>

          <button
            onClick={goBack}
            className="text-xs sm:text-sm text-stone-400 hover:text-stone-100 transition-colors"
          >
            ← Kembali
          </button>
        </div>

        {/* Geographic Origin Cards */}
        <div className="my-6 space-y-3">
          <div className="text-xs font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" />
            <span>Pusat Geografis Leluhur</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800">
              <span className="text-sm font-bold text-stone-100 block">Kotagede & Bantul</span>
              <span className="text-xs text-amber-400 block mt-0.5">Akar Leluhur Pertama (1892)</span>
              <p className="text-xs text-stone-400 mt-2 leading-relaxed">
                Tempat kelahiran K.R.T. Wiryodiningrat & R. Ayu Murtini, pusat kebudayaan perak dan batik.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800">
              <span className="text-sm font-bold text-stone-100 block">Surakarta Hadiningrat</span>
              <span className="text-xs text-amber-400 block mt-0.5">Pusat Trah Generasi II (1924)</span>
              <p className="text-xs text-stone-400 mt-2 leading-relaxed">
                Pusat kediaman R.M. Soedarmono Kusumo dan basis musyawarah keluarga besar.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800">
              <span className="text-sm font-bold text-stone-100 block">Yogyakarta Modern</span>
              <span className="text-xs text-amber-400 block mt-0.5">Arsip & Penerus Masa Kini</span>
              <p className="text-xs text-stone-400 mt-2 leading-relaxed">
                Lokasi pemeliharaan naskah fisik, digitalisasi silsilah, dan tempat lahir tunas muda keluarga.
              </p>
            </div>
          </div>
        </div>

        {/* Timeline Era Filters */}
        <div className="my-6">
          <div className="flex items-center gap-2 mb-3">
            <Milestone className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-300">
              Filter Lintasan Waktu:
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveEra('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeEra === 'all'
                  ? 'bg-amber-600 text-stone-950 shadow-md'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
              }`}
            >
              Semua Masa
            </button>
            <button
              onClick={() => setActiveEra('pra-1945')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeEra === 'pra-1945'
                  ? 'bg-amber-600 text-stone-950 shadow-md'
                  : 'bg-stone-950/70 border border-stone-800 text-stone-300 hover:bg-stone-800'
              }`}
            >
              Pra-Kemerdekaan (&lt; 1945)
            </button>
            <button
              onClick={() => setActiveEra('1945-1980')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeEra === '1945-1980'
                  ? 'bg-amber-600 text-stone-950 shadow-md'
                  : 'bg-stone-950/70 border border-stone-800 text-stone-300 hover:bg-stone-800'
              }`}
            >
              Perjuangan (1945 - 1980)
            </button>
            <button
              onClick={() => setActiveEra('modern')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeEra === 'modern'
                  ? 'bg-amber-600 text-stone-950 shadow-md'
                  : 'bg-stone-950/70 border border-stone-800 text-stone-300 hover:bg-stone-800'
              }`}
            >
              Modern (1980+)
            </button>
          </div>
        </div>

        {/* Chronological Era Cards */}
        <div className="my-6 space-y-6">
          {displayedEras.map((era) => (
            <div
              key={era.id}
              className="p-5 sm:p-6 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-amber-400">
                    {era.name}
                  </h3>
                  <p className="text-xs text-stone-300 mt-1 leading-relaxed">
                    {era.description}
                  </p>
                </div>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-stone-900 border border-stone-700 text-stone-300 font-mono">
                  {era.ancestors.length} Tokoh
                </span>
              </div>

              <div className="space-y-2 pt-2">
                {era.ancestors.map((person) => (
                  <div
                    key={person.id}
                    className="p-3.5 rounded-xl bg-stone-900/70 border border-stone-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-stone-100">
                          {person.name}
                        </span>
                        <span className="text-[10px] text-amber-400/90 font-mono">
                          ({person.birthYear} — {person.deathYear || 'Kini'})
                        </span>
                      </div>
                      <p className="text-xs text-stone-400 mt-0.5">
                        {person.relation} · Asal: {person.birthPlace}
                      </p>
                      <p className="text-xs text-stone-300 mt-1">{person.notes}</p>
                    </div>

                    <div className="text-right text-[11px] text-stone-400 shrink-0">
                      <span>Generasi {person.generation}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-stone-800 flex items-center justify-between">
          <button
            onClick={goBack}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs sm:text-sm font-medium transition-colors"
          >
            <span>← Kembali ke Halaman Utama</span>
          </button>
        </div>
      </div>
    </div>
  );
};
