import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GitFork, Shield, ArrowDown, UserCheck, Heart, Sparkles } from 'lucide-react';

export const LineageView: React.FC = () => {
  const { goBack, familyMembers } = useApp();
  const [activeBranch, setActiveBranch] = useState<'patrilineal' | 'matrilineal'>('patrilineal');

  // Patrilineal direct chain: Wiryodiningrat -> Soedarmono -> Hendro -> Arya -> Bimasena
  const patrilinealLine = familyMembers.filter((m) =>
    ['mem-1', 'mem-3', 'mem-5', 'mem-7', 'mem-9'].includes(m.id)
  ).sort((a, b) => a.generation - b.generation);

  // Matrilineal connection: Endang Purwaningsih -> Arya -> Bimasena
  const matrilinealLine = familyMembers.filter((m) =>
    ['mem-6', 'mem-7', 'mem-8', 'mem-9'].includes(m.id)
  ).sort((a, b) => a.generation - b.generation);

  const currentChain = activeBranch === 'patrilineal' ? patrilinealLine : matrilinealLine;

  return (
    <div className="w-full h-full overflow-y-auto p-3 sm:p-5 flex flex-col">
      <div className="w-full bg-stone-900/90 border border-stone-800/80 rounded-2xl shadow-xl backdrop-blur-md p-4 sm:p-6 animate-in fade-in duration-200 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-5 border-b border-stone-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-100 flex items-center gap-2">
              <GitFork className="w-6 h-6 text-amber-400" />
              <span>Lineage (Garis Trah Keturunan)</span>
            </h2>
            <p className="text-xs sm:text-sm text-stone-400 mt-0.5">
              Penelusuran mata rantai darah murni patrilineal dan matrilineal keluarga
            </p>
          </div>

          <button
            onClick={goBack}
            className="text-xs sm:text-sm text-stone-400 hover:text-stone-100 transition-colors"
          >
            ← Kembali
          </button>
        </div>

        {/* Branch Selector Tabs */}
        <div className="my-6 grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setActiveBranch('patrilineal')}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
              activeBranch === 'patrilineal'
                ? 'bg-amber-950/30 border-amber-400 ring-2 ring-amber-500/30 shadow-lg'
                : 'bg-stone-950/50 border-stone-800 hover:bg-stone-800'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-mono uppercase tracking-wider text-amber-400">
                Garis Utama (Trah Ayah)
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-blue-400" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-stone-100">
              Garis Patrilineal
            </h3>
            <p className="text-xs text-stone-400 mt-1">
              Mata rantai leluhur laki-laki pembawa nama trah Kusumaningrat.
            </p>
          </button>

          <button
            type="button"
            onClick={() => setActiveBranch('matrilineal')}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
              activeBranch === 'matrilineal'
                ? 'bg-amber-950/30 border-amber-400 ring-2 ring-amber-500/30 shadow-lg'
                : 'bg-stone-950/50 border-stone-800 hover:bg-stone-800'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-mono uppercase tracking-wider text-amber-400">
                Garis Ibu & Pasangan
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-pink-400" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-stone-100">
              Garis Matrilineal
            </h3>
            <p className="text-xs text-stone-400 mt-1">
              Jejak para ibu, pendidik batin, dan keharmonisan keluarga besar.
            </p>
          </button>
        </div>

        {/* Sequential Lineage Chain Presentation */}
        <div className="my-6 p-6 rounded-2xl bg-stone-950/70 border border-stone-800">
          <div className="flex items-center justify-between mb-6">
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-400">
              Rantai Urutan Generasi Terhubung:
            </span>
            <span className="text-xs text-amber-400 font-mono">
              {currentChain.length} Generasi Berurutan
            </span>
          </div>

          <div className="space-y-4 relative">
            {currentChain.map((person, idx) => {
              const isLast = idx === currentChain.length - 1;
              return (
                <div key={person.id} className="relative">
                  <div className="flex items-start gap-4 p-4 rounded-xl bg-stone-900/90 border border-stone-800">
                    <div className="w-10 h-10 rounded-full bg-amber-500/15 border border-amber-500/40 flex items-center justify-center font-bold text-amber-400 text-xs shrink-0">
                      G{person.generation}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <h4 className="text-sm sm:text-base font-bold text-stone-100">
                          {person.name}
                        </h4>
                        <span className="text-xs text-amber-400 font-medium">
                          {person.relation}
                        </span>
                      </div>

                      <div className="text-xs text-stone-400 mt-1 flex items-center gap-3">
                        <span>Lahir: {person.birthYear}</span>
                        <span>·</span>
                        <span>{person.birthPlace}</span>
                        {person.occupation && (
                          <>
                            <span>·</span>
                            <span className="text-stone-300">{person.occupation}</span>
                          </>
                        )}
                      </div>

                      <p className="text-xs text-stone-300 mt-2 leading-relaxed">
                        {person.notes}
                      </p>
                    </div>
                  </div>

                  {/* Flow Arrow */}
                  {!isLast && (
                    <div className="flex justify-center my-2 text-amber-400/80">
                      <ArrowDown className="w-5 h-5 animate-bounce" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-stone-800 flex items-center justify-between">
          <button
            onClick={goBack}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs sm:text-sm font-medium transition-colors"
          >
            <span>← Kembali ke Halaman Utama</span>
          </button>
        </div>
      </div>
    </div>
  );
};
