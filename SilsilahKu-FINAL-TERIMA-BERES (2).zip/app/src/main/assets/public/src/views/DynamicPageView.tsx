import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PersonDetailModal } from '../components/PersonDetailModal';
import { FamilyMember, UIComponent } from '../types';
import { renderIconByName } from '../utils/iconMap';

// Domain views
import { ProfileView } from './ProfileView';
import { GenealogyView } from './GenealogyView';
import { FamilyTreeView } from './FamilyTreeView';
import { AncestryView } from './AncestryView';
import { LineageView } from './LineageView';
import { FamilyDataView } from './FamilyDataView';

export const DynamicPageView: React.FC = () => {
  const {
    currentPage,
    navigateToPage,
    familyMembers,
    showToast,
    executeComponentAction,
    appMode,
    openComponentEditor,
    openPersonModal,
    activePersonModal,
    closePersonModal,
    t,
  } = useApp();

  const [selectedPerson, setSelectedPerson] = useState<FamilyMember | null>(null);

  // If page is one of the specialized full domain views
  if (currentPage.id === 'page_profile') return <ProfileView />;
  if (currentPage.id === 'page_genealogy') return <GenealogyView />;
  if (currentPage.id === 'page_family_tree') return <FamilyTreeView />;
  if (currentPage.id === 'page_ancestry') return <AncestryView />;
  if (currentPage.id === 'page_lineage') return <LineageView />;
  if (currentPage.id === 'page_family_data') return <FamilyDataView />;

  // HOMEPAGE: When on page_home with default 5_vertical_cards or dynamic flow
  if (currentPage.isHomePage || currentPage.id === 'page_home') {
    const priorityIds = [
      'adam',
      'set',
      'enos',
      'kenan',
      'mahalaleel',
      'yared',
      'henokh',
      'metusalah',
      'nuh',
      'yakub',
    ];

    const displayedMembers = [...familyMembers].sort((a, b) => {
      const idxA = priorityIds.indexOf(a.id);
      const idxB = priorityIds.indexOf(b.id);
      if (idxA !== -1 && idxB !== -1) return idxA - idxB;
      if (idxA !== -1) return -1;
      if (idxB !== -1) return 1;
      return a.generation - b.generation;
    });

    return (
      <div id="page-home-container" className="w-full h-full overflow-y-auto p-4 sm:p-6 md:p-8 select-none">
        <div className="max-w-2xl mx-auto space-y-4 animate-in fade-in duration-200">
          {/* Subtle Header Label */}
          <div className="border-b border-stone-800/80 pb-2 mb-2 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              {t('personListHeader')}
            </span>
            <span className="text-[11px] text-stone-500 font-mono">
              {displayedMembers.length} {t('familyData')}
            </span>
          </div>

          {/* Any custom top components added via Root APK */}
          {currentPage.components.length > 0 && (
            <div className="space-y-2 mb-4">
              {currentPage.components
                .filter((c) => c.isVisible)
                .map((comp) => {
                  const s = comp.style || {};
                  return (
                    <div
                      key={comp.id}
                      id={comp.id}
                      onClick={() => {
                        if (appMode === 'editor') {
                          openComponentEditor(currentPage.id, comp);
                        } else {
                          executeComponentAction(comp);
                        }
                      }}
                      className="p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all hover:scale-[1.01]"
                      style={{
                        backgroundColor: s.backgroundColor || comp.backgroundColor || 'rgba(28, 25, 23, 0.85)',
                        borderColor: s.borderColor || comp.borderColor || '#38322e',
                        color: s.textColor || comp.color || '#f5f5f4',
                        borderRadius: s.borderRadius ? `${s.borderRadius}px` : '12px',
                        fontSize: s.fontSize ? `${s.fontSize}px` : undefined,
                        opacity: (s.transparency ?? comp.transparency ?? 100) / 100,
                      }}
                    >
                      <div className="flex items-center gap-3">
                        {comp.icon && (
                          <div className="p-2 rounded-lg bg-stone-950 text-amber-400 shrink-0">
                            {renderIconByName(comp.icon, 'w-4 h-4')}
                          </div>
                        )}
                        <div>
                          <span className="font-bold text-sm block">{comp.name}</span>
                          {comp.subtitle && (
                            <span className="text-xs text-amber-400/90 block">{comp.subtitle}</span>
                          )}
                        </div>
                      </div>
                      <span className="text-stone-400 text-xs">→</span>
                    </div>
                  );
                })}
            </div>
          )}

          {/* Clean Vertical Text List of Names */}
          <div className="divide-y divide-stone-800/60 bg-stone-900/60 border border-stone-800/80 rounded-2xl overflow-hidden shadow-xl backdrop-blur-md">
            {displayedMembers.map((member) => (
              <button
                key={member.id}
                id={`person-node-${member.id}`}
                type="button"
                onClick={() => setSelectedPerson(member)}
                className="w-full text-left px-4 py-3 sm:py-3.5 hover:bg-stone-800/70 transition-colors cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full bg-amber-400/80 group-hover:scale-125 transition-transform" />
                  <span className="text-base sm:text-lg font-bold text-stone-100 group-hover:text-amber-300 transition-colors">
                    {member.name}
                  </span>
                  {member.birthYear && (
                    <span className="text-xs text-stone-400 font-mono">
                      ({member.birthYear})
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-amber-400/80 px-2 py-0.5 rounded bg-stone-950/60 border border-stone-800">
                    Gen {member.generation}
                  </span>
                  <span className="text-stone-500 group-hover:text-amber-400 transition-colors text-xs font-mono">
                    →
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Person Detail Modal */}
        <PersonDetailModal
          person={selectedPerson || activePersonModal}
          onClose={() => {
            setSelectedPerson(null);
            closePersonModal();
          }}
          onSelectPerson={(p) => setSelectedPerson(p)}
          onSetAsRoot={(p) => {
            setSelectedPerson(null);
            closePersonModal();
            navigateToPage('page_genealogy');
            showToast(`${t('genealogy')}: "${p.name}"`);
          }}
        />
      </div>
    );
  }

  // DYNAMIC CUSTOM PAGE RENDERING
  return (
    <div
      id={`page-view-${currentPage.id}`}
      className="w-full h-full overflow-y-auto p-4 sm:p-6 md:p-8 select-none"
    >
      <div className="max-w-3xl mx-auto space-y-5 animate-in fade-in duration-200">
        {/* Header */}
        <div className="border-b border-stone-800 pb-3 flex items-center justify-between">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-stone-100">{currentPage.title}</h1>
            {currentPage.description && (
              <p className="text-xs text-stone-400 mt-0.5">{currentPage.description}</p>
            )}
          </div>

          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-500/40">
            {currentPage.layoutType}
          </span>
        </div>

        {/* Components Grid / Flow */}
        {currentPage.components.length === 0 ? (
          <div className="p-8 text-center border-2 border-dashed border-stone-800 rounded-2xl">
            <p className="text-stone-400 text-sm">Halaman ini belum memiliki komponen aktif.</p>
            <p className="text-stone-500 text-xs mt-1">
              Gunakan mode <strong>🛠 Visual Editor</strong> di Root APK untuk menambahkan elemen baru.
            </p>
          </div>
        ) : (
          <div
            className={
              currentPage.layoutType === 'grid'
                ? 'grid grid-cols-1 sm:grid-cols-2 gap-3'
                : 'space-y-3'
            }
          >
            {[...currentPage.components]
              .sort((a, b) => a.order - b.order)
              .filter((c) => c.isVisible)
              .map((comp) => {
                const s = comp.style || {};
                return (
                  <div
                    key={comp.id}
                    id={comp.id}
                    onClick={() => {
                      if (appMode === 'editor') {
                        openComponentEditor(currentPage.id, comp);
                      } else {
                        executeComponentAction(comp);
                      }
                    }}
                    className="p-4 rounded-xl border flex items-center justify-between cursor-pointer transition-all hover:scale-[1.01] active:scale-95"
                    style={{
                      backgroundColor:
                        s.backgroundColor || comp.backgroundColor || 'rgba(28, 25, 23, 0.85)',
                      borderColor: s.borderColor || comp.borderColor || '#38322e',
                      color: s.textColor || comp.color || '#f5f5f4',
                      borderRadius: s.borderRadius ? `${s.borderRadius}px` : '12px',
                      fontSize: s.fontSize ? `${s.fontSize}px` : undefined,
                      opacity: (s.transparency ?? comp.transparency ?? 100) / 100,
                    }}
                  >
                    <div className="flex items-center gap-3">
                      {comp.icon && (
                        <div className="p-2.5 rounded-lg bg-stone-950 text-amber-400 shrink-0">
                          {renderIconByName(comp.icon, 'w-4 h-4')}
                        </div>
                      )}
                      <div>
                        <span className="font-bold text-sm block">{comp.name}</span>
                        {comp.subtitle && (
                          <span className="text-xs text-amber-400/90 block">{comp.subtitle}</span>
                        )}
                        {comp.description && (
                          <p className="text-[11px] text-stone-400 mt-0.5">{comp.description}</p>
                        )}
                      </div>
                    </div>

                    <span className="text-stone-400 text-xs">→</span>
                  </div>
                );
              })}
          </div>
        )}
      </div>

      {/* Global Person Modal */}
      <PersonDetailModal
        person={activePersonModal}
        onClose={closePersonModal}
        onSelectPerson={(p) => openPersonModal(p)}
        onSetAsRoot={(p) => {
          closePersonModal();
          navigateToPage('page_genealogy');
          showToast(`${t('genealogy')}: "${p.name}"`);
        }}
      />
    </div>
  );
};
