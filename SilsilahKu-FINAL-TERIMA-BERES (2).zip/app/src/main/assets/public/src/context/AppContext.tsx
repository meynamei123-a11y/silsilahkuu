import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  AppMode,
  RootApkConfig,
  AppPage,
  UIComponent,
  UserProfile,
  BlurLevel,
  CardSize,
  FontFamilyType,
  FontSizePreset,
  FamilyMember,
  LanguageCode,
  ElementStyleConfig,
} from '../types';
import {
  INITIAL_ROOT_CONFIG,
  INITIAL_FAMILY_MEMBERS,
  DEFAULT_GENEALOGY_CONFIG,
} from '../data/initialData';
import { fileToOptimizedDataUrl } from '../utils/imageHelper';
import { getTranslation } from '../utils/i18n';

interface AppContextType {
  // Mode: Preview (👁) vs Editor (⚙)
  appMode: AppMode;
  setAppMode: (mode: AppMode) => void;
  toggleAppMode: () => void;

  // Focus Mode (Full screen tree canvas)
  isFocusMode: boolean;
  setIsFocusMode: (val: boolean) => void;
  toggleFocusMode: () => void;

  // Root Configuration
  rootConfig: RootApkConfig;
  updateRootConfig: (updates: Partial<RootApkConfig>, recordHistory?: boolean) => void;
  updateGlobalTheme: (updates: Partial<RootApkConfig['globalTheme']>) => void;
  exportConfigAsJson: () => string;
  downloadBackupJson: () => void;
  importConfigFromJson: (jsonStr: string) => boolean;
  resetToDefaultConfig: () => void;

  // Undo / Redo Engine
  canUndo: boolean;
  canRedo: boolean;
  undo: () => void;
  redo: () => void;

  // Navigation & Pages
  currentPageId: string;
  currentPage: AppPage;
  pageHistory: string[];
  navigateToPage: (pageId: string) => void;
  goBack: () => void;
  addPage: (page: Omit<AppPage, 'id'>) => string;
  deletePage: (pageId: string) => boolean;
  updatePage: (pageId: string, updates: Partial<AppPage>) => void;

  // Component Management
  addComponentToPage: (pageId: string, component: Omit<UIComponent, 'id'>) => string;
  updateComponent: (pageId: string, compId: string, updates: Partial<UIComponent>) => void;
  deleteComponent: (pageId: string, compId: string) => void;
  duplicateComponent: (pageId: string, compId: string) => void;
  detachComponentAction: (pageId: string, compId: string) => void;
  moveComponentOrder: (pageId: string, compId: string, direction: 'up' | 'down') => void;
  executeComponentAction: (comp: UIComponent) => void;

  // Visual Editor Active Selection State
  selectedPageIdInEditor: string;
  setSelectedPageIdInEditor: (pageId: string) => void;
  selectedElementIdInEditor: string | null;
  setSelectedElementIdInEditor: (elementId: string | null) => void;

  // Two-Tier Security & App Lock
  isUnlocked: boolean;
  isAppLocked: boolean;
  isPasscodePromptOpen: boolean;
  passcodePromptOptions: {
    title: string;
    description: string;
    targetActionName?: string;
  };
  openPasscodePrompt: (options?: {
    title?: string;
    description?: string;
    targetActionName?: string;
    onSuccess?: () => void;
  }) => void;
  closePasscodePrompt: () => void;
  verifyAndUnlock: (code: string) => boolean;
  lockNow: () => void;
  requestProtectedAction: (
    action: () => void,
    actionName?: string,
    actionDescription?: string
  ) => void;
  enableAppLock: (passcode: string, hint?: string) => void;
  disableAppLock: (passcode: string) => boolean;
  changePasscode: (oldPasscode: string, newPasscode: string) => boolean;

  // Modals & Drawers Shortcuts
  isMenuOpen: boolean;
  openMenu: () => void;
  closeMenu: () => void;

  isMainSettingsModalOpen: boolean;
  openMainSettingsModal: () => void;
  closeMainSettingsModal: () => void;

  isLanguageModalOpen: boolean;
  openLanguageModal: () => void;
  closeLanguageModal: () => void;
  setLanguage: (code: LanguageCode) => void;
  t: (key: string) => string;

  isNoteImportModalOpen: boolean;
  openNoteImportModal: () => void;
  closeNoteImportModal: () => void;

  // Root APK Master Control Modal
  isRootApkModalOpen: boolean;
  rootApkInitialTab: 'visual_editor' | 'inspector' | 'code' | 'identitas' | 'halaman_utama' | 'tampilan' | 'font_teks' | 'warna_tema' | 'profil' | 'kunci_aplikasi';
  openRootApkModal: (tab?: 'visual_editor' | 'inspector' | 'code' | 'identitas' | 'halaman_utama' | 'tampilan' | 'font_teks' | 'warna_tema' | 'profil' | 'kunci_aplikasi') => void;
  closeRootApkModal: () => void;

  isPageSettingsModalOpen: boolean;
  openPageSettingsModal: () => void;
  closePageSettingsModal: () => void;

  editingComponent: { pageId: string; comp: UIComponent } | null;
  openComponentEditor: (pageId: string, comp: UIComponent) => void;
  closeComponentEditor: () => void;

  // Basic Settings Modals
  isBasicWallpaperModalOpen: boolean;
  openBasicWallpaperModal: () => void;
  closeBasicWallpaperModal: () => void;

  isBasicThemeModalOpen: boolean;
  openBasicThemeModal: () => void;
  closeBasicThemeModal: () => void;

  isBasicFontModalOpen: boolean;
  openBasicFontModal: () => void;
  closeBasicFontModal: () => void;

  // Profile Management
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
  setAvatarFromFile: (file: File) => Promise<boolean>;

  // Wallpaper & Appearance Shortcuts
  setWallpaperFromFile: (file: File) => Promise<boolean>;
  setWallpaperPreset: (url: string, name: string) => void;
  setBlurLevel: (blur: BlurLevel) => void;
  setCardSize: (size: CardSize) => void;
  setFontFamily: (font: FontFamilyType) => void;
  setFontSizePreset: (preset: FontSizePreset) => void;
  setFontSizeCustom: (val: number) => void;

  // Family Members Data
  familyMembers: FamilyMember[];
  addFamilyMember: (member: Omit<FamilyMember, 'id'>) => void;
  deleteFamilyMember: (id: string) => void;
  updateFamilyMember: (id: string, updates: Partial<FamilyMember>) => void;

  // Selected Person for Global Biodata Modal
  activePersonModal: FamilyMember | null;
  openPersonModal: (member: FamilyMember) => void;
  closePersonModal: () => void;

  // Toast
  toastMessage: string | null;
  showToast: (message: string) => void;
}

const STORAGE_KEYS = {
  ROOT_CONFIG: 'silsilahku_root_config_v3',
  FAMILY_MEMBERS: 'silsilahku_family_members_v3',
  APP_MODE: 'silsilahku_app_mode_v3',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // App Mode
  const [appMode, setAppMode] = useState<AppMode>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.APP_MODE);
      if (saved === 'editor' || saved === 'preview') return saved;
    } catch (e) {
      console.error(e);
    }
    return 'preview';
  });

  // Focus Mode
  const [isFocusMode, setIsFocusMode] = useState<boolean>(false);
  const toggleFocusMode = () => setIsFocusMode((prev) => !prev);

  // Root Config State
  const [rootConfig, setRootConfig] = useState<RootApkConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ROOT_CONFIG);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return {
            ...INITIAL_ROOT_CONFIG,
            ...parsed,
            appLock: {
              ...INITIAL_ROOT_CONFIG.appLock,
              ...(parsed.appLock || {}),
            },
            globalTheme: {
              ...INITIAL_ROOT_CONFIG.globalTheme,
              ...(parsed.globalTheme || {}),
            },
            genealogyDisplay: {
              ...DEFAULT_GENEALOGY_CONFIG,
              ...(parsed.genealogyDisplay || {}),
            },
            customPersonFields:
              parsed.customPersonFields || INITIAL_ROOT_CONFIG.customPersonFields,
            customPresets: parsed.customPresets || INITIAL_ROOT_CONFIG.customPresets,
            profile: {
              ...INITIAL_ROOT_CONFIG.profile,
              ...(parsed.profile || {}),
            },
            pages:
              Array.isArray(parsed.pages) && parsed.pages.length > 0
                ? parsed.pages
                : INITIAL_ROOT_CONFIG.pages,
          };
        }
      }
    } catch (e) {
      console.error('Error loading config from localStorage', e);
    }
    return INITIAL_ROOT_CONFIG;
  });

  // Undo & Redo Stacks
  const [undoStack, setUndoStack] = useState<RootApkConfig[]>([]);
  const [redoStack, setRedoStack] = useState<RootApkConfig[]>([]);

  const pushToHistory = (previousConfig: RootApkConfig) => {
    setUndoStack((prev) => [...prev.slice(-30), previousConfig]);
    setRedoStack([]); // Clear redo stack on new action
  };

  const undo = () => {
    if (undoStack.length === 0) return;
    const previous = undoStack[undoStack.length - 1];
    setUndoStack((prev) => prev.slice(0, prev.length - 1));
    setRedoStack((prev) => [...prev, rootConfig]);
    setRootConfig(previous);
    showToast('↶ Perubahan dibatalkan (Undo)');
  };

  const redo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    setRedoStack((prev) => prev.slice(0, prev.length - 1));
    setUndoStack((prev) => [...prev, rootConfig]);
    setRootConfig(next);
    showToast('↷ Perubahan dimajukan kembali (Redo)');
  };

  const profile = rootConfig.profile;

  // Visual Editor Active Element Selection
  const [selectedPageIdInEditor, setSelectedPageIdInEditor] = useState<string>(
    rootConfig.homePageId || 'page_home'
  );
  const [selectedElementIdInEditor, setSelectedElementIdInEditor] = useState<string | null>(null);

  // Security / App Lock Session State
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const isAppLocked = Boolean(rootConfig.appLock?.isEnabled && !isUnlocked);

  // Passcode Prompt Modal State
  const [isPasscodePromptOpen, setIsPasscodePromptOpen] = useState(false);
  const [passcodePromptOptions, setPasscodePromptOptions] = useState<{
    title: string;
    description: string;
    targetActionName?: string;
  }>({
    title: 'Masukkan Kode Pengaturan',
    description: 'Pengaturan Root APK dilindungi oleh kunci aplikasi.',
  });
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);

  // Basic Settings Modals
  const [isBasicWallpaperModalOpen, setIsBasicWallpaperModalOpen] = useState(false);
  const [isBasicThemeModalOpen, setIsBasicThemeModalOpen] = useState(false);
  const [isBasicFontModalOpen, setIsBasicFontModalOpen] = useState(false);

  // Family Members
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FAMILY_MEMBERS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const existingIds = new Set(parsed.map((m: FamilyMember) => m.id));
          const missingInitial = INITIAL_FAMILY_MEMBERS.filter(
            (m) => !existingIds.has(m.id)
          );
          return [...parsed, ...missingInitial];
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_FAMILY_MEMBERS;
  });

  // Navigation State
  const [currentPageId, setCurrentPageId] = useState<string>(
    rootConfig.homePageId || 'page_home'
  );
  const [pageHistory, setPageHistory] = useState<string[]>([
    rootConfig.homePageId || 'page_home',
  ]);

  // Global Person Modal State
  const [activePersonModal, setActivePersonModal] = useState<FamilyMember | null>(null);

  // Modals & Drawers
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMainSettingsModalOpen, setIsMainSettingsModalOpen] = useState(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [isNoteImportModalOpen, setIsNoteImportModalOpen] = useState(false);
  const [isRootApkModalOpen, setIsRootApkModalOpen] = useState(false);
  const [rootApkInitialTab, setRootApkInitialTab] = useState<
    'visual_editor' | 'inspector' | 'code' | 'identitas' | 'halaman_utama' | 'tampilan' | 'font_teks' | 'warna_tema' | 'profil' | 'kunci_aplikasi'
  >('visual_editor');
  const [isPageSettingsModalOpen, setIsPageSettingsModalOpen] = useState(false);
  const [editingComponent, setEditingComponent] = useState<{
    pageId: string;
    comp: UIComponent;
  } | null>(null);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Persistence
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ROOT_CONFIG, JSON.stringify(rootConfig));
    } catch (e) {
      console.error(e);
    }
  }, [rootConfig]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.FAMILY_MEMBERS, JSON.stringify(familyMembers));
    } catch (e) {
      console.error(e);
    }
  }, [familyMembers]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.APP_MODE, appMode);
    } catch (e) {
      console.error(e);
    }
  }, [appMode]);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage((prev) => (prev === message ? null : prev));
    }, 2800);
  };

  const t = (key: string): string => {
    return getTranslation(key, rootConfig.language || 'id');
  };

  const toggleAppMode = () => {
    const nextMode: AppMode = appMode === 'editor' ? 'preview' : 'editor';
    setAppMode(nextMode);
    showToast(
      nextMode === 'editor'
        ? '🛠 Mode Visual Editor Aktif'
        : '👁 Mode Preview Aktif'
    );
  };

  const updateRootConfig = (updates: Partial<RootApkConfig>, recordHistory = true) => {
    if (recordHistory) {
      pushToHistory(rootConfig);
    }
    setRootConfig((prev) => ({
      ...prev,
      ...updates,
    }));
  };

  const updateGlobalTheme = (updates: Partial<RootApkConfig['globalTheme']>) => {
    pushToHistory(rootConfig);
    setRootConfig((prev) => ({
      ...prev,
      globalTheme: {
        ...prev.globalTheme,
        ...updates,
      },
    }));
  };

  const exportConfigAsJson = (): string => {
    const data = {
      version: rootConfig.version || '2.5.0-PROTOTYPE',
      appTitle: rootConfig.appTitle,
      snapshotTimestamp: new Date().toISOString(),
      snapshotSummary: {
        totalMembers: familyMembers.length,
        totalPages: rootConfig.pages.length,
        totalCustomFields: rootConfig.customPersonFields?.length || 0,
        activeTheme: rootConfig.globalTheme.primaryColorName || 'Bronze Pusaka',
        wallpaperName: rootConfig.globalTheme.wallpaperName || 'Parchment Kuno',
        exportedBy: rootConfig.profile.name || 'Admin',
      },
      rootConfig,
      familyMembers,
    };
    return JSON.stringify(data, null, 2);
  };

  const downloadBackupJson = () => {
    try {
      const jsonStr = exportConfigAsJson();
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      a.href = url;
      a.download = `silsilahku_backup_snapshot_${timestamp}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('💾 Berkas Snapshot JSON berhasil diunduh untuk backup!');
    } catch (e) {
      console.error(e);
      showToast('❌ Gagal mengunduh berkas backup!');
    }
  };

  const importConfigFromJson = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed && typeof parsed === 'object') {
        pushToHistory(rootConfig);
        if (parsed.rootConfig) {
          setRootConfig({
            ...INITIAL_ROOT_CONFIG,
            ...parsed.rootConfig,
          });
        }
        if (Array.isArray(parsed.familyMembers)) {
          setFamilyMembers(parsed.familyMembers);
        }
        showToast('✅ Snapshot JSON berhasil dipulihkan!');
        return true;
      }
    } catch (e) {
      console.error(e);
    }
    showToast('❌ Format file JSON snapshot tidak valid!');
    return false;
  };

  const resetToDefaultConfig = () => {
    pushToHistory(rootConfig);
    setRootConfig(INITIAL_ROOT_CONFIG);
    setFamilyMembers(INITIAL_FAMILY_MEMBERS);
    setAppMode('preview');
    setSelectedPageIdInEditor(INITIAL_ROOT_CONFIG.homePageId || 'page_home');
    setSelectedElementIdInEditor(null);
    showToast('🔄 Konfigurasi dikembalikan ke Setelan Pabrik');
  };

  const navigateToPage = (pageId: string) => {
    setCurrentPageId(pageId);
    setPageHistory((prev) => [...prev, pageId]);
  };

  const goBack = () => {
    if (pageHistory.length > 1) {
      const newHistory = [...pageHistory];
      newHistory.pop();
      const prevPage = newHistory[newHistory.length - 1];
      setPageHistory(newHistory);
      setCurrentPageId(prevPage);
    } else {
      setCurrentPageId(rootConfig.homePageId || 'page_home');
    }
  };

  const addPage = (pageData: Omit<AppPage, 'id'>): string => {
    pushToHistory(rootConfig);
    const newId = `page_${Date.now()}`;
    const newPage: AppPage = {
      ...pageData,
      id: newId,
    };
    setRootConfig((prev) => ({
      ...prev,
      pages: [...prev.pages, newPage],
    }));
    setSelectedPageIdInEditor(newId);
    showToast(`✅ Halaman "${newPage.title}" berhasil dibuat!`);
    return newId;
  };

  const deletePage = (pageId: string): boolean => {
    if (pageId === rootConfig.homePageId || pageId === 'page_home') {
      showToast('❌ Halaman Utama tidak dapat dihapus');
      return false;
    }
    pushToHistory(rootConfig);
    setRootConfig((prev) => ({
      ...prev,
      pages: prev.pages.filter((p) => p.id !== pageId),
    }));
    if (currentPageId === pageId) {
      setCurrentPageId(rootConfig.homePageId || 'page_home');
    }
    if (selectedPageIdInEditor === pageId) {
      setSelectedPageIdInEditor(rootConfig.homePageId || 'page_home');
    }
    showToast('🗑 Halaman berhasil dihapus');
    return true;
  };

  const updatePage = (pageId: string, updates: Partial<AppPage>) => {
    pushToHistory(rootConfig);
    setRootConfig((prev) => ({
      ...prev,
      pages: prev.pages.map((p) => (p.id === pageId ? { ...p, ...updates } : p)),
    }));
    showToast('✅ Pengaturan Halaman disimpan');
  };

  const currentPage =
    rootConfig.pages.find((p) => p.id === currentPageId) ||
    rootConfig.pages.find((p) => p.isHomePage) ||
    rootConfig.pages[0];

  const addComponentToPage = (
    pageId: string,
    componentData: Omit<UIComponent, 'id'>
  ): string => {
    pushToHistory(rootConfig);
    const newId = `elem_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const newComp: UIComponent = {
      ...componentData,
      id: newId,
    };
    setRootConfig((prev) => ({
      ...prev,
      pages: prev.pages.map((p) =>
        p.id === pageId ? { ...p, components: [...p.components, newComp] } : p
      ),
    }));
    setSelectedElementIdInEditor(newId);
    showToast(`✅ Elemen "${newComp.name}" ditambahkan`);
    return newId;
  };

  const updateComponent = (
    pageId: string,
    compId: string,
    updates: Partial<UIComponent>
  ) => {
    pushToHistory(rootConfig);
    setRootConfig((prev) => ({
      ...prev,
      pages: prev.pages.map((p) => {
        if (p.id !== pageId) return p;
        return {
          ...p,
          components: p.components.map((c) =>
            c.id === compId ? { ...c, ...updates } : c
          ),
        };
      }),
    }));
    showToast('✅ Elemen berhasil diperbarui');
  };

  const deleteComponent = (pageId: string, compId: string) => {
    pushToHistory(rootConfig);
    setRootConfig((prev) => ({
      ...prev,
      pages: prev.pages.map((p) => {
        if (p.id !== pageId) return p;
        return {
          ...p,
          components: p.components.filter((c) => c.id !== compId),
        };
      }),
    }));
    if (selectedElementIdInEditor === compId) {
      setSelectedElementIdInEditor(null);
    }
    showToast('🗑 Elemen berhasil dihapus');
  };

  const detachComponentAction = (pageId: string, compId: string) => {
    pushToHistory(rootConfig);
    setRootConfig((prev) => ({
      ...prev,
      pages: prev.pages.map((p) => {
        if (p.id !== pageId) return p;
        return {
          ...p,
          components: p.components.map((c) =>
            c.id === compId
              ? {
                  ...c,
                  actionType: 'none',
                  targetPageId: undefined,
                  actionPayload: undefined,
                  customJsCode: undefined,
                }
              : c
          ),
        };
      }),
    }));
    showToast('🔌 Fungsi elemen dilepas (Tampilan tombol tetap ada)');
  };

  const duplicateComponent = (pageId: string, compId: string) => {
    const page = rootConfig.pages.find((p) => p.id === pageId);
    const targetComp = page?.components.find((c) => c.id === compId);
    if (targetComp) {
      addComponentToPage(pageId, {
        ...targetComp,
        name: `${targetComp.name} (Salinan)`,
        order: targetComp.order + 1,
      });
    }
  };

  const moveComponentOrder = (
    pageId: string,
    compId: string,
    direction: 'up' | 'down'
  ) => {
    const page = rootConfig.pages.find((p) => p.id === pageId);
    if (!page) return;

    const comps = [...page.components].sort((a, b) => a.order - b.order);
    const idx = comps.findIndex((c) => c.id === compId);
    if (idx === -1) return;

    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= comps.length) return;

    pushToHistory(rootConfig);
    const tempOrder = comps[idx].order;
    comps[idx].order = comps[targetIdx].order;
    comps[targetIdx].order = tempOrder;

    setRootConfig((prev) => ({
      ...prev,
      pages: prev.pages.map((p) => (p.id === pageId ? { ...p, components: comps } : p)),
    }));
    showToast(`Posisi digeser ${direction === 'up' ? 'ke atas' : 'ke bawah'}`);
  };

  const executeComponentAction = (comp: UIComponent) => {
    if (!comp.isEnabled) {
      showToast(`⚠️ Elemen "${comp.name}" sedang dinonaktifkan`);
      return;
    }
    switch (comp.actionType) {
      case 'navigate':
        if (comp.targetPageId) {
          navigateToPage(comp.targetPageId);
        }
        break;
      case 'open_person_detail':
        if (comp.targetPersonId) {
          const person = familyMembers.find((m) => m.id === comp.targetPersonId);
          if (person) {
            setActivePersonModal(person);
          } else {
            showToast('Tokoh tidak ditemukan dalam database silsilah');
          }
        } else {
          setActivePersonModal(familyMembers[0]);
        }
        break;
      case 'toast':
        showToast(comp.actionPayload || `Aksi "${comp.name}" berhasil dijalankan`);
        break;
      case 'open_popup':
        showToast(comp.actionPayload || `Popup "${comp.name}" aktif`);
        break;
      case 'open_url':
        if (comp.actionPayload) {
          window.open(comp.actionPayload, '_blank');
        }
        break;
      case 'back':
        goBack();
        break;
      case 'edit_profile':
        navigateToPage('page_profile');
        break;
      case 'custom_js':
        if (comp.customJsCode) {
          try {
            // Safe evaluation or toast info
            const runner = new Function('showToast', 'navigateToPage', comp.customJsCode);
            runner(showToast, navigateToPage);
          } catch (e) {
            console.error('Custom JS execution error:', e);
            showToast(`⚠️ JS Error: ${(e as Error).message}`);
          }
        }
        break;
      case 'none':
      default:
        break;
    }
  };

  const openPasscodePrompt = (options?: {
    title?: string;
    description?: string;
    targetActionName?: string;
    onSuccess?: () => void;
  }) => {
    if (options) {
      setPasscodePromptOptions({
        title: options.title || 'Masukkan Kode Sandi',
        description:
          options.description ||
          'Pengaturan Root APK dilindungi oleh kunci aplikasi.',
        targetActionName: options.targetActionName,
      });
      if (options.onSuccess) {
        setPendingAction(() => options.onSuccess);
      }
    }
    setIsPasscodePromptOpen(true);
  };

  const closePasscodePrompt = () => {
    setIsPasscodePromptOpen(false);
    setPendingAction(null);
  };

  const verifyAndUnlock = (code: string): boolean => {
    if (code.trim() === rootConfig.appLock?.passcode?.trim()) {
      setIsUnlocked(true);
      setIsPasscodePromptOpen(false);
      showToast('🔓 Kunci aplikasi berhasil dibuka');
      if (pendingAction) {
        pendingAction();
        setPendingAction(null);
      }
      return true;
    }
    return false;
  };

  const lockNow = () => {
    setIsUnlocked(false);
    showToast('🔒 Aplikasi terkunci kembali');
  };

  const requestProtectedAction = (
    action: () => void,
    actionName = 'Tindakan Dilindungi',
    actionDescription = 'Aksi ini memerlukan verifikasi kode sandi.'
  ) => {
    if (isAppLocked) {
      openPasscodePrompt({
        title: actionName,
        description: actionDescription,
        onSuccess: action,
      });
    } else {
      action();
    }
  };

  const enableAppLock = (passcode: string, hint = '') => {
    updateRootConfig({
      appLock: {
        isEnabled: true,
        passcode,
        hint,
      },
    });
    setIsUnlocked(true);
    showToast('🔒 Kunci Aplikasi Diaktifkan');
  };

  const disableAppLock = (passcode: string): boolean => {
    if (passcode.trim() === rootConfig.appLock?.passcode?.trim()) {
      updateRootConfig({
        appLock: {
          ...rootConfig.appLock,
          isEnabled: false,
        },
      });
      setIsUnlocked(true);
      showToast('🔓 Kunci Aplikasi Dinonaktifkan');
      return true;
    }
    return false;
  };

  const changePasscode = (oldPasscode: string, newPasscode: string): boolean => {
    if (oldPasscode.trim() === rootConfig.appLock?.passcode?.trim()) {
      updateRootConfig({
        appLock: {
          ...rootConfig.appLock,
          passcode: newPasscode.trim(),
        },
      });
      showToast('🔑 Kode sandi berhasil diubah!');
      return true;
    }
    return false;
  };

  const openRootApkModal = (
    tab: 'visual_editor' | 'inspector' | 'code' | 'identitas' | 'halaman_utama' | 'tampilan' | 'font_teks' | 'warna_tema' | 'profil' | 'kunci_aplikasi' = 'visual_editor'
  ) => {
    if (isAppLocked) {
      openPasscodePrompt({
        title: 'Akses Root APK Master Control',
        description: 'Visual App Editor dan Pusat Kontrol Root dilindungi oleh kode sandi pemilik.',
        targetActionName: 'Root APK Master Control',
        onSuccess: () => {
          setRootApkInitialTab(tab);
          setIsRootApkModalOpen(true);
        },
      });
      return;
    }
    setRootApkInitialTab(tab);
    setIsRootApkModalOpen(true);
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    pushToHistory(rootConfig);
    setRootConfig((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        ...updates,
      },
    }));
    showToast('✅ Profil berhasil diperbarui');
  };

  const setAvatarFromFile = async (file: File): Promise<boolean> => {
    try {
      const dataUrl = await fileToOptimizedDataUrl(file, 400, 400, 0.85);
      updateProfile({ photoUrl: dataUrl });
      showToast('📷 Foto profil berhasil diperbarui');
      return true;
    } catch (e) {
      console.error(e);
      showToast('❌ Gagal memproses gambar foto profil');
      return false;
    }
  };

  const setWallpaperFromFile = async (file: File): Promise<boolean> => {
    try {
      const dataUrl = await fileToOptimizedDataUrl(file, 1200, 1200, 0.75);
      updateGlobalTheme({
        wallpaper: dataUrl,
        wallpaperName: file.name,
      });
      showToast('🖼 Wallpaper kustom berhasil dipasang');
      return true;
    } catch (e) {
      console.error(e);
      showToast('❌ Gagal memproses gambar wallpaper');
      return false;
    }
  };

  const setWallpaperPreset = (url: string, name: string) => {
    updateGlobalTheme({
      wallpaper: url,
      wallpaperName: name,
    });
    showToast(`🖼 Wallpaper diubah ke: ${name}`);
  };

  const setBlurLevel = (blur: BlurLevel) => {
    updateGlobalTheme({ blur });
  };

  const setCardSize = (cardSize: CardSize) => {
    updateGlobalTheme({ cardSize });
  };

  const setFontFamily = (fontFamily: FontFamilyType) => {
    updateGlobalTheme({ fontFamily });
  };

  const setFontSizePreset = (fontSizePreset: FontSizePreset) => {
    let fontSizeValue = 15;
    if (fontSizePreset === 'kecil') fontSizeValue = 13;
    if (fontSizePreset === 'besar') fontSizeValue = 17;
    updateGlobalTheme({ fontSizePreset, fontSizeValue });
  };

  const setFontSizeCustom = (fontSizeValue: number) => {
    updateGlobalTheme({ fontSizeValue });
  };

  const setLanguage = (code: LanguageCode) => {
    updateRootConfig({ language: code });
  };

  const addFamilyMember = (memberData: Omit<FamilyMember, 'id'>) => {
    const newId = `mem_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const newMember: FamilyMember = {
      ...memberData,
      id: newId,
    };
    setFamilyMembers((prev) => [...prev, newMember]);
    showToast(`✅ "${newMember.name}" berhasil ditambahkan ke silsilah`);
  };

  const deleteFamilyMember = (id: string) => {
    setFamilyMembers((prev) => prev.filter((m) => m.id !== id));
    showToast('Anggota silsilah dihapus');
  };

  const updateFamilyMember = (id: string, updates: Partial<FamilyMember>) => {
    setFamilyMembers((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...updates } : m))
    );
  };

  return (
    <AppContext.Provider
      value={{
        appMode,
        setAppMode,
        toggleAppMode,
        isFocusMode,
        setIsFocusMode,
        toggleFocusMode,
        rootConfig,
        updateRootConfig,
        updateGlobalTheme,
        exportConfigAsJson,
        downloadBackupJson,
        importConfigFromJson,
        resetToDefaultConfig,
        canUndo: undoStack.length > 0,
        canRedo: redoStack.length > 0,
        undo,
        redo,
        currentPageId,
        currentPage,
        pageHistory,
        navigateToPage,
        goBack,
        addPage,
        deletePage,
        updatePage,
        addComponentToPage,
        updateComponent,
        deleteComponent,
        duplicateComponent,
        detachComponentAction,
        moveComponentOrder,
        executeComponentAction,
        selectedPageIdInEditor,
        setSelectedPageIdInEditor,
        selectedElementIdInEditor,
        setSelectedElementIdInEditor,
        isMenuOpen,
        openMenu: () => setIsMenuOpen(true),
        closeMenu: () => setIsMenuOpen(false),
        isMainSettingsModalOpen,
        openMainSettingsModal: () => setIsMainSettingsModalOpen(true),
        closeMainSettingsModal: () => setIsMainSettingsModalOpen(false),
        isLanguageModalOpen,
        openLanguageModal: () => setIsLanguageModalOpen(true),
        closeLanguageModal: () => setIsLanguageModalOpen(false),
        setLanguage,
        t,
        isNoteImportModalOpen,
        openNoteImportModal: () => setIsNoteImportModalOpen(true),
        closeNoteImportModal: () => setIsNoteImportModalOpen(false),
        isRootApkModalOpen,
        rootApkInitialTab,
        openRootApkModal,
        closeRootApkModal: () => setIsRootApkModalOpen(false),
        isPageSettingsModalOpen,
        openPageSettingsModal: () => {
          if (isAppLocked) {
            openPasscodePrompt({
              title: 'Buka Pengaturan Halaman',
              description: 'Pengaturan struktur halaman memerlukan otorisasi sandi pemilik.',
              targetActionName: 'Pengaturan Halaman',
              onSuccess: () => setIsPageSettingsModalOpen(true),
            });
            return;
          }
          setIsPageSettingsModalOpen(true);
        },
        closePageSettingsModal: () => setIsPageSettingsModalOpen(false),
        editingComponent,
        openComponentEditor: (pageId, comp) => {
          if (isAppLocked) {
            openPasscodePrompt({
              title: 'Buka Editor Komponen',
              description: 'Mengubah struktur, posisi, atau fungsi komponen memerlukan sandi.',
              targetActionName: 'Editor Komponen',
              onSuccess: () => setEditingComponent({ pageId, comp }),
            });
            return;
          }
          setEditingComponent({ pageId, comp });
        },
        closeComponentEditor: () => setEditingComponent(null),
        isUnlocked,
        isAppLocked,
        isPasscodePromptOpen,
        passcodePromptOptions,
        openPasscodePrompt,
        closePasscodePrompt,
        verifyAndUnlock,
        lockNow,
        requestProtectedAction,
        enableAppLock,
        disableAppLock,
        changePasscode,
        isBasicWallpaperModalOpen,
        openBasicWallpaperModal: () => setIsBasicWallpaperModalOpen(true),
        closeBasicWallpaperModal: () => setIsBasicWallpaperModalOpen(false),
        isBasicThemeModalOpen,
        openBasicThemeModal: () => setIsBasicThemeModalOpen(true),
        closeBasicThemeModal: () => setIsBasicThemeModalOpen(false),
        isBasicFontModalOpen,
        openBasicFontModal: () => setIsBasicFontModalOpen(true),
        closeBasicFontModal: () => setIsBasicFontModalOpen(false),
        profile,
        updateProfile,
        setAvatarFromFile,
        setWallpaperFromFile,
        setWallpaperPreset,
        setBlurLevel,
        setCardSize,
        setFontFamily,
        setFontSizePreset,
        setFontSizeCustom,
        familyMembers,
        addFamilyMember,
        deleteFamilyMember,
        updateFamilyMember,
        activePersonModal,
        openPersonModal: (m) => setActivePersonModal(m),
        closePersonModal: () => setActivePersonModal(null),
        toastMessage,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
