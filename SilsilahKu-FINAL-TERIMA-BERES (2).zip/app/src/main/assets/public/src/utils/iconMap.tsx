import React from 'react';
import {
  Compass,
  Network,
  History,
  GitFork,
  BookMarked,
  User,
  Heart,
  Sparkles,
  Shield,
  Calendar,
  MapPin,
  Layers,
  Star,
  Folder,
  TreePine,
  Feather,
  Scroll,
  Award,
  BookOpen,
  Settings,
  Share2,
  Users,
  Home,
  Tag,
  ChevronRight,
  ArrowRight,
  Info,
  Circle,
  Clock,
  Compass as CompassIcon,
  Archive,
  Flag,
  Globe,
  Sliders,
  Maximize2,
  Palette,
  FileText,
  HelpCircle,
} from 'lucide-react';

export const AVAILABLE_ICONS: { id: string; label: string; icon: React.ElementType }[] = [
  { id: 'Compass', label: 'Kompas (Genealogy)', icon: Compass },
  { id: 'Network', label: 'Jejaring (Family Tree)', icon: Network },
  { id: 'History', label: 'Sejarah (Ancestry)', icon: History },
  { id: 'GitFork', label: 'Cabang (Lineage)', icon: GitFork },
  { id: 'BookMarked', label: 'Buku Arsip (Data Silsilah)', icon: BookMarked },
  { id: 'User', label: 'Orang / Profil', icon: User },
  { id: 'Users', label: 'Keluarga Besar', icon: Users },
  { id: 'TreePine', label: 'Pohon Silsilah', icon: TreePine },
  { id: 'Scroll', label: 'Naskah Kuno / Babad', icon: Scroll },
  { id: 'Feather', label: 'Pena Pusaka', icon: Feather },
  { id: 'Award', label: 'Gelar / Kehormatan', icon: Award },
  { id: 'Heart', label: 'Hubungan Pernikahan', icon: Heart },
  { id: 'Sparkles', label: 'Istimewa / Sorotan', icon: Sparkles },
  { id: 'Shield', label: 'Lambang / Perisai Trah', icon: Shield },
  { id: 'Calendar', label: 'Tahun / Era Waktu', icon: Calendar },
  { id: 'Clock', label: 'Kronologi Waktu', icon: Clock },
  { id: 'MapPin', label: 'Lokasi Leluhur', icon: MapPin },
  { id: 'Layers', label: 'Tingkat Generasi', icon: Layers },
  { id: 'Star', label: 'Bintang Utama', icon: Star },
  { id: 'Folder', label: 'Berkas Dokumen', icon: Folder },
  { id: 'FileText', label: 'Catatan Riwayat', icon: FileText },
  { id: 'Archive', label: 'Kotak Pusaka', icon: Archive },
  { id: 'Home', label: 'Rumah Asal', icon: Home },
  { id: 'Globe', label: 'Wilayah / Diaspora', icon: Globe },
  { id: 'Settings', label: 'Pengaturan', icon: Settings },
  { id: 'Sliders', label: 'Kontrol / Konfigurasi', icon: Sliders },
  { id: 'Palette', label: 'Warna / Estetika', icon: Palette },
  { id: 'Info', label: 'Informasi', icon: Info },
  { id: 'ArrowRight', label: 'Panah Lanjut', icon: ArrowRight },
  { id: 'Tag', label: 'Label Trah', icon: Tag },
];

export const renderIconByName = (
  iconName?: string,
  className = 'w-5 h-5',
  fallback: React.ElementType = Sparkles
): React.ReactNode => {
  if (!iconName) {
    const Fallback = fallback;
    return <Fallback className={className} />;
  }

  const found = AVAILABLE_ICONS.find(
    (item) => item.id.toLowerCase() === iconName.toLowerCase()
  );

  if (found) {
    const IconComp = found.icon;
    return <IconComp className={className} />;
  }

  // Fallback to Sparkles
  return <Sparkles className={className} />;
};
