import { FamilyMember } from '../types';

/**
 * Calculates Damerau-Levenshtein Distance between two strings.
 * Handles insertion, deletion, substitution, and transposition of two adjacent characters.
 */
export function damerauLevenshteinDistance(source: string, target: string): number {
  const s = source.toLowerCase().trim();
  const t = target.toLowerCase().trim();

  if (s === t) return 0;
  if (s.length === 0) return t.length;
  if (t.length === 0) return s.length;

  const m = s.length;
  const n = t.length;
  const d: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) d[i][0] = i;
  for (let j = 0; j <= n; j++) d[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = s[i - 1] === t[j - 1] ? 0 : 1;
      d[i][j] = Math.min(
        d[i - 1][j] + 1,      // deletion
        d[i][j - 1] + 1,      // insertion
        d[i - 1][j - 1] + cost // substitution
      );

      // Transposition
      if (i > 1 && j > 1 && s[i - 1] === t[j - 2] && s[i - 2] === t[j - 1]) {
        d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
      }
    }
  }

  return d[m][n];
}

/**
 * Computes word-level and substring similarity score (0.0 to 1.0).
 */
export function calculateFuzzyScore(query: string, candidate: string): { score: number; isExactOrPrefix: boolean } {
  const q = query.toLowerCase().trim();
  const c = candidate.toLowerCase().trim();

  if (!q || !c) return { score: 0, isExactOrPrefix: false };

  // 1. Exact match
  if (q === c) return { score: 1.0, isExactOrPrefix: true };

  // 2. Starts with / Prefix
  if (c.startsWith(q)) return { score: 0.95, isExactOrPrefix: true };

  // 3. Substring inclusion
  if (c.includes(q)) return { score: 0.88, isExactOrPrefix: true };

  // 4. Word-by-word match
  const candidateWords = c.split(/\s+/);
  for (const word of candidateWords) {
    if (word === q) return { score: 0.92, isExactOrPrefix: true };
    if (word.startsWith(q)) return { score: 0.85, isExactOrPrefix: true };
  }

  // 5. Typo tolerance using Damerau-Levenshtein
  // Compare query against each candidate word, and against candidate as a whole
  let bestDistance = damerauLevenshteinDistance(q, c);

  for (const word of candidateWords) {
    const dist = damerauLevenshteinDistance(q, word);
    if (dist < bestDistance) {
      bestDistance = dist;
    }
  }

  // If query is short (<= 3 chars), allow at most 1 typo
  // If query is longer, allow up to 2 typos
  const maxAllowedDistance = q.length <= 3 ? 1 : q.length <= 6 ? 2 : 3;

  if (bestDistance <= maxAllowedDistance) {
    // Normalization score based on length
    const score = Math.max(0.4, 0.82 - (bestDistance * 0.15));
    return { score, isExactOrPrefix: false };
  }

  return { score: 0, isExactOrPrefix: false };
}

export interface FuzzySearchResult {
  member: FamilyMember;
  score: number;
  isTypoMatch: boolean;
  matchField: string;
}

/**
 * Searches family members with typo tolerance and ranks results.
 */
export function searchFamilyMembers(
  query: string,
  members: FamilyMember[],
  limit = 8
): FuzzySearchResult[] {
  const q = query.trim();
  if (!q || q.length < 2) return [];

  const results: FuzzySearchResult[] = [];

  for (const member of members) {
    let highestScore = 0;
    let bestField = 'Nama';
    let isTypo = false;

    // Check main name
    const nameMatch = calculateFuzzyScore(q, member.name);
    if (nameMatch.score > highestScore) {
      highestScore = nameMatch.score;
      bestField = 'Nama';
      isTypo = !nameMatch.isExactOrPrefix;
    }

    // Check alternate names
    if (member.altNames) {
      for (const alt of member.altNames) {
        const altMatch = calculateFuzzyScore(q, alt);
        if (altMatch.score > highestScore) {
          highestScore = altMatch.score;
          bestField = `Nama Lain (${alt})`;
          isTypo = !altMatch.isExactOrPrefix;
        }
      }
    }

    // Check title / Gelar
    if (member.title) {
      const titleMatch = calculateFuzzyScore(q, member.title);
      if (titleMatch.score > highestScore) {
        highestScore = titleMatch.score;
        bestField = 'Gelar';
        isTypo = !titleMatch.isExactOrPrefix;
      }
    }

    // Check birth place / residence
    if (member.birthPlace) {
      const placeMatch = calculateFuzzyScore(q, member.birthPlace);
      if (placeMatch.score > highestScore) {
        highestScore = placeMatch.score;
        bestField = 'Tempat Lahir';
        isTypo = !placeMatch.isExactOrPrefix;
      }
    }

    // Only include if score meets threshold
    if (highestScore >= 0.45) {
      results.push({
        member,
        score: highestScore,
        isTypoMatch: isTypo,
        matchField: bestField,
      });
    }
  }

  // Sort by highest score first, then generation
  results.sort((a, b) => b.score - a.score || a.member.generation - b.member.generation);

  return results.slice(0, limit);
}
