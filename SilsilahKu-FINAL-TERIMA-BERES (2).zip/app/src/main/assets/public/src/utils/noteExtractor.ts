export interface ExtractedPersonCandidate {
  name: string;
  gender: 'Laki-laki' | 'Perempuan';
  generation?: number;
  fatherName?: string;
  motherName?: string;
  spouseName?: string;
  childrenNames?: string[];
  birthYear?: string;
  deathYear?: string;
  birthPlace?: string;
  occupation?: string;
  biography: string;
  notes: string;
  sources?: string;
}

/**
 * Intelligent natural language parser for Indonesian & English genealogy notes.
 * Extracts candidate persons and parent-child relationships.
 */
export function extractPersonFromNote(text: string): ExtractedPersonCandidate {
  const cleanText = text.trim();
  const lower = cleanText.toLowerCase();

  const candidate: ExtractedPersonCandidate = {
    name: '',
    gender: 'Laki-laki',
    biography: cleanText,
    notes: cleanText,
    childrenNames: [],
  };

  // 1. Extract Name & Father/Parent
  // Patterns like: "[Name] adalah anak [Father]" or "[Name] putra [Father]" or "[Name] putri [Mother/Father]"
  const patternChildOf = /([A-Z][a-zA-Z\s]{1,30})\s+(?:adalah\s+)?(?:anak|putra|putri|keturunan|son of|daughter of|child of)\s+(?:dari\s+)?([A-Z][a-zA-Z\s]{1,30})/i;
  const matchChild = cleanText.match(patternChildOf);

  if (matchChild) {
    candidate.name = matchChild[1].trim();
    const parentName = matchChild[2].replace(/(?:dan|and|\.|\,).*/i, '').trim();
    candidate.fatherName = parentName;

    // Check gender hint from "putri" or "daughter"
    if (/putri|daughter|perempuan/i.test(matchChild[0])) {
      candidate.gender = 'Perempuan';
    }
  }

  // Fallback pattern: "Nama: [Name]"
  const patternExplicitName = /(?:nama|name)\s*:\s*([A-Z][a-zA-Z\s]{1,35})/i;
  const matchExplicitName = cleanText.match(patternExplicitName);
  if (matchExplicitName) {
    candidate.name = matchExplicitName[1].trim();
  }

  // If name still empty, grab first capitalized phrase before punctuation
  if (!candidate.name) {
    const firstWordMatch = cleanText.match(/^([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,2})/);
    if (firstWordMatch) {
      candidate.name = firstWordMatch[1].trim();
    } else {
      candidate.name = 'Tokoh Baru';
    }
  }

  // 2. Extract Father if not found yet
  // Pattern: "ayah(?:nya)? (?:adalah )?([A-Z][a-zA-Z\s]+)" or "father: [Name]"
  const patternFather = /(?:ayah(?:nya)?|father)\s*(?:adalah|is|:)?\s*([A-Z][a-zA-Z\s]{1,30})/i;
  const matchFather = cleanText.match(patternFather);
  if (matchFather && !candidate.fatherName) {
    candidate.fatherName = matchFather[1].replace(/(?:dan|and|\.|\,).*/i, '').trim();
  }

  // 3. Extract Mother
  // Pattern: "ibu(?:nya)? (?:adalah )?([A-Z][a-zA-Z\s]+)" or "dan [Ibu]"
  const patternMother = /(?:ibu(?:nya)?|mother)\s*(?:adalah|is|:)?\s*([A-Z][a-zA-Z\s]{1,30})/i;
  const matchMother = cleanText.match(patternMother);
  if (matchMother) {
    candidate.motherName = matchMother[1].replace(/(?:dan|and|\.|\,).*/i, '').trim();
  }

  // Check joint parent pattern: "anak [Ayah] dan [Ibu]"
  const patternBothParents = /(?:anak|putra|putri)\s+(?:dari\s+)?([A-Z][a-zA-Z]+)\s+(?:dan|and)\s+([A-Z][a-zA-Z]+)/i;
  const matchBoth = cleanText.match(patternBothParents);
  if (matchBoth) {
    candidate.fatherName = matchBoth[1].trim();
    candidate.motherName = matchBoth[2].trim();
  }

  // 4. Extract Spouse
  const patternSpouse = /(?:istri|suami|pasangan|menikah dengan|spouse|married to)\s*(?:adalah|is|:)?\s*([A-Z][a-zA-Z\s]{1,30})/i;
  const matchSpouse = cleanText.match(patternSpouse);
  if (matchSpouse) {
    candidate.spouseName = matchSpouse[1].replace(/(?:dan|and|\.|\,).*/i, '').trim();
  }

  // 5. Extract Children
  const patternChildren = /(?:memiliki anak|anak-anaknya|punya anak|children|sons|daughters)\s*(?:adalah|is|:|yaitu)?\s*([^.]+)/i;
  const matchChildren = cleanText.match(patternChildren);
  if (matchChildren) {
    const listStr = matchChildren[1];
    const items = listStr
      .split(/,|dan|and|;/)
      .map((s) => s.trim().replace(/^antara lain/i, '').trim())
      .filter((s) => s.length > 1 && s.length < 35 && /^[A-Z]/.test(s));
    candidate.childrenNames = items;
  }

  // 6. Extract Birth Year
  // Pattern: "lahir (?:pada )?(?:tahun )?([0-9]{1,4}(?:\s*(?:SM|BC|M|AD))?)"
  const patternBirthYear = /(?:lahir|born)\s*(?:pada\s+)?(?:tahun\s+)?([0-9]{1,4}\s*(?:SM|BC|M|AD)?)/i;
  const matchBirth = cleanText.match(patternBirthYear);
  if (matchBirth) {
    candidate.birthYear = matchBirth[1].trim();
  }

  // 7. Extract Death Year
  const patternDeathYear = /(?:meninggal|wafat|died)\s*(?:pada\s+)?(?:tahun\s+)?([0-9]{1,4}\s*(?:SM|BC|M|AD)?)/i;
  const matchDeath = cleanText.match(patternDeathYear);
  if (matchDeath) {
    candidate.deathYear = matchDeath[1].trim();
  }

  // 8. Extract Place
  const patternPlace = /(?:di\s+|in\s+)([A-Z][a-zA-Z\s]{2,25}(?:Mesopotamia|Kanaan|Yerusalem|Yogyakarta|Betlehem|Mesir|Sikhem|Hebron|Ur|Bantul|Surakarta))/i;
  const matchPlace = cleanText.match(patternPlace);
  if (matchPlace) {
    candidate.birthPlace = matchPlace[1].trim();
  }

  // 9. Extract Occupation
  const patternOcc = /(?:seorang|bekerja sebagai|profesi|pekerjaan)\s+([a-zA-Z\s]{3,30})/i;
  const matchOcc = cleanText.match(patternOcc);
  if (matchOcc) {
    candidate.occupation = matchOcc[1].replace(/(?:yang|\.|\,).*/i, '').trim();
  }

  return candidate;
}
