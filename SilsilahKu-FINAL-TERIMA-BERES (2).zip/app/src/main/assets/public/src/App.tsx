/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { BackgroundLayer } from './components/BackgroundLayer';
import { TopHeader } from './components/TopHeader';
import { NavigationDrawer } from './components/NavigationDrawer';
import { Toast } from './components/Toast';

// Modals
import { ComponentEditorModal } from './components/ComponentEditorModal';
import { PageSettingsModal } from './components/PageSettingsModal';
import { RootApkSettingsModal } from './components/RootApkSettingsModal';
import { PasscodePromptModal } from './components/PasscodePromptModal';
import {
  BasicWallpaperModal,
  BasicThemeModal,
  BasicFontModal,
} from './components/BasicSettingsModals';
import { MainSettingsModal } from './components/MainSettingsModal';
import { LanguageModal } from './components/LanguageModal';
import { NoteImportModal } from './components/NoteImportModal';

// Dynamic Page Engine
import { DynamicPageView } from './views/DynamicPageView';

const MainLayout: React.FC = () => {
  const { rootConfig, currentPage, isNoteImportModalOpen, closeNoteImportModal } = useApp();
  const theme = rootConfig.globalTheme;

  // Determine current font family class
  const getFontFamilyClass = () => {
    switch (theme.fontFamily) {
      case 'cinzel':
        return 'font-cinzel';
      case 'playfair':
        return 'font-playfair';
      case 'lora':
        return 'font-lora';
      case 'typewriter':
        return 'font-typewriter';
      case 'plus-jakarta':
      default:
        return 'font-plus-jakarta';
    }
  };

  const is5Cards = currentPage.layoutType === '5_vertical_cards';

  return (
    <div
      className={`relative w-screen h-screen ${getFontFamilyClass()} transition-colors duration-300 flex flex-col justify-between overflow-hidden select-none`}
      style={{
        fontSize: `${theme.fontSizeValue}px`,
      }}
    >
      {/* Dynamic Background with Live Blur */}
      <BackgroundLayer />

      {/* Top Header with ☰ Menu, ← Kembali, Mode Switcher (👁 Preview / ⚙ Editor), and Profile */}
      <TopHeader />

      {/* Slide Navigation Drawer */}
      <NavigationDrawer />

      {/* Core Dynamic Page Engine */}
      <div
        className={`flex-1 min-h-0 w-full flex flex-col ${
          is5Cards ? 'overflow-hidden' : 'overflow-y-auto'
        }`}
      >
        <DynamicPageView />
      </div>

      {/* Component Property Inspector / Editor Modal */}
      <ComponentEditorModal />

      {/* Page Configuration Modal */}
      <PageSettingsModal />

      {/* Master Hub: Pengaturan Root APK */}
      <RootApkSettingsModal />

      {/* Security: Passcode Prompt Modal */}
      <PasscodePromptModal />

      {/* Tier 1 Basic Settings Modals (Accessible without passcode) */}
      <BasicWallpaperModal />
      <BasicThemeModal />
      <BasicFontModal />

      {/* Main Settings Modal & Language Selector Modal */}
      <MainSettingsModal />
      <LanguageModal />

      {/* Note Import Modal */}
      <NoteImportModal isOpen={isNoteImportModalOpen} onClose={closeNoteImportModal} />

      {/* Toast Feedback */}
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
