import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ChevronRight,
  Globe,
  Lock,
  Sliders,
  Type,
  Palette,
  Image as ImageIcon,
  User,
  Eye,
  Settings,
  RotateCcw,
  AlertTriangle,
  Layers,
  Download,
  FolderArchive,
} from 'lucide-react';
import { LANGUAGES } from '../utils/i18n';
import { PWAInstallButton } from './PWAInstallButton';

export const MainSettingsModal: React.FC = () => {
  const {
    isMainSettingsModalOpen,
    closeMainSettingsModal,
    openLanguageModal,
    openBasicFontModal,
    openBasicThemeModal,
    openBasicWallpaperModal,
    openRootApkModal,
    navigateToPage,
    rootConfig,
    appMode,
    toggleAppMode,
    resetToDefaultConfig,
    showToast,
    t,
  } = useApp();

  const [confirmReset, setConfirmReset] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownloadZip = async (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    if (isDownloading) return;
    setIsDownloading(true);
    showToast('⏳ Sedang memproses pengunduhan file ZIP...');

    try {
      const response = await fetch('/SilsilahKu-Final-Source.zip', {
        headers: { 'Cache-Control': 'no-cache' }
      });
      if (!response.ok) {
        throw new Error('Gagal mengambil file ZIP dari server');
      }
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const tempLink = document.createElement('a');
      tempLink.style.display = 'none';
      tempLink.href = blobUrl;
      tempLink.setAttribute('download', 'SilsilahKu-Final-Source.zip');
      document.body.appendChild(tempLink);
      tempLink.click();
      
      setTimeout(() => {
        document.body.removeChild(tempLink);
        window.URL.revokeObjectURL(blobUrl);
      }, 500);

      showToast('✅ Berhasil! File SilsilahKu-Final-Source.zip sedang diunduh.');
    } catch (error) {
      console.warn('Direct blob download fallback to window.location:', error);
      window.location.href = '/SilsilahKu-Final-Source.zip';
    } finally {
      setIsDownloading(false);
    }
  };

  if (!isMainSettingsModalOpen) return null;

  const currentLangObj = LANGUAGES.find((l) => l.code === (rootConfig.language || 'id')) || LANGUAGES[0];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-sm bg-stone-900 border border-stone-800 rounded-2xl shadow-xl overflow-hidden text-stone-100 flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-stone-950/80">
          <h3 className="text-sm font-bold text-stone-100">{t('settings')}</h3>
          <button
            onClick={closeMainSettingsModal}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* List Items */}
        <div className="p-3 overflow-y-auto space-y-1 text-xs font-semibold">
          {/* Master Visual App Editor & Root APK */}
          <button
            type="button"
            onClick={() => {
              closeMainSettingsModal();
              openRootApkModal('visual_editor');
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-amber-950/50 hover:bg-amber-900/60 text-amber-300 border border-amber-500/40 transition-colors cursor-pointer flex items-center justify-between text-left shadow-sm"
          >
            <div className="flex items-center gap-2.5">
              <Sliders className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <span className="block font-bold">🛠 Visual App Editor</span>
                <span className="block text-[10px] text-amber-300/80 font-normal">
                  Pusat Kontrol & Editor Visual Seluruh Aplikasi
                </span>
              </div>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-amber-400" />
          </button>

          {/* Bahasa / Language */}
          <button
            type="button"
            onClick={() => {
              closeMainSettingsModal();
              openLanguageModal();
            }}
            className="w-full py-2 px-3 rounded-xl hover:bg-stone-800/70 text-stone-200 transition-colors cursor-pointer flex items-center justify-between text-left"
          >
            <div className="flex items-center gap-2.5">
              <Globe className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{t('language')}</span>
            </div>
            <div className="flex items-center gap-1 text-stone-400 text-[11px]">
              <span>{currentLangObj.nativeName}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </button>

          {/* Mode Editor / Preview Switcher */}
          <div className="w-full py-2 px-3 rounded-xl bg-stone-950/40 border border-stone-800/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {appMode === 'editor' ? (
                <Settings className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '8s' }} />
              ) : (
                <Eye className="w-4 h-4 text-amber-400" />
              )}
              <div>
                <span className="block text-stone-200">{t('editorMode')}</span>
                <span className="block text-[10px] text-stone-400 font-normal">
                  {appMode === 'editor' ? 'Mode Editor Visual Aktif' : 'Tampilan Pengguna Biasa'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={toggleAppMode}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                appMode === 'editor'
                  ? 'bg-amber-600 text-stone-950'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
              }`}
            >
              {appMode === 'editor' ? 'ON' : 'OFF'}
            </button>
          </div>

          {/* Profil */}
          <button
            type="button"
            onClick={() => {
              closeMainSettingsModal();
              navigateToPage('page_profile');
            }}
            className="w-full py-2 px-3 rounded-xl hover:bg-stone-800/70 text-stone-200 transition-colors cursor-pointer flex items-center justify-between text-left"
          >
            <div className="flex items-center gap-2.5">
              <User className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{t('profile')}</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-stone-500" />
          </button>

          {/* Font & Teks */}
          <button
            type="button"
            onClick={() => {
              closeMainSettingsModal();
              openBasicFontModal();
            }}
            className="w-full py-2 px-3 rounded-xl hover:bg-stone-800/70 text-stone-200 transition-colors cursor-pointer flex items-center justify-between text-left"
          >
            <div className="flex items-center gap-2.5">
              <Type className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{t('fontAndText')}</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-stone-500" />
          </button>

          {/* Warna & Tema */}
          <button
            type="button"
            onClick={() => {
              closeMainSettingsModal();
              openBasicThemeModal();
            }}
            className="w-full py-2 px-3 rounded-xl hover:bg-stone-800/70 text-stone-200 transition-colors cursor-pointer flex items-center justify-between text-left"
          >
            <div className="flex items-center gap-2.5">
              <Palette className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{t('colorAndTheme')}</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-stone-500" />
          </button>

          {/* Wallpaper */}
          <button
            type="button"
            onClick={() => {
              closeMainSettingsModal();
              openBasicWallpaperModal();
            }}
            className="w-full py-2 px-3 rounded-xl hover:bg-stone-800/70 text-stone-200 transition-colors cursor-pointer flex items-center justify-between text-left"
          >
            <div className="flex items-center gap-2.5">
              <ImageIcon className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{t('wallpaper')}</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-stone-500" />
          </button>

          {/* Kunci Aplikasi */}
          <button
            type="button"
            onClick={() => {
              closeMainSettingsModal();
              openRootApkModal('kunci_aplikasi');
            }}
            className="w-full py-2 px-3 rounded-xl hover:bg-stone-800/70 text-stone-200 transition-colors cursor-pointer flex items-center justify-between text-left"
          >
            <div className="flex items-center gap-2.5">
              <Lock className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{t('appLock')}</span>
            </div>
            <div className="flex items-center gap-1 text-[10px] font-mono text-stone-400">
              <span>{rootConfig.appLock?.isEnabled ? '🔒' : '🔓'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </button>

          {/* PWA Mobile App Install Button */}
          <PWAInstallButton variant="modal" />

          {/* 🌟 SATU ZIP PROJECT LENGKAP (CAPACITOR ANDROID NATIVE READY) */}
          <a
            href="/SilsilahKu-Capacitor-Android-FullProject.zip"
            download="SilsilahKu-Capacitor-Android-FullProject.zip"
            onClick={() => showToast('Mengunduh FULL PROJECT ZIP (SilsilahKu-Capacitor-Android-FullProject.zip)...')}
            className="w-full py-3.5 px-3.5 rounded-xl bg-gradient-to-r from-amber-500/40 via-yellow-500/30 to-amber-600/40 hover:from-amber-500/55 hover:to-amber-600/55 text-amber-200 border-2 border-amber-400 font-black flex items-center justify-between text-left transition-all cursor-pointer shadow-xl active:scale-98 my-1.5"
          >
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-lg bg-amber-400 text-stone-950 font-black shadow">
                <FolderArchive className="w-5 h-5 shrink-0" />
              </div>
              <div>
                <span className="block text-xs font-black text-amber-300">
                  ⭐ SATU ZIP PROJECT LENGKAP (CAPACITOR NATIVE)
                </span>
                <span className="block text-[10px] text-amber-200/90 font-mono">
                  SilsilahKu-Capacitor-Android-FullProject.zip
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-400 text-stone-950 font-black text-xs shadow-md">
              <Download className="w-4 h-4" />
              <span>UNDUH</span>
            </div>
          </a>

          {/* Unduh File Siap Jadi APK (App-Ready ZIP) */}
          <a
            href="/SilsilahKu-App-Ready.zip"
            download="SilsilahKu-App-Ready.zip"
            onClick={() => showToast('Mengunduh SilsilahKu-App-Ready.zip...')}
            className="w-full py-2.5 px-3 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-200 border border-emerald-500/50 font-semibold flex items-center justify-between text-left transition-all cursor-pointer shadow active:scale-98 my-1"
          >
            <div className="flex items-center gap-2">
              <Download className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <span className="block text-xs font-bold text-emerald-300">
                  📱 HTML Web App Build (dist)
                </span>
                <span className="block text-[9px] text-emerald-400/80 font-mono">
                  SilsilahKu-App-Ready.zip
                </span>
              </div>
            </div>
            <span className="text-[10px] font-bold text-emerald-400">Unduh</span>
          </a>

          {/* Unduh Source Code Project ZIP */}
          <a
            href="/SilsilahKu-Final-Source.zip"
            download="SilsilahKu-Final-Source.zip"
            onClick={handleDownloadZip}
            className="w-full py-2.5 px-3 rounded-xl bg-stone-900/80 hover:bg-stone-800 text-stone-300 border border-stone-700/60 font-medium flex items-center justify-between text-left transition-all cursor-pointer shadow active:scale-98 my-1"
          >
            <div className="flex items-center gap-2">
              <FolderArchive className="w-4 h-4 text-stone-400 shrink-0" />
              <div>
                <span className="block text-xs font-semibold text-stone-300">
                  📦 Master Source Code
                </span>
                <span className="block text-[9px] text-stone-400 font-mono">
                  SilsilahKu-Final-Source.zip
                </span>
              </div>
            </div>
            <span className="text-[10px] font-bold text-stone-400">Unduh</span>
          </a>

          {/* Factory Reset button as required in Requirement 16 */}
          <div className="pt-2 border-t border-stone-800">
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="w-full py-2 px-3 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>↻ Kembali ke Setelan Pabrik</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2 border-t border-stone-800 bg-stone-950/80 flex justify-end">
          <button
            onClick={closeMainSettingsModal}
            className="px-4 py-1 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs cursor-pointer"
          >
            {t('close')}
          </button>
        </div>
      </div>

      {/* Confirmation modal for Factory Reset */}
      {confirmReset && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85">
          <div className="w-full max-w-sm bg-stone-900 border border-rose-800 rounded-2xl p-5 shadow-2xl space-y-3 text-xs">
            <h4 className="text-sm font-bold text-rose-400 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              <span>Konfirmasi Reset Setelan Pabrik</span>
            </h4>
            <p className="text-stone-300 leading-relaxed">
              Apakah Anda yakin ingin mengembalikan seluruh aplikasi ke setelan standar pabrik? Konfigurasi tata letak, halaman baru, dan elemen yang telah Anda sesuaikan akan dikembalikan ke pengaturan awal.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-300"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  resetToDefaultConfig();
                  setConfirmReset(false);
                  closeMainSettingsModal();
                }}
                className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
              >
                Ya, Reset Sekarang
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
