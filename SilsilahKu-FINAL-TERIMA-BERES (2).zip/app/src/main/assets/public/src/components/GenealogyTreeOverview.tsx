import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { FamilyMember } from '../types';
import { DEFAULT_GENEALOGY_CONFIG } from '../data/initialData';
import { PersonDetailModal } from './PersonDetailModal';
import { GenealogySettingsModal } from './GenealogySettingsModal';
import { NoteImportModal } from './NoteImportModal';
import {
  Search,
  ChevronDown,
  User,
  Plus,
  Maximize2,
  Sliders,
  X,
} from 'lucide-react';

interface TreeNodeData {
  member: FamilyMember;
  children: TreeNodeData[];
  depth: number;
}

export const GenealogyTreeOverview: React.FC = () => {
  const { familyMembers, rootConfig, updateRootConfig, showToast, isFocusMode, t } = useApp();
  const config = {
    ...DEFAULT_GENEALOGY_CONFIG,
    ...(rootConfig.genealogyDisplay || {}),
  };

  // Zoom scale level (100% = 1.0)
  const [zoomScale, setZoomScale] = useState<number>(1.0);

  // Single Floating Control Panel State (Hidden by default as requested)
  const [isControlsPanelOpen, setIsControlsPanelOpen] = useState(false);

  // Default root member
  const defaultRootId = useMemo(() => {
    const yakub = familyMembers.find((m) => m.id === 'yakub');
    if (yakub) return yakub.id;
    const adam = familyMembers.find((m) => m.id === 'adam');
    if (adam) return adam.id;
    const gen1 = familyMembers.find((m) => m.generation === 1);
    if (gen1) return gen1.id;
    return familyMembers[0]?.id || '';
  }, [familyMembers]);

  const [selectedRootId, setSelectedRootId] = useState<string>(defaultRootId);
  const [rootSearchQuery, setRootSearchQuery] = useState('');
  const [isRootDropdownOpen, setIsRootDropdownOpen] = useState(false);

  // Detail Modal State
  const [detailPerson, setDetailPerson] = useState<FamilyMember | null>(null);

  // Settings Modal State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Note Import Modal State
  const [isNoteImportOpen, setIsNoteImportOpen] = useState(false);

  // Expanded nodes map
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(() => {
    const initialSet = new Set<string>();
    familyMembers.forEach((m) => {
      initialSet.add(m.id);
    });
    return initialSet;
  });

  const toggleNode = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setExpandedNodes((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const expandAll = () => {
    const allIds = new Set(familyMembers.map((m) => m.id));
    setExpandedNodes(allIds);
    showToast('Seluruh cabang silsilah dibuka');
  };

  const handleZoomIn = () => {
    setZoomScale((prev) => Math.min(2.5, Math.round((prev + 0.15) * 100) / 100));
  };

  const handleZoomOut = () => {
    setZoomScale((prev) => Math.max(0.4, Math.round((prev - 0.15) * 100) / 100));
  };

  const handleZoomReset = () => {
    setZoomScale(1.0);
    showToast('Fit to Screen (100%)');
  };

  const rootMember = useMemo(() => {
    return (
      familyMembers.find((m) => m.id === selectedRootId) ||
      familyMembers.find((m) => m.id === defaultRootId) ||
      familyMembers[0]
    );
  }, [familyMembers, selectedRootId, defaultRootId]);

  const treeData = useMemo(() => {
    if (!rootMember) return null;

    const maxDepthNum = config.maxDepth === 'all' ? 99 : Number(config.maxDepth);
    const visited = new Set<string>();

    const buildSubTree = (member: FamilyMember, currentDepth: number): TreeNodeData => {
      visited.add(member.id);

      let childMembers: FamilyMember[] = [];
      if (currentDepth < maxDepthNum) {
        childMembers = familyMembers.filter((m) => {
          if (visited.has(m.id)) return false;
          const isDirectChild =
            m.fatherId === member.id ||
            m.motherId === member.id ||
            (member.childrenIds && member.childrenIds.includes(m.id));
          return isDirectChild;
        });

        childMembers.sort((a, b) => {
          const yearA = parseInt(a.birthYear.replace(/[^0-9]/g, '')) || 0;
          const yearB = parseInt(b.birthYear.replace(/[^0-9]/g, '')) || 0;
          return yearA - yearB;
        });
      }

      return {
        member,
        depth: currentDepth,
        children: childMembers.map((child) => buildSubTree(child, currentDepth + 1)),
      };
    };

    return buildSubTree(rootMember, 1);
  }, [rootMember, familyMembers, config.maxDepth]);

  const quickRootPresets = useMemo(() => {
    const targetKeys = ['yakub', 'adam', 'abraham', 'ishak', 'mem-1', 'mem-5', 'lewi', 'yehuda'];
    return familyMembers.filter((m) => targetKeys.includes(m.id));
  }, [familyMembers]);

  const searchRootResults = useMemo(() => {
    if (!rootSearchQuery.trim()) return familyMembers.slice(0, 15);
    const q = rootSearchQuery.toLowerCase();
    return familyMembers.filter(
      (m) =>
        m.name.toLowerCase().includes(q) ||
        (m.title && m.title.toLowerCase().includes(q)) ||
        (m.altNames && m.altNames.some((alt) => alt.toLowerCase().includes(q)))
    );
  }, [familyMembers, rootSearchQuery]);

  // Render Outline Tree (├──→ └──→ concept)
  const renderOutlineTreeNode = (node: TreeNodeData, isLastChild: boolean = false) => {
    const isExpanded = expandedNodes.has(node.member.id);
    const hasChildren = node.children.length > 0;
    const isMale = node.member.gender === 'Laki-laki';
    const isRoot = node.depth === 1;

    const spouse =
      config.showSpouse && node.member.spouseId
        ? familyMembers.find((m) => m.id === node.member.spouseId)
        : null;

    return (
      <div key={node.member.id} className="font-mono text-stone-200 select-none">
        <div
          onClick={() => setDetailPerson(node.member)}
          className={`inline-flex items-center gap-1.5 group cursor-pointer rounded-lg px-2 py-1 transition-all ${
            isRoot
              ? 'bg-amber-950/70 border border-amber-500/60 text-amber-200 font-bold my-1 shadow'
              : 'bg-stone-900/70 border border-stone-800/80 hover:bg-stone-800/80 text-stone-100 hover:border-amber-500/50 my-0.5'
          }`}
        >
          {!isRoot && (
            <span
              className="text-amber-500 font-mono select-none shrink-0 font-bold"
              style={{ color: config.lineColor }}
            >
              {isLastChild ? '└──→ ' : '├──→ '}
            </span>
          )}

          {hasChildren ? (
            <button
              type="button"
              onClick={(e) => toggleNode(node.member.id, e)}
              className="w-4 h-4 rounded bg-stone-800 hover:bg-amber-600 hover:text-stone-950 text-amber-400 border border-stone-700/80 flex items-center justify-center text-[10px] shrink-0 font-bold"
              title={isExpanded ? 'Tutup' : 'Buka'}
            >
              {isExpanded ? '−' : '+'}
            </button>
          ) : (
            <span className="w-4 flex items-center justify-center text-stone-600 text-[10px] shrink-0">
              •
            </span>
          )}

          <span
            className={`w-2 h-2 rounded-full shrink-0 ${
              isMale ? 'bg-blue-400' : 'bg-pink-400'
            }`}
          />

          <span className="font-bold text-xs sm:text-sm text-stone-100 group-hover:text-amber-300">
            {node.member.name}
          </span>

          {node.member.birthYear && (
            <span className="text-[10px] text-stone-400 font-mono">
              ({node.member.birthYear}{node.member.deathYear ? `-${node.member.deathYear}` : ''})
            </span>
          )}

          {spouse && (
            <span className="text-[10px] px-1 py-0.2 rounded bg-pink-950/60 border border-pink-800/50 text-pink-300 flex items-center gap-0.5">
              ♥ {spouse.name}
            </span>
          )}
        </div>

        {hasChildren && isExpanded && (
          <div className="border-l border-stone-800/80 ml-2.5 pl-1.5 space-y-0.5">
            {node.children.map((childNode, index) =>
              renderOutlineTreeNode(childNode, index === node.children.length - 1)
            )}
          </div>
        )}
      </div>
    );
  };

  // Render Visual Node
  const renderVisualNode = (node: TreeNodeData) => {
    const isExpanded = expandedNodes.has(node.member.id);
    const hasChildren = node.children.length > 0;
    const isMale = node.member.gender === 'Laki-laki';
    const isRoot = node.depth === 1;

    const spouse =
      config.showSpouse && node.member.spouseId
        ? familyMembers.find((m) => m.id === node.member.spouseId)
        : null;

    return (
      <div
        key={node.member.id}
        className={`flex ${
          config.orientation === 'horizontal' ? 'flex-row items-center' : 'flex-col items-center'
        }`}
      >
        <div
          onClick={() => setDetailPerson(node.member)}
          className={`relative rounded-xl border transition-all cursor-pointer shadow-md backdrop-blur-xs px-3 py-1.5 text-xs ${
            isRoot
              ? 'bg-amber-950/80 border-amber-400 ring-1 ring-amber-400/40 text-stone-100'
              : 'bg-stone-900/80 border-stone-700/80 hover:border-amber-400 hover:bg-stone-800 text-stone-200'
          }`}
          style={{ maxWidth: '240px' }}
        >
          <div className="flex items-center justify-between gap-1 mb-0.5">
            <span className={`w-2 h-2 rounded-full shrink-0 ${isMale ? 'bg-blue-400' : 'bg-pink-400'}`} />
            <span className="text-[10px] font-mono text-amber-400 font-bold">Gen {node.member.generation}</span>
            {hasChildren && (
              <button
                type="button"
                onClick={(e) => toggleNode(node.member.id, e)}
                className="w-3.5 h-3.5 rounded bg-stone-800 hover:bg-amber-600 text-stone-300 hover:text-stone-950 flex items-center justify-center text-[10px] ml-auto shrink-0 font-bold"
              >
                {isExpanded ? '−' : '+'}
              </button>
            )}
          </div>
          <div className="font-bold text-xs text-stone-100 break-words leading-tight">{node.member.name}</div>
          {node.member.birthYear && (
            <div className="text-[10px] text-stone-400 font-mono truncate mt-0.5">{node.member.birthYear}</div>
          )}
          {spouse && (
            <div className="text-[9px] text-pink-300 truncate mt-0.5 font-medium">♥ {spouse.name}</div>
          )}
        </div>

        {hasChildren && isExpanded && (
          <div
            className={`flex relative ${
              config.orientation === 'horizontal'
                ? 'flex-col justify-center pl-5 border-l-2'
                : 'flex-row justify-center pt-5 border-t-2'
            }`}
            style={{
              borderColor: config.lineColor || '#f59e0b',
              gap: `${config.branchSpacing}px`,
              margin:
                config.orientation === 'horizontal'
                  ? `0 0 0 ${config.generationSpacing}px`
                  : `${config.generationSpacing}px 0 0 0`,
            }}
          >
            <div
              className={`absolute font-bold text-amber-400 text-xs select-none ${
                config.orientation === 'horizontal'
                  ? '-left-2.5 top-1/2 -translate-y-1/2 bg-stone-950 px-0.5'
                  : '-top-3 left-1/2 -translate-x-1/2 bg-stone-950 px-0.5'
              }`}
            >
              {config.orientation === 'horizontal' ? '→' : '↓'}
            </div>
            {node.children.map((child) => renderVisualNode(child))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="relative w-full h-full flex flex-col overflow-hidden select-none bg-stone-950">
      {/* 3. CONSOLIDATED FLOATING CONTROL ICON IN CORNER (Hidden when in Focus Mode or closed) */}
      {!isFocusMode && (
        <div className="absolute bottom-3 right-3 z-30 flex flex-col items-end gap-1.5 pointer-events-auto">
          {/* Toggle Button: ONE Small Icon Button as requested */}
          <button
            type="button"
            onClick={() => setIsControlsPanelOpen((prev) => !prev)}
            className="w-9 h-9 rounded-full bg-stone-900/95 border border-amber-500/50 text-amber-400 hover:scale-110 shadow-2xl backdrop-blur-md flex items-center justify-center cursor-pointer transition-all"
            title="Kontrol Canvas & Zoom"
          >
            {isControlsPanelOpen ? <X className="w-4 h-4" /> : <Sliders className="w-4 h-4" />}
          </button>

          {/* Hidden Panel (Appears ONLY when icon is clicked) */}
          {isControlsPanelOpen && (
            <div className="p-2 rounded-2xl bg-stone-950/98 border border-amber-500/40 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150 space-y-2 text-xs w-52 sm:w-60">
              {/* Top Row: Root Person Selection */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsRootDropdownOpen((p) => !p)}
                  className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 font-bold cursor-pointer"
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <User className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="truncate">{rootMember ? rootMember.name : 'Akar'}</span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                </button>

                {isRootDropdownOpen && (
                  <div className="absolute right-0 bottom-full mb-1 z-50 w-56 p-2 rounded-xl bg-stone-950 border border-amber-500/50 shadow-2xl space-y-1.5">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={rootSearchQuery}
                        onChange={(e) => setRootSearchQuery(e.target.value)}
                        placeholder={t('searchPerson')}
                        className="w-full pl-6 pr-2 py-1 rounded bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                        autoFocus
                      />
                    </div>

                    <div className="max-h-36 overflow-y-auto divide-y divide-stone-800">
                      {searchRootResults.map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => {
                            setSelectedRootId(m.id);
                            setIsRootDropdownOpen(false);
                            setRootSearchQuery('');
                          }}
                          className="w-full px-2 py-1 text-left hover:bg-stone-900 rounded flex items-center justify-between text-xs cursor-pointer"
                        >
                          <span className="text-stone-200 font-semibold truncate">{m.name}</span>
                          <span className="text-[10px] text-amber-400 font-mono ml-1">
                            G{m.generation}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Compact Zoom Controls (− 100% + Fit) */}
              <div className="flex items-center justify-between gap-1 p-1 bg-stone-900 rounded-xl border border-stone-800">
                <button
                  type="button"
                  onClick={handleZoomOut}
                  className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-750 text-amber-300 font-extrabold flex items-center justify-center text-sm cursor-pointer active:scale-95"
                  title={t('zoomOut')}
                >
                  −
                </button>

                <button
                  type="button"
                  onClick={handleZoomReset}
                  className="px-2 py-1 rounded bg-stone-950 text-amber-400 font-mono text-xs font-bold hover:bg-stone-800 cursor-pointer"
                  title={t('resetZoom')}
                >
                  {Math.round(zoomScale * 100)}%
                </button>

                <button
                  type="button"
                  onClick={handleZoomIn}
                  className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-750 text-amber-300 font-extrabold flex items-center justify-center text-sm cursor-pointer active:scale-95"
                  title={t('zoomIn')}
                >
                  +
                </button>

                <button
                  type="button"
                  onClick={expandAll}
                  className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-750 text-stone-200 cursor-pointer"
                  title="Buka semua cabang"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Add Note Button */}
              <button
                type="button"
                onClick={() => {
                  setIsNoteImportOpen(true);
                  setIsControlsPanelOpen(false);
                }}
                className="w-full py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold flex items-center justify-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Catatan Silsilah</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Main Full-Screen Scrollable Viewport Canvas (Priority 100% Canvas Space) */}
      <div className="flex-1 w-full h-full overflow-auto cursor-grab active:cursor-grabbing p-3 sm:p-6">
        <div
          className="transition-transform duration-150 origin-top-left min-w-full min-h-full"
          style={{
            transform: `scale(${zoomScale})`,
            transformOrigin: 'top left',
          }}
        >
          {treeData ? (
            config.orientation === 'outline_tree' ? (
              <div className="space-y-0.5 py-2 font-mono">
                {renderOutlineTreeNode(treeData, true)}
              </div>
            ) : (
              <div className="py-4 flex items-center justify-start min-w-full">
                {renderVisualNode(treeData)}
              </div>
            )
          ) : (
            <div className="p-8 text-center text-stone-400 text-xs">
              Tidak ada data silsilah.
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <PersonDetailModal
        person={detailPerson}
        onClose={() => setDetailPerson(null)}
        onSelectPerson={(p) => setDetailPerson(p)}
        onSetAsRoot={(p) => {
          setSelectedRootId(p.id);
          showToast(`Akar: "${p.name}"`);
        }}
      />

      <GenealogySettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      <NoteImportModal
        isOpen={isNoteImportOpen}
        onClose={() => setIsNoteImportOpen(false)}
        onSuccessAdded={(newM) => {
          setSelectedRootId(newM.id);
        }}
      />
    </div>
  );
};
