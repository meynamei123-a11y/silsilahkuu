import React from 'react';
import { useApp } from '../context/AppContext';

export const BackgroundLayer: React.FC = () => {
  const { rootConfig, currentPage } = useApp();
  const theme = rootConfig.globalTheme;

  // If page has a custom background, use it; otherwise use global wallpaper
  const wallpaperUrl = currentPage.customBackground || theme.wallpaper;
  const blurValue = currentPage.customBlur !== undefined ? currentPage.customBlur : theme.blur;

  return (
    <div className="fixed inset-0 w-full h-full pointer-events-none overflow-hidden -z-10 bg-stone-950">
      {/* Background Image with Dynamic Blur and Scale */}
      <div
        className="absolute inset-0 w-full h-full bg-cover bg-center transition-all duration-500 ease-out"
        style={{
          backgroundImage: `url("${wallpaperUrl}")`,
          filter: `blur(${blurValue}px)`,
          transform: blurValue > 0 ? 'scale(1.08)' : 'scale(1)',
        }}
        aria-hidden="true"
      />

      {/* Atmospheric Overlays for optimal contrast and readability */}
      <div
        className="absolute inset-0 w-full h-full transition-colors duration-500"
        style={{
          backgroundColor:
            theme.cardColorTheme === 'clean'
              ? 'rgba(255, 255, 255, 0.35)'
              : 'rgba(12, 10, 9, 0.65)',
          backdropFilter: 'contrast(105%)',
        }}
        aria-hidden="true"
      />

      {/* Subtle vignette mask */}
      <div
        className="absolute inset-0 w-full h-full bg-radial from-transparent via-stone-950/30 to-stone-950/80 pointer-events-none"
        aria-hidden="true"
      />
    </div>
  );
};
