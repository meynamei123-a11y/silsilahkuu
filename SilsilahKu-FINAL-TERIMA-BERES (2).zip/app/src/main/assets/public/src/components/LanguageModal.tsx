import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { X, Check, Globe } from 'lucide-react';
import { LANGUAGES } from '../utils/i18n';
import { LanguageCode } from '../types';

export const LanguageModal: React.FC = () => {
  const {
    isLanguageModalOpen,
    closeLanguageModal,
    rootConfig,
    setLanguage,
    showToast,
    t,
  } = useApp();

  const [selectedLang, setSelectedLang] = useState<LanguageCode>(rootConfig.language || 'id');

  useEffect(() => {
    if (isLanguageModalOpen) {
      setSelectedLang(rootConfig.language || 'id');
    }
  }, [isLanguageModalOpen, rootConfig.language]);

  if (!isLanguageModalOpen) return null;

  const handleSave = () => {
    setLanguage(selectedLang);
    const selectedObj = LANGUAGES.find((l) => l.code === selectedLang);
    showToast(`✅ ${t('languageSaved')}: ${selectedObj?.nativeName || selectedLang}`);
    closeLanguageModal();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-xs bg-stone-900 border border-stone-800 rounded-2xl shadow-xl overflow-hidden text-stone-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-stone-950/80">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-stone-100">{t('selectLanguage')}</h3>
          </div>
          <button
            onClick={closeLanguageModal}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Languages List */}
        <div className="p-3 space-y-1.5 text-xs">
          {LANGUAGES.map((lang) => {
            const isSelected = selectedLang === lang.code;
            return (
              <button
                key={lang.code}
                type="button"
                onClick={() => setSelectedLang(lang.code)}
                className={`w-full py-2.5 px-3 rounded-xl border text-left font-semibold cursor-pointer transition-colors flex items-center justify-between ${
                  isSelected
                    ? 'bg-amber-950/60 border-amber-400 text-amber-200 ring-1 ring-amber-400/40'
                    : 'bg-stone-950/50 border-stone-800 text-stone-300 hover:bg-stone-800'
                }`}
              >
                <div>
                  <span className="block font-bold text-xs">{lang.nativeName}</span>
                  <span className="block text-[10px] text-stone-400 font-normal">{lang.name}</span>
                </div>
                {isSelected && <Check className="w-4 h-4 text-amber-400" />}
              </button>
            );
          })}
        </div>

        {/* Footer with Explicit Simpan Button as requested */}
        <div className="px-4 py-3 border-t border-stone-800 bg-stone-950/80 flex justify-between items-center gap-2">
          <button
            onClick={closeLanguageModal}
            className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold text-xs cursor-pointer"
          >
            {t('cancel')}
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer shadow-md transition-all active:scale-95"
          >
            {t('save')}
          </button>
        </div>
      </div>
    </div>
  );
};
