import React, { useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Camera, RotateCcw, Check, AlertTriangle } from 'lucide-react';
import {
  WALLPAPER_PRESETS,
  PRIMARY_COLOR_OPTIONS,
  CARD_THEME_OPTIONS,
  DEFAULT_WALLPAPER,
} from '../data/initialData';
import { BlurLevel, CardSize, FontFamilyType } from '../types';

/**
 * Basic Wallpaper Modal (Minimalist & Compact)
 */
export const BasicWallpaperModal: React.FC = () => {
  const {
    isBasicWallpaperModalOpen,
    closeBasicWallpaperModal,
    rootConfig,
    setWallpaperFromFile,
    setWallpaperPreset,
    setBlurLevel,
  } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);

  if (!isBasicWallpaperModalOpen) return null;

  const theme = rootConfig.globalTheme;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploading(true);
      await setWallpaperFromFile(file);
      setIsUploading(false);
    }
    e.target.value = '';
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      <div className="w-full max-w-md bg-stone-900 border border-stone-800 rounded-2xl shadow-xl overflow-hidden text-stone-100 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-stone-950/80">
          <h3 className="text-sm font-bold text-stone-100">Pengaturan Wallpaper & Blur</h3>
          <button
            onClick={closeBasicWallpaperModal}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs">
          {/* Upload & Reset Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="flex-1 py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>{isUploading ? 'Memproses...' : 'Pilih Foto'}</span>
            </button>

            <button
              type="button"
              onClick={() => setWallpaperPreset(DEFAULT_WALLPAPER, 'Default Heritage')}
              className="py-2 px-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 font-medium flex items-center gap-1 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>

          {/* Blur Level Selection */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold text-stone-300">
              <span>Blur Latar Belakang</span>
              <span className="text-amber-400 font-mono">{theme.blur}px</span>
            </div>
            <div className="flex gap-1.5">
              {([0, 5, 10, 15, 20] as BlurLevel[]).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setBlurLevel(lvl)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer border ${
                    theme.blur === lvl
                      ? 'bg-amber-600 text-stone-950 border-amber-400'
                      : 'bg-stone-800 text-stone-300 border-stone-700/60 hover:bg-stone-750'
                  }`}
                >
                  {lvl === 0 ? 'Off' : `${lvl}px`}
                </button>
              ))}
            </div>
          </div>

          {/* Wallpaper Presets list */}
          <div className="space-y-2 pt-1 border-t border-stone-800">
            <span className="block text-xs font-semibold text-stone-300">Preset Wallpaper</span>
            <div className="grid grid-cols-2 gap-2">
              {WALLPAPER_PRESETS.map((p) => {
                const isSel = theme.wallpaper === p.url;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setWallpaperPreset(p.url, p.name)}
                    className={`p-2 rounded-xl border text-left flex items-center gap-2 cursor-pointer transition-all ${
                      isSel
                        ? 'bg-amber-950/40 border-amber-400 text-amber-200'
                        : 'bg-stone-950/50 border-stone-800 text-stone-300 hover:bg-stone-800'
                    }`}
                  >
                    <img
                      src={p.url}
                      alt={p.name}
                      className="w-8 h-8 rounded-lg object-cover shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0 flex-1">
                      <span className="font-semibold block truncate text-[11px]">{p.name}</span>
                    </div>
                    {isSel && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 border-t border-stone-800 bg-stone-950/80 flex justify-end">
          <button
            onClick={closeBasicWallpaperModal}
            className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};

/**
 * Basic Theme Modal (Minimalist & Compact with Factory Reset)
 */
export const BasicThemeModal: React.FC = () => {
  const {
    isBasicThemeModalOpen,
    closeBasicThemeModal,
    rootConfig,
    updateGlobalTheme,
    setCardSize,
    resetToDefaultConfig,
  } = useApp();

  const [confirmReset, setConfirmReset] = useState(false);

  if (!isBasicThemeModalOpen) return null;

  const theme = rootConfig.globalTheme;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md bg-stone-900 border border-stone-800 rounded-2xl shadow-xl overflow-hidden text-stone-100 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-stone-950/80">
          <h3 className="text-sm font-bold text-stone-100">Warna Tema & Kartu</h3>
          <button
            onClick={closeBasicThemeModal}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs">
          {/* Primary Color Accent */}
          <div className="space-y-2">
            <span className="block font-semibold text-stone-300">Warna Aksen Utama</span>
            <div className="grid grid-cols-4 gap-2">
              {PRIMARY_COLOR_OPTIONS.map((col) => {
                const isSel = theme.primaryColor === col.hex;
                return (
                  <button
                    key={col.hex}
                    type="button"
                    onClick={() =>
                      updateGlobalTheme({
                        primaryColor: col.hex,
                        primaryColorName: col.name,
                      })
                    }
                    className={`py-1.5 px-2 rounded-xl border flex items-center gap-1.5 cursor-pointer transition-all ${
                      isSel
                        ? 'bg-stone-800 border-amber-400 font-bold'
                        : 'bg-stone-950/60 border-stone-800 text-stone-300 hover:bg-stone-800'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full shrink-0"
                      style={{ backgroundColor: col.hex }}
                    />
                    <span className="text-[11px] truncate">{col.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Card Size */}
          <div className="space-y-1.5 pt-2 border-t border-stone-800">
            <span className="block font-semibold text-stone-300">Ukuran Kartu</span>
            <div className="flex gap-2">
              {(['kecil', 'sedang', 'besar'] as CardSize[]).map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => setCardSize(sz)}
                  className={`flex-1 py-1.5 rounded-xl font-semibold capitalize border cursor-pointer transition-colors text-xs ${
                    theme.cardSize === sz
                      ? 'bg-amber-600 text-stone-950 border-amber-400'
                      : 'bg-stone-950/60 text-stone-300 border-stone-800 hover:bg-stone-800'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Card Opacity Slider */}
          <div className="space-y-1 pt-2 border-t border-stone-800">
            <div className="flex items-center justify-between font-semibold text-stone-300">
              <span>Transparansi Kartu</span>
              <span className="text-amber-400 font-mono">{theme.cardOpacity}%</span>
            </div>
            <input
              type="range"
              min="40"
              max="100"
              step="5"
              value={theme.cardOpacity}
              onChange={(e) => updateGlobalTheme({ cardOpacity: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Factory Reset button in Basic Settings as requested in requirement 16 */}
          <div className="pt-3 border-t border-stone-800">
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="w-full py-2 px-3 rounded-xl bg-rose-950/40 hover:bg-rose-950 text-rose-300 border border-rose-800/60 font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors text-xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>↻ Kembali ke Setelan Pabrik</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 border-t border-stone-800 bg-stone-950/80 flex justify-end">
          <button
            onClick={closeBasicThemeModal}
            className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer"
          >
            Selesai
          </button>
        </div>
      </div>

      {/* Confirmation modal for Factory Reset */}
      {confirmReset && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85">
          <div className="w-full max-w-sm bg-stone-900 border border-rose-800 rounded-2xl p-5 shadow-2xl space-y-3 text-xs">
            <h4 className="text-sm font-bold text-rose-400 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              <span>Konfirmasi Setelan Pabrik</span>
            </h4>
            <p className="text-stone-300">
              Apakah Anda yakin ingin mengembalikan seluruh aplikasi ke setelan standar pabrik? Seluruh kustomisasi tema, halaman, dan elemen akan direset ke kondisi awal.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-300"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  resetToDefaultConfig();
                  setConfirmReset(false);
                  closeBasicThemeModal();
                }}
                className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
              >
                Ya, Reset Sekarang
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * Basic Font Modal (Minimalist & Compact)
 */
export const BasicFontModal: React.FC = () => {
  const {
    isBasicFontModalOpen,
    closeBasicFontModal,
    rootConfig,
    setFontFamily,
    setFontSizePreset,
    setFontSizeCustom,
  } = useApp();

  if (!isBasicFontModalOpen) return null;

  const theme = rootConfig.globalTheme;

  const fonts: { id: FontFamilyType; name: string }[] = [
    { id: 'plus-jakarta', name: 'Plus Jakarta Sans (Modern)' },
    { id: 'playfair', name: 'Playfair Display (Serif)' },
    { id: 'cinzel', name: 'Cinzel Monarki (Inskripsi)' },
    { id: 'lora', name: 'Lora Naskah (Hangat)' },
    { id: 'typewriter', name: 'Courier Prime (Ketik)' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md bg-stone-900 border border-stone-800 rounded-2xl shadow-xl overflow-hidden text-stone-100 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-stone-950/80">
          <h3 className="text-sm font-bold text-stone-100">Font & Ukuran Teks</h3>
          <button
            onClick={closeBasicFontModal}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs">
          {/* Font List */}
          <div className="space-y-1.5">
            <span className="block font-semibold text-stone-300">Jenis Huruf</span>
            <div className="space-y-1">
              {fonts.map((f) => {
                const isSel = theme.fontFamily === f.id;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setFontFamily(f.id)}
                    className={`w-full py-2 px-3 rounded-xl border text-left font-semibold cursor-pointer transition-colors flex items-center justify-between ${
                      isSel
                        ? 'bg-amber-950/40 border-amber-400 text-amber-200'
                        : 'bg-stone-950/50 border-stone-800 text-stone-300 hover:bg-stone-800'
                    }`}
                  >
                    <span>{f.name}</span>
                    {isSel && <Check className="w-3.5 h-3.5 text-amber-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Preset Font Sizes */}
          <div className="space-y-1.5 pt-2 border-t border-stone-800">
            <span className="block font-semibold text-stone-300">Ukuran Teks Preset</span>
            <div className="flex gap-2">
              {(['kecil', 'sedang', 'besar'] as const).map((pr) => (
                <button
                  key={pr}
                  type="button"
                  onClick={() => setFontSizePreset(pr)}
                  className={`flex-1 py-1.5 rounded-xl font-semibold capitalize border cursor-pointer transition-colors text-xs ${
                    theme.fontSizePreset === pr
                      ? 'bg-amber-600 text-stone-950 border-amber-400'
                      : 'bg-stone-950/60 text-stone-300 border-stone-800 hover:bg-stone-800'
                  }`}
                >
                  {pr}
                </button>
              ))}
            </div>
          </div>

          {/* Font Pixel Slider */}
          <div className="space-y-1 pt-2 border-t border-stone-800">
            <div className="flex items-center justify-between font-semibold text-stone-300">
              <span>Ukuran Pixel Teks</span>
              <span className="text-amber-400 font-mono">{theme.fontSizeValue}px</span>
            </div>
            <input
              type="range"
              min="12"
              max="22"
              step="1"
              value={theme.fontSizeValue}
              onChange={(e) => setFontSizeCustom(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 border-t border-stone-800 bg-stone-950/80 flex justify-end">
          <button
            onClick={closeBasicFontModal}
            className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};
