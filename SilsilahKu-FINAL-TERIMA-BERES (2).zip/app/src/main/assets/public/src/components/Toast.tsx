import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2 } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toastMessage } = useApp();

  if (!toastMessage) return null;

  return (
    <aside
      aria-label="Notifikasi sistem"
      aria-live="polite"
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-stone-900/95 text-stone-100 border border-amber-600/50 shadow-2xl text-sm font-medium backdrop-blur-md animate-in fade-in slide-in-from-bottom-3 duration-300"
    >
      <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
      <span>{toastMessage}</span>
    </aside>
  );
};
