import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Menu,
  ArrowLeft,
  Search,
  X,
  User,
  FileText,
  Layers,
  ChevronRight,
  Eye,
  Lock,
  Crown,
  Settings,
  Download,
  FolderArchive,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

export const TopHeader: React.FC = () => {
  const {
    currentPage,
    goBack,
    openMenu,
    appMode,
    toggleAppMode,
    openRootApkModal,
    rootConfig,
    navigateToPage,
    familyMembers,
    isAppLocked,
    lockNow,
    showToast,
    isFocusMode,
    openMainSettingsModal,
    t,
  } = useApp();

  if (isFocusMode) return null;

  const isHome = currentPage.isHomePage || currentPage.id === rootConfig.homePageId;

  // Global Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Close search dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(e.target as Node)
      ) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Search Results Query logic
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return null;
    const q = searchQuery.toLowerCase().trim();

    // 1. People / Tokoh
    const matchedPeople = familyMembers.filter((m) => {
      const matchName = m.name.toLowerCase().includes(q);
      const matchAlt = m.altNames && m.altNames.some((alt) => alt.toLowerCase().includes(q));
      const matchTitle = m.title && m.title.toLowerCase().includes(q);
      const matchBranch = m.lineageBranch && m.lineageBranch.toLowerCase().includes(q);
      const matchYear = m.birthYear && m.birthYear.includes(q);
      const matchNotes = (m.notes && m.notes.toLowerCase().includes(q)) || (m.biography && m.biography.toLowerCase().includes(q));
      return matchName || matchAlt || matchTitle || matchBranch || matchYear || matchNotes;
    });

    // 2. Views / Navigation Items / Archives
    const allSystemViews = [
      { id: 'page_genealogy', title: 'Ikhtisar Silsilah', keywords: ['genealogy', 'silsilah', 'ikhtisar', 'pohon', 'akar', 'trah'] },
      { id: 'page_family_tree', title: 'Bagan Pohon Keluarga', keywords: ['pohon', 'tree', 'family', 'bagan', 'struktur'] },
      { id: 'page_ancestry', title: 'Jejak Leluhur', keywords: ['ancestry', 'leluhur', 'jejak', 'asal-usul', 'era'] },
      { id: 'page_lineage', title: 'Garis Keturunan', keywords: ['lineage', 'garis', 'keturunan', 'patrilineal', 'matrilineal'] },
      { id: 'page_family_data', title: 'Data Silsilah', keywords: ['data', 'tabel', 'list', 'daftar', 'silsilah'] },
      { id: 'page_profile', title: 'Profil & Bio Tokoh Utama', keywords: ['profil', 'profile', 'bio', 'identitas'] },
    ];

    const matchedViews = allSystemViews.filter(
      (v) =>
        v.title.toLowerCase().includes(q) ||
        v.keywords.some((k) => k.includes(q))
    );

    // 3. Pages / Archives from rootConfig
    const matchedCustomPages = rootConfig.pages.filter((p) =>
      p.title.toLowerCase().includes(q) || (p.description && p.description.toLowerCase().includes(q))
    );

    // 4. Eras / Trah
    const matchedEras = ['1890', '1920', '1955', '1985', '2015', 'surakarta', 'kusumaningrat'].filter((e) =>
      e.includes(q)
    );

    return {
      people: matchedPeople.slice(0, 8),
      views: matchedViews,
      customPages: matchedCustomPages,
      eras: matchedEras,
      totalCount:
        matchedPeople.length + matchedViews.length + matchedCustomPages.length + matchedEras.length,
    };
  }, [searchQuery, familyMembers, rootConfig.pages]);

  const handleSelectPersonResult = (personId: string, personName: string) => {
    navigateToPage('page_genealogy');
    setSearchQuery('');
    setIsSearchFocused(false);
    showToast(`📍 Menampilkan: "${personName}"`);
  };

  const handleSelectPageResult = (pageId: string, pageTitle: string) => {
    navigateToPage(pageId);
    setSearchQuery('');
    setIsSearchFocused(false);
    showToast(`📍 Membuka: "${pageTitle}"`);
  };

  const handleDownloadZip = async (e: React.MouseEvent) => {
    e.preventDefault();
    showToast('⏳ Memulai pengunduhan SilsilahKu-Final-Source.zip...');
    try {
      const response = await fetch('/SilsilahKu-Final-Source.zip', { headers: { 'Cache-Control': 'no-cache' } });
      if (!response.ok) throw new Error('Download failed');
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const tempLink = document.createElement('a');
      tempLink.style.display = 'none';
      tempLink.href = blobUrl;
      tempLink.setAttribute('download', 'SilsilahKu-Final-Source.zip');
      document.body.appendChild(tempLink);
      tempLink.click();
      setTimeout(() => {
        document.body.removeChild(tempLink);
        window.URL.revokeObjectURL(blobUrl);
      }, 500);
      showToast('✅ File SilsilahKu-Final-Source.zip berhasil diunduh!');
    } catch {
      window.location.href = '/SilsilahKu-Final-Source.zip';
    }
  };

  return (
    <header className="w-full flex items-center justify-between px-2 sm:px-4 py-2 z-40 shrink-0 select-none border-b border-stone-800/60 bg-stone-950/90 backdrop-blur-md relative">
      {/* Left Area: Menu button & Back button */}
      <div className="flex items-center gap-1 sm:gap-2 shrink-0">
        <button
          onClick={openMenu}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-100 border border-stone-700/70 shadow transition-all active:scale-95 cursor-pointer text-xs font-bold"
          aria-label={t('menu')}
          title={t('menu')}
        >
          <Menu className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">{t('menu')}</span>
        </button>

        {!isHome && (
          <button
            onClick={goBack}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-100 border border-stone-700/80 shadow transition-all active:scale-95 text-xs font-semibold cursor-pointer"
            aria-label={t('back')}
          >
            <ArrowLeft className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">{t('back')}</span>
          </button>
        )}
      </div>

      {/* Center Area: GLOBAL SEARCH BAR */}
      <div ref={searchContainerRef} className="flex-1 max-w-xl mx-2 relative">
        <div className="relative flex items-center w-full">
          <Search className="w-3.5 h-3.5 text-amber-400 absolute left-2.5 pointer-events-none shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setIsSearchFocused(true);
            }}
            onFocus={() => setIsSearchFocused(true)}
            placeholder={t('searchPlaceholder')}
            className="w-full pl-8 pr-7 py-1.5 rounded-xl bg-stone-900/90 border border-stone-700/80 hover:border-amber-500/70 focus:border-amber-500 text-stone-100 text-xs focus:outline-none shadow-inner placeholder:text-stone-500 transition-all font-semibold"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2 p-0.5 rounded-full text-stone-400 hover:text-stone-100 hover:bg-stone-800 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Real-time Global Search Overlay Dropdown */}
        {isSearchFocused && searchResults && (
          <div className="absolute left-0 right-0 top-full mt-1 z-50 max-h-[70vh] overflow-y-auto bg-stone-950/95 border border-amber-500/50 rounded-2xl shadow-2xl p-2.5 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150 space-y-2 text-xs">
            {searchResults.totalCount === 0 ? (
              <div className="p-4 text-center text-stone-400 text-xs">
                Tidak ada hasil ditemukan untuk "{searchQuery}".
              </div>
            ) : (
              <>
                {/* System Views / Navigation Items */}
                {searchResults.views.length > 0 && (
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block px-2 mb-1">
                      Halaman & Pandangan
                    </span>
                    <div className="space-y-0.5">
                      {searchResults.views.map((v) => (
                        <button
                          key={v.id}
                          type="button"
                          onClick={() => handleSelectPageResult(v.id, v.title)}
                          className="w-full px-2.5 py-1.5 rounded-xl hover:bg-stone-900 text-left flex items-center justify-between group cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <Layers className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <span className="font-bold text-stone-200 group-hover:text-amber-300">
                              {v.title}
                            </span>
                          </div>
                          <ChevronRight className="w-3.5 h-3.5 text-stone-500" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* People / Tokoh */}
                {searchResults.people.length > 0 && (
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block px-2 mb-1">
                      Tokoh & Anggota Silsilah
                    </span>
                    <div className="space-y-0.5">
                      {searchResults.people.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => handleSelectPersonResult(p.id, p.name)}
                          className="w-full px-2.5 py-1.5 rounded-xl hover:bg-stone-900 text-left flex items-center justify-between group cursor-pointer"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <User className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <div className="min-w-0">
                              <span className="font-bold text-stone-100 group-hover:text-amber-300 block truncate">
                                {p.name}
                              </span>
                              <span className="text-[10px] text-stone-400 font-mono block truncate">
                                {p.birthYear ? `Lahir ${p.birthYear}` : ''} · Gen {p.generation} · {p.lineageBranch}
                              </span>
                            </div>
                          </div>
                          <ChevronRight className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Custom Pages / Archives */}
                {searchResults.customPages.length > 0 && (
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block px-2 mb-1">
                      Koleksi Arsip & Halaman Kustom
                    </span>
                    <div className="space-y-0.5">
                      {searchResults.customPages.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => handleSelectPageResult(p.id, p.title)}
                          className="w-full px-2.5 py-1.5 rounded-xl hover:bg-stone-900 text-left flex items-center justify-between group cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <FileText className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <span className="font-bold text-stone-200 group-hover:text-amber-300">
                              {p.title}
                            </span>
                          </div>
                          <ChevronRight className="w-3.5 h-3.5 text-stone-500" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Eras / Trah */}
                {searchResults.eras.length > 0 && (
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block px-2 mb-1">
                      Era & Trah
                    </span>
                    <div className="flex flex-wrap gap-1 px-2">
                      {searchResults.eras.map((e) => (
                        <button
                          key={e}
                          type="button"
                          onClick={() => handleSelectPageResult('page_ancestry', `Era ${e}`)}
                          className="px-2 py-1 rounded-lg bg-stone-900 border border-stone-800 text-stone-300 hover:text-amber-300 text-[11px] font-mono cursor-pointer"
                        >
                          {e}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>

      {/* Right Area: Mode Switcher & Lock Toggle */}
      <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
        {!isAppLocked && rootConfig.appLock?.isEnabled && (
          <button
            onClick={lockNow}
            className="p-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-amber-300 border border-amber-500/40 shadow cursor-pointer"
            title={t('locked')}
          >
            <Lock className="w-3.5 h-3.5 text-amber-400" />
          </button>
        )}

        {/* Mode Switcher */}
        <button
          onClick={() => {
            if (appMode === 'preview') {
              toggleAppMode();
            } else {
              openRootApkModal('visual_editor');
            }
          }}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all shadow cursor-pointer ${
            appMode === 'editor'
              ? 'bg-amber-500 text-stone-950 border-amber-400 ring-1 ring-amber-400/40'
              : 'bg-stone-900 text-stone-200 border-stone-700/80 hover:bg-stone-800'
          }`}
          title={appMode === 'editor' ? 'Buka Visual App Editor' : t('preview')}
        >
          <Eye className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden md:inline">{appMode === 'editor' ? '🛠 Visual Editor' : '👁️ Preview'}</span>
        </button>

        {/* In-App PWA Install Button for Mobile */}
        <PWAInstallButton variant="header" />

        {/* Quick ZIP Download Link */}
        <a
          href="/SilsilahKu-Final-Source.zip"
          download="SilsilahKu-Final-Source.zip"
          onClick={handleDownloadZip}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border border-amber-500/50 text-xs font-bold transition-all shadow cursor-pointer active:scale-95"
          title="📦 Unduh Source Project ZIP Lengkap"
        >
          <FolderArchive className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden lg:inline">Unduh ZIP</span>
        </a>

        {/* Settings / Gear Button */}
        <button
          onClick={openMainSettingsModal}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700/80 text-xs font-bold transition-all shadow cursor-pointer"
          title="⚙️ Pengaturan / Gear"
        >
          <Settings className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">Setelan</span>
        </button>

        {!isAppLocked && (
          <button
            onClick={() => openRootApkModal('visual_editor')}
            className="p-1.5 rounded-xl bg-amber-950/70 hover:bg-amber-900 text-amber-300 border border-amber-600/60 shadow cursor-pointer"
            title="Pusat Kontrol Root APK"
          >
            <Crown className="w-3.5 h-3.5 text-amber-400" />
          </button>
        )}
      </div>
    </header>
  );
};
