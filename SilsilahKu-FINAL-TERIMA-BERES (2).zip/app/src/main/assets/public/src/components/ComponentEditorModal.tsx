import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UIComponent, ComponentActionType, CardSize, ComponentPosition } from '../types';
import { AVAILABLE_ICONS, renderIconByName } from '../utils/iconMap';
import { PRIMARY_COLOR_OPTIONS } from '../data/initialData';
import {
  X,
  Save,
  Trash2,
  Copy,
  Eye,
  EyeOff,
  Power,
  Sparkles,
  Link,
  Sliders,
  Palette,
  Maximize2,
  Info,
} from 'lucide-react';

export const ComponentEditorModal: React.FC = () => {
  const {
    editingComponent,
    closeComponentEditor,
    updateComponent,
    deleteComponent,
    duplicateComponent,
    rootConfig,
  } = useApp();

  const [formData, setFormData] = useState<UIComponent>({
    id: '',
    name: '',
    type: 'button',
    position: 'default',
    order: 1,
    size: 'sedang',
    isVisible: true,
    isEnabled: true,
    actionType: 'none',
  });
  const [iconSearch, setIconSearch] = useState('');

  React.useEffect(() => {
    if (editingComponent) {
      setFormData({ ...editingComponent.comp });
      setIconSearch('');
    }
  }, [editingComponent]);

  if (!editingComponent) return null;

  const { pageId, comp } = editingComponent;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateComponent(pageId, comp.id, formData);
    closeComponentEditor();
  };

  const handleDelete = () => {
    if (window.confirm(`Yakin ingin menghapus komponen "${comp.name}"?`)) {
      deleteComponent(pageId, comp.id);
      closeComponentEditor();
    }
  };

  const handleDuplicate = () => {
    duplicateComponent(pageId, comp.id);
    closeComponentEditor();
  };

  const filteredIcons = AVAILABLE_ICONS.filter(
    (item) =>
      item.label.toLowerCase().includes(iconSearch.toLowerCase()) ||
      item.id.toLowerCase().includes(iconSearch.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-2xl bg-stone-900 border border-amber-600/40 rounded-3xl p-5 sm:p-7 shadow-2xl space-y-5 my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-800 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <Sliders className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-bold text-stone-100">
                Pengaturan Komponen: {formData.name}
              </h3>
            </div>
            <p className="text-xs text-stone-400 mt-0.5">
              ID Internal: <code className="text-amber-400 font-mono">{formData.id}</code> (Halaman: {pageId})
            </p>
          </div>

          <button
            onClick={closeComponentEditor}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form id="comp-form" onSubmit={handleSave} className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs sm:text-sm">
          {/* Section 1: Label & Deskripsi */}
          <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-3">
            <h4 className="font-semibold text-amber-400 uppercase tracking-wider text-[11px]">
              Identitas & Teks Tampilan
            </h4>

            <div>
              <label className="block text-stone-300 font-medium mb-1">
                Nama / Label Komponen *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  Sub-judul / Judul Kecil
                </label>
                <input
                  type="text"
                  value={formData.subtitle || ''}
                  onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                  placeholder="Contoh: Ikhtisar Silsilah"
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  Jenis Komponen
                </label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="vertical_card">Kolom / Card Memanjang (Halaman Utama)</option>
                  <option value="button">Tombol Aksi (Button)</option>
                  <option value="card_item">Kartu Konten (Card Item)</option>
                  <option value="text_block">Blok Teks / Pengantar</option>
                  <option value="badge">Label / Badge</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-stone-300 font-medium mb-1">
                Deskripsi / Keterangan Singkat
              </label>
              <textarea
                rows={2}
                value={formData.description || ''}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Section 2: Fungsi & Aksi Klik */}
          <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-3">
            <h4 className="font-semibold text-amber-400 uppercase tracking-wider text-[11px]">
              Fungsi & Aksi Ketika Diklik
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  Status Fungsi
                </label>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, isEnabled: !formData.isEnabled })}
                  className={`w-full py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-medium transition-colors ${
                    formData.isEnabled
                      ? 'bg-emerald-950/50 border-emerald-500/50 text-emerald-300'
                      : 'bg-red-950/40 border-red-800 text-red-300'
                  }`}
                >
                  <Power className="w-4 h-4" />
                  <span>{formData.isEnabled ? 'Fungsi Aktif' : 'Fungsi Dinonaktifkan'}</span>
                </button>
              </div>

              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  Jenis Aksi Klik
                </label>
                <select
                  value={formData.actionType}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      actionType: e.target.value as ComponentActionType,
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="navigate">Pindah ke Halaman (Navigate)</option>
                  <option value="none">Tanpa Fungsi (Hapus Fungsi, Tampilan Tetap Ada)</option>
                  <option value="toast">Tampilkan Pesan / Notifikasi (Toast)</option>
                  <option value="edit_profile">Buka Halaman Profil</option>
                  <option value="back">Kembali ke Halaman Sebelumnya</option>
                  <option value="open_url">Buka Tautan / URL</option>
                </select>
              </div>
            </div>

            {/* Target Page selector if navigate */}
            {formData.actionType === 'navigate' && (
              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  Halaman Tujuan *
                </label>
                <select
                  value={formData.targetPageId || ''}
                  onChange={(e) => setFormData({ ...formData, targetPageId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-amber-600/50 text-amber-300 text-xs focus:border-amber-400 focus:outline-none font-semibold"
                >
                  <option value="">-- Pilih Halaman Tujuan --</option>
                  {rootConfig.pages.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} {p.isHomePage ? '(Beranda)' : ''} [{p.id}]
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Action Payload if toast or url */}
            {(formData.actionType === 'toast' || formData.actionType === 'open_url') && (
              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  {formData.actionType === 'toast' ? 'Teks Pesan Notifikasi' : 'Alamat URL'}
                </label>
                <input
                  type="text"
                  value={formData.actionPayload || ''}
                  onChange={(e) => setFormData({ ...formData, actionPayload: e.target.value })}
                  placeholder={
                    formData.actionType === 'toast'
                      ? 'Contoh: Berhasil membuka arsip generasi!'
                      : 'https://...'
                  }
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                />
              </div>
            )}
          </div>

          {/* Section 3: Tampilan, Ukuran, Posisi & Ikon */}
          <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-3">
            <h4 className="font-semibold text-amber-400 uppercase tracking-wider text-[11px]">
              Tampilan, Ukuran & Posisi
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div>
                <label className="block text-stone-400 font-medium mb-1">Ukuran</label>
                <select
                  value={formData.size}
                  onChange={(e) => setFormData({ ...formData, size: e.target.value as CardSize })}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs"
                >
                  <option value="kecil">Kecil</option>
                  <option value="sedang">Sedang</option>
                  <option value="besar">Besar</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-400 font-medium mb-1">Posisi Alur</label>
                <select
                  value={formData.position}
                  onChange={(e) =>
                    setFormData({ ...formData, position: e.target.value as ComponentPosition })
                  }
                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs"
                >
                  <option value="default">Default</option>
                  <option value="left">Rata Kiri</option>
                  <option value="center">Tengah</option>
                  <option value="right">Rata Kanan</option>
                  <option value="top_left">Pojok Kiri Atas</option>
                  <option value="top_right">Pojok Kanan Atas</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-400 font-medium mb-1">Urutan (Order)</label>
                <input
                  type="number"
                  value={formData.order}
                  onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs"
                />
              </div>

              <div>
                <label className="block text-stone-400 font-medium mb-1">Visibilitas</label>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, isVisible: !formData.isVisible })}
                  className={`w-full py-1.5 px-2 rounded-lg border flex items-center justify-center gap-1 text-xs ${
                    formData.isVisible
                      ? 'bg-stone-800 border-stone-700 text-stone-200'
                      : 'bg-stone-950 border-stone-800 text-stone-500'
                  }`}
                >
                  {formData.isVisible ? (
                    <>
                      <Eye className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Tampil</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-3.5 h-3.5 text-stone-500" />
                      <span>Sembunyi</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Warna & Transparansi */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  Warna Aksen Komponen
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={formData.color || '#b45309'}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="w-9 h-9 rounded-lg bg-transparent cursor-pointer border border-stone-700"
                  />
                  <input
                    type="text"
                    value={formData.color || '#b45309'}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="flex-1 px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-stone-300 font-medium">Transparansi Latar</label>
                  <span className="font-mono text-amber-400 font-bold">
                    {formData.transparency ?? 85}%
                  </span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={100}
                  step={5}
                  value={formData.transparency ?? 85}
                  onChange={(e) =>
                    setFormData({ ...formData, transparency: Number(e.target.value) })
                  }
                  className="w-full accent-amber-500 h-2 bg-stone-800 rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* Ikon Picker */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-stone-300 font-medium flex items-center gap-1.5">
                  <span>Pilih Ikon Komponen:</span>
                  <span className="p-1 rounded bg-stone-800 text-amber-400 inline-flex items-center gap-1">
                    {renderIconByName(formData.icon, 'w-3.5 h-3.5')}
                    <strong className="text-[11px]">{formData.icon || 'Default'}</strong>
                  </span>
                </label>
                <input
                  type="text"
                  placeholder="Cari ikon..."
                  value={iconSearch}
                  onChange={(e) => setIconSearch(e.target.value)}
                  className="px-2 py-1 rounded-md bg-stone-900 border border-stone-700 text-[11px] text-stone-200 w-28"
                />
              </div>

              <div className="grid grid-cols-6 sm:grid-cols-10 gap-1.5 max-h-32 overflow-y-auto p-2 rounded-xl bg-stone-900/80 border border-stone-800">
                {filteredIcons.map((item) => {
                  const isCur = formData.icon === item.id;
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setFormData({ ...formData, icon: item.id })}
                      className={`p-2 rounded-lg flex flex-col items-center justify-center transition-colors cursor-pointer ${
                        isCur
                          ? 'bg-amber-600 text-stone-950 font-bold shadow'
                          : 'bg-stone-950/60 hover:bg-stone-800 text-stone-300'
                      }`}
                      title={item.label}
                    >
                      <Icon className="w-4 h-4" />
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </form>

        {/* Modal Footer Actions */}
        <div className="pt-3 border-t border-stone-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDuplicate}
              className="flex items-center gap-1 px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-medium transition-colors"
              title="Gandakan komponen ini"
            >
              <Copy className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Duplikasi</span>
            </button>
            <button
              type="button"
              onClick={handleDelete}
              className="flex items-center gap-1 px-3 py-2 rounded-xl bg-red-950/50 hover:bg-red-900/60 text-red-300 border border-red-800/40 text-xs font-medium transition-colors"
              title="Hapus komponen ini"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Hapus</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={closeComponentEditor}
              className="px-3.5 py-2 rounded-xl bg-stone-800 text-stone-300 text-xs hover:bg-stone-700"
            >
              Batal
            </button>
            <button
              type="submit"
              form="comp-form"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs shadow-lg transition-all active:scale-95 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Perubahan</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
