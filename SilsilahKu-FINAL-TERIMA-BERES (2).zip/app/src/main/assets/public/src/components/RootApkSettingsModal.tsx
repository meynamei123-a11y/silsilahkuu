import React from 'react';
import { RootApkMasterEditor } from './RootApkMasterEditor/RootApkMasterEditor';

/**
 * Root APK Master Control & Visual App Editor
 * Pusat Kontrol dan Visual Editor untuk Seluruh Aplikasi
 */
export const RootApkSettingsModal: React.FC = () => {
  return <RootApkMasterEditor />;
};
