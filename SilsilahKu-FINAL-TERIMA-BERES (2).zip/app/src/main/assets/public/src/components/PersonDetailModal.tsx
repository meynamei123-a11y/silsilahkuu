import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { FamilyMember } from '../types';
import {
  X,
  User,
  Heart,
  Calendar,
  MapPin,
  GitBranch,
  ChevronRight,
  ChevronDown,
  Share2,
  Edit3,
  FileText,
  Save,
  BookOpen,
} from 'lucide-react';

interface PersonDetailModalProps {
  person: FamilyMember | null;
  onClose: () => void;
  onSelectPerson?: (person: FamilyMember) => void;
  onSetAsRoot?: (person: FamilyMember) => void;
}

export const PersonDetailModal: React.FC<PersonDetailModalProps> = ({
  person,
  onClose,
  onSelectPerson,
  onSetAsRoot,
}) => {
  const { familyMembers, updateFamilyMember, showToast, t } = useApp();

  // Active section for progressive disclosure: 'overview' | 'biodata' | 'silsilah' | 'relasi' | 'catatan' | 'arsip' | 'edit'
  const [activeSection, setActiveSection] = useState<string>('biodata');

  // Active edit form mode: null | 'edit_biodata' | 'edit_catatan'
  const [activeEditForm, setActiveEditForm] = useState<string | null>(null);

  // Form states for editing
  const [editName, setEditName] = useState('');
  const [editBirthYear, setEditBirthYear] = useState('');
  const [editBirthPlace, setEditBirthPlace] = useState('');
  const [editFatherId, setEditFatherId] = useState<string>('');
  const [editMotherId, setEditMotherId] = useState<string>('');
  const [editNotes, setEditNotes] = useState('');

  useEffect(() => {
    if (person) {
      setActiveSection('biodata');
      setActiveEditForm(null);
      setEditName(person.name || '');
      setEditBirthYear(person.birthYear || '');
      setEditBirthPlace(person.birthPlace || '');
      setEditFatherId(person.fatherId || '');
      setEditMotherId(person.motherId || '');
      setEditNotes(person.notes || '');
    }
  }, [person]);

  if (!person) return null;

  const isMale = person.gender === 'Laki-laki';

  // Relations
  const father = person.fatherId ? familyMembers.find((m) => m.id === person.fatherId) : null;
  const mother = person.motherId ? familyMembers.find((m) => m.id === person.motherId) : null;
  const spouse = person.spouseId ? familyMembers.find((m) => m.id === person.spouseId) : null;
  const children = familyMembers.filter(
    (m) =>
      (person.childrenIds && person.childrenIds.includes(m.id)) ||
      m.fatherId === person.id ||
      m.motherId === person.id
  );

  const handleCopySummary = () => {
    const text = `${person.name} (Gen ${person.generation})
${t('birthYear')}: ${person.birthYear || '-'}
${t('father')}: ${father ? father.name : '-'}
${t('mother')}: ${mother ? mother.name : '-'}
${t('notes')}: ${person.notes || '-'}`;

    navigator.clipboard?.writeText(text);
    showToast(`Data "${person.name}" disalin!`);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    updateFamilyMember(person.id, {
      name: editName.trim(),
      birthYear: editBirthYear.trim(),
      birthPlace: editBirthPlace.trim(),
      fatherId: editFatherId || null,
      motherId: editMotherId || null,
      notes: editNotes.trim(),
    });
    showToast(`✅ ${t('savedSuccessfully')}`);
    setActiveEditForm(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl bg-stone-900 border-2 border-amber-600/40 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 text-stone-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative p-4 sm:p-5 bg-stone-950 border-b border-stone-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`w-12 h-16 sm:w-14 sm:h-14 rounded-2xl border flex items-center justify-center font-bold text-lg shrink-0 ${
                isMale
                  ? 'bg-blue-950/70 border-blue-500/50 text-blue-400'
                  : 'bg-pink-950/70 border-pink-500/50 text-pink-400'
              }`}
            >
              <User className="w-6 h-6 opacity-80" />
            </div>

            <div className="min-w-0">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                Gen {person.generation}
              </span>
              <h3 className="text-lg sm:text-xl font-black text-stone-100 tracking-tight mt-0.5 truncate">
                {person.name}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleCopySummary}
              className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors cursor-pointer"
              title="Salin Data"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors cursor-pointer"
              title={t('close')}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Progressive Navigation Menu Bar (Objek -> Fungsi -> Submenu) */}
        <div className="flex items-center gap-1 px-4 py-2 bg-stone-950/80 border-b border-stone-800 overflow-x-auto shrink-0 text-xs font-semibold">
          {[
            { id: 'biodata', label: t('biodata') },
            { id: 'silsilah', label: t('genealogy') },
            { id: 'relasi', label: t('relasi') },
            { id: 'catatan', label: t('catatan') },
            { id: 'arsip', label: t('arsip') },
            { id: 'edit', label: t('edit') },
          ].map((sec) => (
            <button
              key={sec.id}
              type="button"
              onClick={() => {
                setActiveSection(sec.id);
                if (sec.id !== 'edit') setActiveEditForm(null);
              }}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap cursor-pointer transition-colors ${
                activeSection === sec.id
                  ? 'bg-amber-600 text-stone-950 font-bold'
                  : 'text-stone-300 hover:bg-stone-800'
              }`}
            >
              {sec.label}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
          {/* SECTION 1: BIODATA */}
          {activeSection === 'biodata' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-stone-950/60 border border-stone-800">
                  <span className="text-[10px] text-stone-400 font-semibold block">{t('gender')}</span>
                  <span className="font-bold text-stone-100">{person.gender}</span>
                </div>

                <div className="p-3 rounded-2xl bg-stone-950/60 border border-stone-800">
                  <span className="text-[10px] text-stone-400 font-semibold block">{t('generation')}</span>
                  <span className="font-bold text-amber-400 font-mono">Generasi {person.generation}</span>
                </div>

                <div className="p-3 rounded-2xl bg-stone-950/60 border border-stone-800">
                  <span className="text-[10px] text-stone-400 font-semibold block">{t('birthYear')}</span>
                  <span className="font-bold text-stone-100">{person.birthYear || '-'}</span>
                </div>

                <div className="p-3 rounded-2xl bg-stone-950/60 border border-stone-800">
                  <span className="text-[10px] text-stone-400 font-semibold block">{t('birthPlace')}</span>
                  <span className="font-bold text-stone-100">{person.birthPlace || '-'}</span>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 2: SILSILAH */}
          {activeSection === 'silsilah' && (
            <div className="space-y-3 animate-in fade-in duration-150 text-center py-4">
              <p className="text-stone-300 font-semibold text-sm">
                Lihat silsilah lengkap dan jalur keturunan dari <strong className="text-amber-300">{person.name}</strong>.
              </p>
              {onSetAsRoot && (
                <button
                  type="button"
                  onClick={() => {
                    onSetAsRoot(person);
                    onClose();
                  }}
                  className="px-5 py-2.5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer inline-flex items-center gap-2 shadow"
                >
                  <GitBranch className="w-4 h-4" />
                  <span>{t('setAsRoot')}</span>
                </button>
              )}
            </div>
          )}

          {/* SECTION 3: RELASI */}
          {activeSection === 'relasi' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="p-3 rounded-2xl bg-stone-950/80 border border-stone-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-stone-400 block">{t('father')}</span>
                    <span className="font-bold text-stone-100">{father ? father.name : '-'}</span>
                  </div>
                  {father && onSelectPerson && (
                    <button
                      onClick={() => onSelectPerson(father)}
                      className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-300"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="p-3 rounded-2xl bg-stone-950/80 border border-stone-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-stone-400 block">{t('mother')}</span>
                    <span className="font-bold text-stone-100">{mother ? mother.name : '-'}</span>
                  </div>
                  {mother && onSelectPerson && (
                    <button
                      onClick={() => onSelectPerson(mother)}
                      className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-300"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="p-3 rounded-2xl bg-stone-950/80 border border-stone-800 flex items-center justify-between col-span-1 sm:col-span-2">
                  <div>
                    <span className="text-[10px] text-stone-400 block">{t('spouse')}</span>
                    <span className="font-bold text-pink-300">{spouse ? spouse.name : '-'}</span>
                  </div>
                  {spouse && onSelectPerson && (
                    <button
                      onClick={() => onSelectPerson(spouse)}
                      className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-300"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {children.length > 0 && (
                <div className="pt-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block mb-1">
                    {t('children')} ({children.length})
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {children.map((child) => (
                      <button
                        key={child.id}
                        type="button"
                        onClick={() => onSelectPerson && onSelectPerson(child)}
                        className="px-3 py-1.5 rounded-xl bg-stone-950 hover:bg-stone-800 border border-stone-800 text-stone-200 font-semibold cursor-pointer transition-colors flex items-center gap-1.5"
                      >
                        <span>{child.name}</span>
                        <ChevronRight className="w-3.5 h-3.5 text-amber-400" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* SECTION 4: CATATAN */}
          {activeSection === 'catatan' && (
            <div className="space-y-2 p-4 rounded-2xl bg-stone-950/80 border border-stone-800 animate-in fade-in duration-150">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block">
                {t('notes')}
              </span>
              <p className="text-stone-300 leading-relaxed whitespace-pre-wrap">
                {person.notes || 'Belum ada catatan sejarah.'}
              </p>
            </div>
          )}

          {/* SECTION 5: ARSIP */}
          {activeSection === 'arsip' && (
            <div className="space-y-2 p-4 rounded-2xl bg-stone-950/80 border border-stone-800 animate-in fade-in duration-150">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block">
                Arsip & Naskah Sumber
              </span>
              <p className="text-stone-300 leading-relaxed">
                {person.biography || 'Sumber pustaka & dokumen tersimpan dalam arsip terpusat.'}
              </p>
            </div>
          )}

          {/* SECTION 6: EDIT (PROGRESSIVE DISCLOSURE: Submenu -> Form) */}
          {activeSection === 'edit' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              {!activeEditForm ? (
                /* Submenu Edit Choices */
                <div className="space-y-1.5">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block mb-2">
                    Pilih Bagian yang Ingin Diubah
                  </span>

                  <button
                    type="button"
                    onClick={() => setActiveEditForm('edit_biodata')}
                    className="w-full py-2.5 px-3 rounded-xl bg-stone-950 hover:bg-stone-800 border border-stone-800 text-stone-100 font-bold text-left flex items-center justify-between cursor-pointer"
                  >
                    <span>1. Edit Biodata</span>
                    <ChevronRight className="w-4 h-4 text-stone-500" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveEditForm('edit_catatan')}
                    className="w-full py-2.5 px-3 rounded-xl bg-stone-950 hover:bg-stone-800 border border-stone-800 text-stone-100 font-bold text-left flex items-center justify-between cursor-pointer"
                  >
                    <span>2. Edit Catatan & Sejarah</span>
                    <ChevronRight className="w-4 h-4 text-stone-500" />
                  </button>
                </div>
              ) : (
                /* Form ONLY renders when requested as required */
                <form onSubmit={handleSaveForm} className="space-y-3 p-3.5 bg-stone-950 border border-stone-800 rounded-2xl">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                    <span className="font-bold text-amber-400">
                      {activeEditForm === 'edit_biodata' ? 'Form Edit Biodata' : 'Form Edit Catatan'}
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveEditForm(null)}
                      className="text-stone-400 hover:text-white text-xs cursor-pointer font-semibold"
                    >
                      ← Kembali
                    </button>
                  </div>

                  {activeEditForm === 'edit_biodata' && (
                    <>
                      <div>
                        <label className="block text-stone-300 font-semibold mb-1">Nama Tokoh *</label>
                        <input
                          type="text"
                          required
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 text-xs font-semibold focus:border-amber-500 focus:outline-none"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-stone-300 font-semibold mb-1">{t('birthYear')}</label>
                          <input
                            type="text"
                            value={editBirthYear}
                            onChange={(e) => setEditBirthYear(e.target.value)}
                            className="w-full px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 text-xs font-semibold focus:border-amber-500 focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-stone-300 font-semibold mb-1">{t('birthPlace')}</label>
                          <input
                            type="text"
                            value={editBirthPlace}
                            onChange={(e) => setEditBirthPlace(e.target.value)}
                            className="w-full px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 text-xs font-semibold focus:border-amber-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-stone-300 font-semibold mb-1">{t('father')}</label>
                          <select
                            value={editFatherId}
                            onChange={(e) => setEditFatherId(e.target.value)}
                            className="w-full px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                          >
                            <option value="">- Tanpa Ayah -</option>
                            {familyMembers.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-stone-300 font-semibold mb-1">{t('mother')}</label>
                          <select
                            value={editMotherId}
                            onChange={(e) => setEditMotherId(e.target.value)}
                            className="w-full px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                          >
                            <option value="">- Tanpa Ibu -</option>
                            {familyMembers.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </>
                  )}

                  {activeEditForm === 'edit_catatan' && (
                    <div>
                      <label className="block text-stone-300 font-semibold mb-1">{t('notes')}</label>
                      <textarea
                        rows={4}
                        value={editNotes}
                        onChange={(e) => setEditNotes(e.target.value)}
                        className="w-full px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 text-xs focus:border-amber-500 focus:outline-none resize-none"
                      />
                    </div>
                  )}

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveEditForm(null)}
                      className="px-3 py-1.5 rounded-xl bg-stone-800 text-stone-300 font-semibold"
                    >
                      {t('cancel')}
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{t('save')}</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-800 bg-stone-950 flex items-center justify-between gap-2">
          {onSetAsRoot && (
            <button
              onClick={() => {
                onSetAsRoot(person);
                onClose();
              }}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer flex items-center gap-1.5 shadow"
            >
              <GitBranch className="w-4 h-4" />
              <span>{t('setAsRoot')}</span>
            </button>
          )}

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs cursor-pointer ml-auto"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </div>
  );
};
