import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Lock, Unlock, X, AlertCircle, Eye, EyeOff } from 'lucide-react';

export const PasscodePromptModal: React.FC = () => {
  const {
    isPasscodePromptOpen,
    closePasscodePrompt,
    verifyAndUnlock,
    passcodePromptOptions,
    rootConfig,
    t,
  } = useApp();

  const [inputCode, setInputCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isPasscodePromptOpen) {
      setInputCode('');
      setErrorMessage(null);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isPasscodePromptOpen]);

  if (!isPasscodePromptOpen) return null;

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputCode.trim()) {
      setErrorMessage(t('incorrectPasscode'));
      return;
    }

    const success = verifyAndUnlock(inputCode);
    if (!success) {
      setErrorMessage(t('incorrectPasscode'));
      setInputCode('');
      inputRef.current?.focus();
    }
  };

  const handleKeyPress = (num: string) => {
    setInputCode((prev) => (prev.length < 12 ? prev + num : prev));
    setErrorMessage(null);
  };

  const handleBackspace = () => {
    setInputCode((prev) => prev.slice(0, -1));
    setErrorMessage(null);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-xs sm:max-w-sm bg-stone-900 border border-stone-800 rounded-2xl shadow-xl overflow-hidden text-stone-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-stone-950/80">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-stone-100">
              {passcodePromptOptions.title || t('enterPasscode')}
            </h3>
          </div>
          <button
            onClick={closePasscodePrompt}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3 text-xs">
          <p className="text-stone-300 font-semibold">
            {passcodePromptOptions.description || t('lockAppDescription')}
          </p>

          <div>
            <div className="relative flex items-center">
              <input
                ref={inputRef}
                type={showPassword ? 'text' : 'password'}
                value={inputCode}
                onChange={(e) => {
                  setInputCode(e.target.value);
                  setErrorMessage(null);
                }}
                placeholder={t('enterPasscode')}
                className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 font-mono text-center text-sm font-bold focus:border-amber-500 focus:outline-none pr-9"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2.5 text-stone-400 hover:text-stone-200 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {errorMessage && (
              <div className="flex items-center gap-1 text-xs text-rose-400 font-semibold mt-1.5 justify-center">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>

          {/* Keypad */}
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((btn) => (
              <button
                key={btn}
                type="button"
                onClick={() => {
                  if (btn === 'C') {
                    setInputCode('');
                    setErrorMessage(null);
                  } else if (btn === '⌫') {
                    handleBackspace();
                  } else {
                    handleKeyPress(btn);
                  }
                }}
                className={`py-2 rounded-xl font-mono text-sm font-bold border transition-colors cursor-pointer ${
                  btn === 'C'
                    ? 'bg-stone-800 hover:bg-stone-700 text-rose-400 border-stone-700 text-xs'
                    : btn === '⌫'
                    ? 'bg-stone-800 hover:bg-stone-700 text-amber-300 border-stone-700 text-xs'
                    : 'bg-stone-950 text-stone-100 border-stone-800 hover:bg-stone-800'
                }`}
              >
                {btn}
              </button>
            ))}
          </div>

          {rootConfig.appLock?.hint && (
            <div className="text-[11px] text-amber-300 font-semibold text-center pt-0.5">
              {t('passcodeHint')}: {rootConfig.appLock.hint}
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={closePasscodePrompt}
              className="flex-1 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold cursor-pointer"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="flex-1 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold flex items-center justify-center gap-1 cursor-pointer"
            >
              <Unlock className="w-3.5 h-3.5" />
              <span>{t('unlocked')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
