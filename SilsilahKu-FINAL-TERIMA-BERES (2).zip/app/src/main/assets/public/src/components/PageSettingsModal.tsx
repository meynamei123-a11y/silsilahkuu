import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PageLayoutType, UIComponent } from '../types';
import { renderIconByName } from '../utils/iconMap';
import {
  X,
  Plus,
  Trash2,
  Edit,
  ArrowUp,
  ArrowDown,
  Copy,
  Eye,
  EyeOff,
  Settings,
  Layers,
  Save,
  FilePlus,
  Check,
  Power,
} from 'lucide-react';

export const PageSettingsModal: React.FC = () => {
  const {
    isPageSettingsModalOpen,
    closePageSettingsModal,
    currentPage,
    updatePage,
    deletePage,
    addComponentToPage,
    openComponentEditor,
    duplicateComponent,
    deleteComponent,
    moveComponentOrder,
    rootConfig,
    navigateToPage,
    addPage,
  } = useApp();

  const [pageTitle, setPageTitle] = useState(currentPage.title);
  const [pageDescription, setPageDescription] = useState(currentPage.description || '');
  const [layoutType, setLayoutType] = useState<PageLayoutType>(currentPage.layoutType);

  // New Component state
  const [isAddingComp, setIsAddingComp] = useState(false);
  const [newCompName, setNewCompName] = useState('');
  const [newCompSubtitle, setNewCompSubtitle] = useState('');
  const [newCompType, setNewCompType] = useState<'button' | 'vertical_card' | 'card_item'>('button');
  const [newCompAction, setNewCompAction] = useState<'navigate' | 'toast' | 'none'>('navigate');
  const [newCompTargetPage, setNewCompTargetPage] = useState('');
  const [newCompIcon, setNewCompIcon] = useState('Sparkles');

  // Sub-page creation quick helper
  const [isAddingSubPage, setIsAddingSubPage] = useState(false);
  const [subPageTitle, setSubPageTitle] = useState('');

  // Sync state whenever modal opens or currentPage changes
  React.useEffect(() => {
    if (isPageSettingsModalOpen) {
      setPageTitle(currentPage.title);
      setPageDescription(currentPage.description || '');
      setLayoutType(currentPage.layoutType);
    }
  }, [isPageSettingsModalOpen, currentPage]);

  if (!isPageSettingsModalOpen) return null;

  const handleSavePageDetails = (e: React.FormEvent) => {
    e.preventDefault();
    updatePage(currentPage.id, {
      title: pageTitle,
      description: pageDescription,
      layoutType,
    });
  };

  const handleCreateComponent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompName.trim()) return;

    addComponentToPage(currentPage.id, {
      name: newCompName,
      subtitle: newCompSubtitle,
      description: 'Komponen baru yang ditambahkan melalui Pengaturan Halaman.',
      type: newCompType,
      icon: newCompIcon,
      position: 'default',
      order: currentPage.components.length + 1,
      size: 'sedang',
      color: rootConfig.globalTheme.primaryColor,
      transparency: 85,
      isVisible: true,
      isEnabled: true,
      actionType: newCompAction,
      targetPageId: newCompAction === 'navigate' ? newCompTargetPage : undefined,
      actionPayload: newCompAction === 'toast' ? `Aksi tombol "${newCompName}" berhasil!` : undefined,
    });

    setIsAddingComp(false);
    setNewCompName('');
    setNewCompSubtitle('');
  };

  const handleCreateSubPage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subPageTitle.trim()) return;

    const newPageId = addPage({
      title: subPageTitle,
      slug: subPageTitle.toLowerCase().replace(/\s+/g, '-'),
      description: `Sub-halaman turunan dari ${currentPage.title}`,
      layoutType: 'flow_list',
      parentPageId: currentPage.id,
      components: [
        {
          id: 'btn_back_to_parent',
          name: `Kembali ke ${currentPage.title}`,
          type: 'button',
          position: 'center',
          order: 1,
          size: 'sedang',
          color: rootConfig.globalTheme.primaryColor,
          isVisible: true,
          isEnabled: true,
          actionType: 'navigate',
          targetPageId: currentPage.id,
          icon: 'ArrowRight',
        },
      ],
    });

    // Also add a button on the current page that links to this new subpage!
    addComponentToPage(currentPage.id, {
      name: `Buka ${subPageTitle}`,
      subtitle: 'Cabang Hierarki Baru',
      description: `Menuju halaman baru: ${subPageTitle}`,
      type: 'button',
      icon: 'GitFork',
      position: 'center',
      order: currentPage.components.length + 1,
      size: 'sedang',
      color: rootConfig.globalTheme.primaryColor,
      isVisible: true,
      isEnabled: true,
      actionType: 'navigate',
      targetPageId: newPageId,
    });

    setIsAddingSubPage(false);
    setSubPageTitle('');
  };

  const sortedComponents = [...currentPage.components].sort((a, b) => a.order - b.order);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-3xl bg-stone-900 border border-stone-700 rounded-3xl p-5 sm:p-7 shadow-2xl space-y-5 my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-800 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-bold text-stone-100">
                Pengaturan Halaman: {currentPage.title}
              </h3>
            </div>
            <p className="text-xs text-stone-400 mt-0.5">
              ID Halaman: <code className="text-amber-400 font-mono">{currentPage.id}</code> · {currentPage.isHomePage ? 'Halaman Utama (Start APK)' : 'Halaman Biasa'}
            </p>
          </div>

          <button
            onClick={closePageSettingsModal}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto space-y-5 pr-1 text-xs sm:text-sm">
          {/* Section 1: Page Details Form */}
          <form onSubmit={handleSavePageDetails} className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-amber-400 uppercase tracking-wider text-[11px]">
                Identitas & Tipe Tampilan Halaman
              </h4>
              <button
                type="submit"
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer shadow"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Simpan Perubahan Nama</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  Nama / Judul Halaman *
                </label>
                <input
                  type="text"
                  required
                  value={pageTitle}
                  onChange={(e) => setPageTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-stone-300 font-medium mb-1">
                  Format Tata Letak (Layout Type)
                </label>
                <select
                  value={layoutType}
                  onChange={(e) => setLayoutType(e.target.value as PageLayoutType)}
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                >
                  <option value="5_vertical_cards">5 Kolom Memanjang Vertikal (1 Layar Penuh)</option>
                  <option value="flow_list">Daftar Mengalir (Flow List)</option>
                  <option value="grid">Grid Responsif (2-3 Kolom)</option>
                  <option value="detail_content">Konten Detail Silsilah</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-stone-300 font-medium mb-1">
                Deskripsi / Keterangan Halaman
              </label>
              <input
                type="text"
                value={pageDescription}
                onChange={(e) => setPageDescription(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
          </form>

          {/* Section 2: Component Management on this page */}
          <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h4 className="font-semibold text-stone-100 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-amber-400" />
                  <span>Komponen di Halaman Ini ({currentPage.components.length})</span>
                </h4>
                <p className="text-xs text-stone-400">
                  Ubah urutan, ubah nama, aktif/nonaktifkan fungsi, atau buka editor detail.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsAddingComp((p) => !p)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs shadow cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isAddingComp ? 'Batal Tambah' : 'Tambah Tombol / Komponen'}</span>
              </button>
            </div>

            {/* Quick Add Component Inline Form */}
            {isAddingComp && (
              <form
                onSubmit={handleCreateComponent}
                className="p-4 rounded-xl bg-stone-900 border border-amber-500/40 space-y-3 animate-in fade-in duration-200"
              >
                <h5 className="font-bold text-amber-400 text-xs">Tambah Komponen Baru</h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-300 text-xs mb-1">Nama Tombol/Komponen *</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Telusuri Cabang Leluhur"
                      value={newCompName}
                      onChange={(e) => setNewCompName(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-700 text-stone-100 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-300 text-xs mb-1">Jenis Komponen</label>
                    <select
                      value={newCompType}
                      onChange={(e) => setNewCompType(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-700 text-stone-100 text-xs"
                    >
                      <option value="button">Tombol Aksi (Button)</option>
                      <option value="vertical_card">Kolom Memanjang Vertikal</option>
                      <option value="card_item">Kartu Konten (Card Item)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-300 text-xs mb-1">Fungsi Ketika Diklik</label>
                    <select
                      value={newCompAction}
                      onChange={(e) => setNewCompAction(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-700 text-stone-100 text-xs"
                    >
                      <option value="navigate">Pindah ke Halaman Lain</option>
                      <option value="toast">Tampilkan Pesan / Notifikasi</option>
                      <option value="none">Tanpa Fungsi (Hanya Tampilan)</option>
                    </select>
                  </div>

                  {newCompAction === 'navigate' && (
                    <div>
                      <label className="block text-stone-300 text-xs mb-1">Halaman Tujuan</label>
                      <select
                        value={newCompTargetPage}
                        onChange={(e) => setNewCompTargetPage(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-amber-600/40 text-amber-300 text-xs font-semibold"
                      >
                        <option value="">-- Pilih Halaman --</option>
                        {rootConfig.pages.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.title}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsAddingComp(false)}
                    className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-400 text-xs"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-amber-600 text-stone-950 font-bold text-xs shadow"
                  >
                    Simpan Komponen
                  </button>
                </div>
              </form>
            )}

            {/* List of Components */}
            <div className="space-y-2 pt-1">
              {sortedComponents.length === 0 ? (
                <div className="p-4 text-center text-stone-400 text-xs bg-stone-900/50 rounded-xl">
                  Belum ada komponen di halaman ini. Klik "Tambah Tombol / Komponen" di atas.
                </div>
              ) : (
                sortedComponents.map((c, index) => (
                  <div
                    key={c.id}
                    className="p-3 rounded-xl bg-stone-900/80 border border-stone-800 flex items-center justify-between gap-3 hover:border-amber-500/40 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="p-2 rounded-lg bg-stone-950 text-amber-400 shrink-0">
                        {renderIconByName(c.icon, 'w-4 h-4')}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-stone-100 text-xs sm:text-sm truncate">
                            {c.name}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-stone-800 text-stone-400 font-mono">
                            {c.type}
                          </span>
                          {!c.isEnabled && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-950/60 text-red-400 border border-red-800/40">
                              Nonaktif
                            </span>
                          )}
                          {!c.isVisible && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-stone-800 text-stone-400">
                              Tersembunyi
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-stone-400 mt-0.5 truncate">
                          Fungsi: <span className="text-amber-400/90">{c.actionType}</span>{' '}
                          {c.targetPageId ? `→ ${c.targetPageId}` : ''}
                        </p>
                      </div>
                    </div>

                    {/* Actions: Reorder, Edit, Duplicate, Delete */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => moveComponentOrder(currentPage.id, c.id, 'up')}
                        disabled={index === 0}
                        className="p-1.5 rounded-lg text-stone-400 hover:text-stone-100 hover:bg-stone-800 disabled:opacity-30"
                        title="Geser Naik"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => moveComponentOrder(currentPage.id, c.id, 'down')}
                        disabled={index === sortedComponents.length - 1}
                        className="p-1.5 rounded-lg text-stone-400 hover:text-stone-100 hover:bg-stone-800 disabled:opacity-30"
                        title="Geser Turun"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => duplicateComponent(currentPage.id, c.id)}
                        className="p-1.5 rounded-lg text-stone-400 hover:text-amber-300 hover:bg-stone-800"
                        title="Gandakan Komponen"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          closePageSettingsModal();
                          openComponentEditor(currentPage.id, c);
                        }}
                        className="p-1.5 rounded-lg text-amber-400 hover:bg-stone-800"
                        title="Edit Properti Lengkap (Warna, Font, Ikon, Ukuran)"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => deleteComponent(currentPage.id, c.id)}
                        className="p-1.5 rounded-lg text-stone-500 hover:text-red-400 hover:bg-stone-800"
                        title="Hapus Komponen"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Section 3: Sub-page hierarchy creator */}
          <div className="p-4 rounded-2xl bg-stone-950/60 border border-stone-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-stone-100 flex items-center gap-1.5">
                  <FilePlus className="w-4 h-4 text-emerald-400" />
                  <span>Buat Sub-Halaman Bersarang (Hierarki Silsilah)</span>
                </h4>
                <p className="text-xs text-stone-400">
                  Contoh: Dari "{currentPage.title}" → Buat halaman turunan seperti "Trah Adam", "Anak Adam", dll.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsAddingSubPage((p) => !p)}
                className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs cursor-pointer shadow"
              >
                {isAddingSubPage ? 'Batal' : '+ Buat Sub-Halaman'}
              </button>
            </div>

            {isAddingSubPage && (
              <form onSubmit={handleCreateSubPage} className="p-3 rounded-xl bg-stone-900 border border-emerald-500/40 space-y-3">
                <div>
                  <label className="block text-stone-300 text-xs mb-1">Judul Sub-Halaman Baru *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Cabang Keturunan Adam"
                    value={subPageTitle}
                    onChange={(e) => setSubPageTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-700 text-stone-100 text-xs"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingSubPage(false)}
                    className="px-3 py-1 rounded bg-stone-800 text-stone-400 text-xs"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-3.5 py-1 rounded bg-emerald-600 text-white font-bold text-xs"
                  >
                    Buat & Tautkan Sekarang
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-stone-800 flex items-center justify-between shrink-0">
          {!currentPage.isHomePage ? (
            <button
              type="button"
              onClick={() => {
                if (window.confirm(`Yakin ingin menghapus halaman "${currentPage.title}"?`)) {
                  deletePage(currentPage.id);
                  closePageSettingsModal();
                }
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-800/40 text-xs font-medium"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus Halaman Ini</span>
            </button>
          ) : (
            <span className="text-xs text-stone-500 italic">
              Halaman Utama tidak dapat dihapus
            </span>
          )}

          <button
            onClick={closePageSettingsModal}
            className="px-5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-100 font-bold text-xs"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
