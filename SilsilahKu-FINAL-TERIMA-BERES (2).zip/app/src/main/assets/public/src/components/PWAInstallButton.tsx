import React, { useState } from 'react';
import { usePWAInstall } from '../utils/usePWAInstall';
import { Smartphone, Download, X } from 'lucide-react';

export const PWAInstallButton: React.FC<{ variant?: 'header' | 'drawer' | 'modal' }> = ({ variant = 'header' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  // Chromium / Android flow
  if (isInstallable) {
    if (variant === 'drawer') {
      return (
        <button
          type="button"
          onClick={install}
          className="w-full text-left px-3 py-2.5 rounded-xl bg-gradient-to-r from-emerald-700/60 to-emerald-600/60 hover:from-emerald-700 hover:to-emerald-600 text-emerald-200 border border-emerald-500/60 transition-all cursor-pointer flex items-center justify-between font-bold my-1 shadow-md active:scale-98"
        >
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span>📲 Pasang Aplikasi di HP</span>
          </div>
          <span className="text-[10px] bg-emerald-500 text-stone-950 px-2 py-0.5 rounded font-black">
            INSTAL
          </span>
        </button>
      );
    }

    if (variant === 'modal') {
      return (
        <button
          type="button"
          onClick={install}
          className="w-full py-3 px-3.5 rounded-xl bg-gradient-to-r from-emerald-600/40 to-emerald-700/40 hover:from-emerald-600/60 hover:to-emerald-700/60 text-emerald-200 border-2 border-emerald-500/70 font-bold flex items-center justify-between text-left transition-all cursor-pointer shadow-lg active:scale-98 my-2"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-300">
              <Smartphone className="w-5 h-5 text-emerald-400 shrink-0" />
            </div>
            <div>
              <span className="block text-xs font-black text-emerald-300">
                📲 Pasang Aplikasi SilsilahKu di HP
              </span>
              <span className="block text-[10px] text-emerald-400/90">
                Langsung muncul di menu aplikasi HP Android Anda
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500 text-stone-950 font-bold text-[11px] shadow">
            <Download className="w-3.5 h-3.5" />
            <span>Pasang</span>
          </div>
        </button>
      );
    }

    // Default Header button
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/50 text-xs font-bold transition-all shadow cursor-pointer active:scale-95"
        title="Pasang Aplikasi di HP Android"
      >
        <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
        <span className="hidden sm:inline">Pasang di HP</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 text-xs font-semibold cursor-pointer"
        >
          <Smartphone className="w-3.5 h-3.5 text-stone-400" />
          <span>Pasang di iOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
            <div className="w-full max-w-sm rounded-2xl bg-stone-900 border border-stone-700 p-5 shadow-2xl text-stone-100 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-amber-400">Pasang di iPhone / iPad</h3>
                <button onClick={() => setShowIOSGuide(false)} className="text-stone-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-stone-300 leading-relaxed">
                1. Ketuk tombol <strong>Share (Bagikan)</strong> di bilah bawah browser Safari.<br />
                2. Gulir ke bawah lalu pilih <strong>Add to Home Screen (Tambahkan ke Layar Utama)</strong>.
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
