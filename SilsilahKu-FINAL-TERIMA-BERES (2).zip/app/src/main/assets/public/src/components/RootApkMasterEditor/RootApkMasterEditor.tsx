import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Sliders,
  Layers,
  Code2,
  Settings,
  Plus,
  Trash2,
  Copy,
  Undo2,
  Redo2,
  Eye,
  EyeOff,
  Save,
  RotateCcw,
  Sparkles,
  ArrowUp,
  ArrowDown,
  Check,
  Power,
  Camera,
  Maximize2,
  Link,
  Type,
  Palette,
  Layout,
  Move,
  Search,
  ChevronDown,
  ChevronRight,
  FileCode,
  FilePlus,
  Lock,
  Globe,
  HelpCircle,
  FolderTree,
  AlertTriangle,
  Download,
  Clipboard,
  ShieldCheck,
  HardDrive,
  Database,
  Upload,
  FileJson,
  CheckCircle2,
  FolderArchive,
} from 'lucide-react';
import { PRIMARY_COLOR_OPTIONS, WALLPAPER_PRESETS, CARD_THEME_OPTIONS, DEFAULT_WALLPAPER } from '../../data/initialData';
import { AVAILABLE_ICONS, renderIconByName } from '../../utils/iconMap';
import {
  UIComponent,
  ComponentType,
  ComponentActionType,
  CardSize,
  ComponentPosition,
  BlurLevel,
  FontFamilyType,
  PageLayoutType,
  AppPage,
  ElementStyleConfig,
} from '../../types';

export const RootApkMasterEditor: React.FC = () => {
  const {
    isRootApkModalOpen,
    closeRootApkModal,
    rootApkInitialTab,
    rootConfig,
    updateRootConfig,
    updateGlobalTheme,
    updateProfile,
    enableAppLock,
    disableAppLock,
    changePasscode,
    setWallpaperPreset,
    showToast,
    lockNow,
    setAvatarFromFile,
    canUndo,
    canRedo,
    undo,
    redo,
    addPage,
    deletePage,
    updatePage,
    addComponentToPage,
    updateComponent,
    deleteComponent,
    duplicateComponent,
    detachComponentAction,
    moveComponentOrder,
    executeComponentAction,
    selectedPageIdInEditor,
    setSelectedPageIdInEditor,
    selectedElementIdInEditor,
    setSelectedElementIdInEditor,
    resetToDefaultConfig,
    familyMembers,
    openPersonModal,
    exportConfigAsJson,
    downloadBackupJson,
    importConfigFromJson,
  } = useApp();

  // Top Level Studio Mode
  const [activeStudioTab, setActiveStudioTab] = useState<
    'visual_editor' | 'inspector' | 'code' | 'backup' | 'global_settings'
  >('visual_editor');

  // Preview vs Editor toggle inside Root Studio
  const [editorPreviewMode, setEditorPreviewMode] = useState<'editor' | 'preview'>('editor');

  // Code Inspector tab
  const [activeCodeTab, setActiveCodeTab] = useState<'html' | 'css' | 'js' | 'bundle'>('bundle');

  // Modals inside Studio
  const [isAddElementModalOpen, setIsAddElementModalOpen] = useState(false);
  const [isAddPageModalOpen, setIsAddPageModalOpen] = useState(false);
  const [confirmDeleteElement, setConfirmDeleteElement] = useState<UIComponent | null>(null);
  const [confirmDeletePage, setConfirmDeletePage] = useState<AppPage | null>(null);
  const [confirmResetFactory, setConfirmResetFactory] = useState(false);
  const [backupRestoreConfirmOpen, setBackupRestoreConfirmOpen] = useState(false);
  const [pendingRestoreJson, setPendingRestoreJson] = useState<string>('');
  const backupFileInputRef = useRef<HTMLInputElement>(null);

  // Inspector search filter
  const [inspectorFilter, setInspectorFilter] = useState('');

  // Forms for Global Settings
  const [appTitle, setAppTitle] = useState(rootConfig.appTitle);
  const [appSubtitle, setAppSubtitle] = useState(rootConfig.appSubtitle);
  const [appIcon, setAppIcon] = useState(rootConfig.appIcon);
  const [blurVal, setBlurVal] = useState<BlurLevel>(rootConfig.globalTheme.blur);
  const [cardOpacityVal, setCardOpacityVal] = useState(rootConfig.globalTheme.cardOpacity);
  const [cardSizeVal, setCardSizeVal] = useState<CardSize>(rootConfig.globalTheme.cardSize);
  const [fontFamilyVal, setFontFamilyVal] = useState<FontFamilyType>(rootConfig.globalTheme.fontFamily);
  const [fontSizeVal, setFontSizeVal] = useState(rootConfig.globalTheme.fontSizeValue);
  const [primaryColorVal, setPrimaryColorVal] = useState(rootConfig.globalTheme.primaryColor);
  const [primaryColorNameVal, setPrimaryColorNameVal] = useState(rootConfig.globalTheme.primaryColorName);

  // Profil Form
  const [profileName, setProfileName] = useState(rootConfig.profile.name);
  const [profileTitle, setProfileTitle] = useState(rootConfig.profile.title || '');
  const [profileBio, setProfileBio] = useState(rootConfig.profile.bio || '');
  const [profileBranch, setProfileBranch] = useState(rootConfig.profile.familyBranch || '');

  // App Lock Form
  const [isLockEnabled, setIsLockEnabled] = useState(rootConfig.appLock.isEnabled);
  const [currentPasscodeAttempt, setCurrentPasscodeAttempt] = useState('');
  const [newPasscode, setNewPasscode] = useState('');
  const [confirmPasscode, setConfirmPasscode] = useState('');
  const [passcodeHint, setPasscodeHint] = useState(rootConfig.appLock.hint || '');
  const [showPassText, setShowPassText] = useState(false);

  const avatarInputRef = useRef<HTMLInputElement>(null);

  // Sync state when open
  useEffect(() => {
    if (isRootApkModalOpen) {
      if (rootApkInitialTab === 'inspector') {
        setActiveStudioTab('inspector');
      } else if (rootApkInitialTab === 'code') {
        setActiveStudioTab('code');
      } else if (
        rootApkInitialTab === 'identitas' ||
        rootApkInitialTab === 'tampilan' ||
        rootApkInitialTab === 'font_teks' ||
        rootApkInitialTab === 'warna_tema' ||
        rootApkInitialTab === 'profil' ||
        rootApkInitialTab === 'kunci_aplikasi'
      ) {
        setActiveStudioTab('global_settings');
      } else {
        setActiveStudioTab('visual_editor');
      }

      setAppTitle(rootConfig.appTitle);
      setAppSubtitle(rootConfig.appSubtitle);
      setAppIcon(rootConfig.appIcon);
      setBlurVal(rootConfig.globalTheme.blur);
      setCardOpacityVal(rootConfig.globalTheme.cardOpacity);
      setCardSizeVal(rootConfig.globalTheme.cardSize);
      setFontFamilyVal(rootConfig.globalTheme.fontFamily);
      setFontSizeVal(rootConfig.globalTheme.fontSizeValue);
      setPrimaryColorVal(rootConfig.globalTheme.primaryColor);
      setPrimaryColorNameVal(rootConfig.globalTheme.primaryColorName);
      setProfileName(rootConfig.profile.name);
      setProfileTitle(rootConfig.profile.title || '');
      setProfileBio(rootConfig.profile.bio || '');
      setProfileBranch(rootConfig.profile.familyBranch || '');
      setIsLockEnabled(rootConfig.appLock.isEnabled);
      setPasscodeHint(rootConfig.appLock.hint || '');
      setCurrentPasscodeAttempt('');
      setNewPasscode('');
      setConfirmPasscode('');
    }
  }, [isRootApkModalOpen, rootApkInitialTab, rootConfig]);

  // Current active page in Studio
  const activePage =
    rootConfig.pages.find((p) => p.id === selectedPageIdInEditor) ||
    rootConfig.pages.find((p) => p.isHomePage) ||
    rootConfig.pages[0];

  // Current selected element in Studio
  const selectedElement = activePage.components.find(
    (c) => c.id === selectedElementIdInEditor
  );

  if (!isRootApkModalOpen) return null;

  // --- SAVE HANDLERS ---
  const handleSaveGlobalIdentity = (e: React.FormEvent) => {
    e.preventDefault();
    updateRootConfig({
      appTitle: appTitle.trim(),
      appSubtitle: appSubtitle.trim(),
      appIcon,
    });
    showToast('✅ Identitas Aplikasi tersimpan');
  };

  const handleSaveAppearance = (e: React.FormEvent) => {
    e.preventDefault();
    updateGlobalTheme({
      blur: blurVal,
      cardOpacity: cardOpacityVal,
      cardSize: cardSizeVal,
      fontFamily: fontFamilyVal,
      fontSizeValue: fontSizeVal,
      primaryColor: primaryColorVal,
      primaryColorName: primaryColorNameVal,
    });
    showToast('✅ Pengaturan Tampilan & Tema tersimpan');
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: profileName.trim(),
      title: profileTitle.trim(),
      bio: profileBio.trim(),
      familyBranch: profileBranch.trim(),
    });
    showToast('✅ Profil Aplikasi tersimpan');
  };

  const handleSaveAppLock = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLockEnabled !== rootConfig.appLock.isEnabled) {
      if (!isLockEnabled) {
        if (currentPasscodeAttempt.trim() !== rootConfig.appLock.passcode.trim()) {
          showToast('❌ Kode sandi saat ini salah!');
          return;
        }
        disableAppLock(currentPasscodeAttempt);
        return;
      } else {
        if (!newPasscode.trim()) {
          showToast('❌ Masukkan kode sandi baru terlebih dahulu!');
          return;
        }
        if (newPasscode !== confirmPasscode) {
          showToast('❌ Konfirmasi kode sandi tidak cocok!');
          return;
        }
        enableAppLock(newPasscode.trim(), passcodeHint.trim());
        return;
      }
    }

    if (isLockEnabled && newPasscode.trim().length > 0) {
      if (currentPasscodeAttempt.trim() !== rootConfig.appLock.passcode.trim()) {
        showToast('❌ Kode sandi saat ini salah!');
        return;
      }
      if (newPasscode !== confirmPasscode) {
        showToast('❌ Konfirmasi kode sandi tidak cocok!');
        return;
      }
      changePasscode(currentPasscodeAttempt, newPasscode.trim());
      updateRootConfig({
        appLock: {
          ...rootConfig.appLock,
          passcode: newPasscode.trim(),
          hint: passcodeHint.trim(),
        },
      });
      return;
    }

    updateRootConfig({
      appLock: {
        ...rootConfig.appLock,
        hint: passcodeHint.trim(),
      },
    });
    showToast('✅ Pengaturan Kunci Aplikasi tersimpan');
  };

  // --- ELEMENT PROPERTY UPDATER ---
  const handleUpdateSelectedElement = (updates: Partial<UIComponent>) => {
    if (!selectedElement) return;
    updateComponent(activePage.id, selectedElement.id, updates);
  };

  const handleUpdateElementStyle = (styleUpdates: Partial<ElementStyleConfig>) => {
    if (!selectedElement) return;
    const currentStyle = selectedElement.style || {};
    updateComponent(activePage.id, selectedElement.id, {
      style: {
        ...currentStyle,
        ...styleUpdates,
      },
    });
  };

  // --- CODE GENERATOR ---
  const generatePageHtml = () => {
    return `<!-- Root APK Engine Generated View: ${activePage.title} (${activePage.id}) -->
<div id="${activePage.id}" class="app-page layout-${activePage.layoutType}" data-slug="${activePage.slug}">
  <header class="page-header">
    <h1 class="page-title">${activePage.title}</h1>
    <p class="page-desc">${activePage.description || ''}</p>
  </header>

  <main class="page-body">
${activePage.components
  .map((c) => {
    return `    <div id="${c.id}" class="app-element element-${c.type} pos-${c.position}" data-action="${c.actionType}">
      <span class="element-name">${c.name}</span>
      ${c.subtitle ? `<span class="element-sub">${c.subtitle}</span>` : ''}
      ${c.description ? `<p class="element-desc">${c.description}</p>` : ''}
    </div>`;
  })
  .join('\n')}
  </main>
</div>`;
  };

  const generatePageCss = () => {
    return `/* Root APK Generated CSS for #${activePage.id} */
#${activePage.id} {
  --primary-accent: ${rootConfig.globalTheme.primaryColor};
  --font-family: '${rootConfig.globalTheme.fontFamily}', sans-serif;
  --font-size: ${rootConfig.globalTheme.fontSizeValue}px;
  --card-opacity: ${rootConfig.globalTheme.cardOpacity}%;
  background: var(--bg-surface, #0c0a09);
  color: var(--text-primary, #f5f5f4);
}

${activePage.components
  .map((c) => {
    const s = c.style || {};
    return `#${c.id} {
  color: ${s.textColor || c.color || 'inherit'};
  background-color: ${s.backgroundColor || c.backgroundColor || 'rgba(28, 25, 23, 0.85)'};
  border-radius: ${s.borderRadius ?? 12}px;
  padding: ${s.paddingTop ?? 12}px ${s.paddingRight ?? 16}px ${s.paddingBottom ?? 12}px ${s.paddingLeft ?? 16}px;
  margin: ${s.marginTop ?? 4}px ${s.marginRight ?? 0}px ${s.marginBottom ?? 4}px ${s.marginLeft ?? 0}px;
  font-size: ${s.fontSize ? `${s.fontSize}px` : 'inherit'};
  font-weight: ${s.fontWeight || 'normal'};
  opacity: ${(s.transparency ?? c.transparency ?? 100) / 100};
  display: ${c.isVisible ? 'block' : 'none'};
}`;
  })
  .join('\n\n')}`;
  };

  const generatePageJs = () => {
    return `/**
 * Root APK Event & Action Dispatcher
 * Page: ${activePage.title} (${activePage.id})
 */
(function() {
  const pageContainer = document.getElementById('${activePage.id}');
  if (!pageContainer) return;

  const actions = {
${activePage.components
  .map((c) => {
    if (c.actionType === 'navigate') {
      return `    '${c.id}': function() { AppRouter.navigate('${c.targetPageId}'); },`;
    }
    if (c.actionType === 'toast') {
      return `    '${c.id}': function() { Toast.show("${c.actionPayload || 'Aksi berhasil'}"); },`;
    }
    if (c.actionType === 'open_url') {
      return `    '${c.id}': function() { window.open("${c.actionPayload}", "_blank"); },`;
    }
    if (c.actionType === 'custom_js' && c.customJsCode) {
      return `    '${c.id}': function() { ${c.customJsCode} },`;
    }
    return `    '${c.id}': function() { /* No function (Detached) */ },`;
  })
  .join('\n')}
  };

  pageContainer.addEventListener('click', function(e) {
    const target = e.target.closest('.app-element');
    if (target && actions[target.id]) {
      actions[target.id]();
    }
  });
})();`;
  };

  const generateCombinedBundle = () => {
    return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>${rootConfig.appTitle} - ${activePage.title}</title>
  <!-- GLOBAL DEPENDENCY: Google Fonts & Root Theme Palette -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Plus+Jakarta+Sans:wght@400;600;700&family=Playfair+Display:wght@600&family=Lora:wght@500&display=swap" rel="stylesheet">
  <style>
${generatePageCss()}
  </style>
</head>
<body>
${generatePageHtml()}

<script>
${generatePageJs()}
</script>
</body>
</html>`;
  };

  const handleCopyCode = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    showToast(`📋 ${label} berhasil disalin ke clipboard!`);
  };

  const handleExportBundleFile = () => {
    const bundle = generateCombinedBundle();
    const blob = new Blob([bundle], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activePage.slug || 'halaman'}_root_apk_export.html`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('💾 Berkas ekspor HTML+CSS+JS berhasil diunduh');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-2.5 bg-black/90 backdrop-blur-md select-none animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <input
        type="file"
        ref={avatarInputRef}
        onChange={async (e) => {
          const file = e.target.files?.[0];
          if (file) await setAvatarFromFile(file);
          e.target.value = '';
        }}
        accept="image/*"
        className="hidden"
      />

      <input
        type="file"
        ref={backupFileInputRef}
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          const reader = new FileReader();
          reader.onload = (event) => {
            const text = event.target?.result as string;
            if (text) {
              setPendingRestoreJson(text);
              setBackupRestoreConfirmOpen(true);
            }
          };
          reader.readAsText(file);
          e.target.value = '';
        }}
        accept=".json,application/json"
        className="hidden"
      />

      <div className="w-full h-full max-w-[98vw] max-h-[96vh] bg-stone-950 border border-stone-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-stone-100">
        {/* =========================================================================
            HEADER BAR: App Brand, Studio Mode Switcher, Undo/Redo, Page Picker, Actions
           ========================================================================= */}
        <header className="h-13 px-3 sm:px-4 bg-stone-900/90 border-b border-stone-800 flex items-center justify-between gap-2 shrink-0 z-20">
          {/* Brand & Studio Mode Tabs */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex items-center gap-1.5 shrink-0">
              <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <Sliders className="w-4 h-4" />
              </div>
              <div className="hidden md:block">
                <span className="font-extrabold text-xs text-stone-100 tracking-tight block leading-tight">
                  ROOT APK
                </span>
                <span className="text-[10px] text-amber-400 font-mono block leading-tight">
                  Master Control Studio
                </span>
              </div>
            </div>

            {/* Studio Mode Selector Tabs */}
            <div className="flex items-center bg-stone-950 p-0.5 rounded-xl border border-stone-800 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveStudioTab('visual_editor')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeStudioTab === 'visual_editor'
                    ? 'bg-amber-600 text-stone-950 font-bold shadow'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                <Layout className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">🛠 Visual Editor</span>
                <span className="sm:hidden">Editor</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveStudioTab('inspector')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeStudioTab === 'inspector'
                    ? 'bg-amber-600 text-stone-950 font-bold shadow'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                <FolderTree className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">🔍 Inspector</span>
                <span className="sm:hidden">Tree</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveStudioTab('code')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeStudioTab === 'code'
                    ? 'bg-amber-600 text-stone-950 font-bold shadow'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                <Code2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">💻 Kode Studio</span>
                <span className="sm:hidden">Kode</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveStudioTab('backup')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeStudioTab === 'backup'
                    ? 'bg-amber-600 text-stone-950 font-bold shadow'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                <Database className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">💾 Snapshot Backup</span>
                <span className="sm:hidden">Backup</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveStudioTab('global_settings')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeStudioTab === 'global_settings'
                    ? 'bg-amber-600 text-stone-950 font-bold shadow'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">⚙ Global & Sandi</span>
                <span className="sm:hidden">Setelan</span>
              </button>
            </div>
          </div>

          {/* Center: Page Selector Dropdown */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-stone-950 px-2 py-1 rounded-xl border border-stone-800 text-xs">
              <span className="text-stone-400 text-[11px] hidden lg:inline">Halaman:</span>
              <select
                value={selectedPageIdInEditor}
                onChange={(e) => {
                  setSelectedPageIdInEditor(e.target.value);
                  setSelectedElementIdInEditor(null);
                }}
                className="bg-transparent text-amber-300 font-bold text-xs focus:outline-none cursor-pointer pr-2"
              >
                {rootConfig.pages.map((p) => (
                  <option key={p.id} value={p.id} className="bg-stone-900 text-stone-100">
                    {p.isHomePage ? '🏠 ' : '📄 '}
                    {p.title} ({p.id})
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => setIsAddPageModalOpen(true)}
                className="p-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-400 transition-colors"
                title="Tambah Halaman Baru"
              >
                <Plus className="w-3 h-3" />
              </button>
            </div>

            {/* Undo / Redo controls */}
            <div className="flex items-center gap-1 bg-stone-950 p-0.5 rounded-xl border border-stone-800">
              <button
                type="button"
                onClick={undo}
                disabled={!canUndo}
                className="p-1.5 rounded-lg text-stone-300 hover:text-white hover:bg-stone-800 disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer"
                title="↶ Undo Perubahan"
              >
                <Undo2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={redo}
                disabled={!canRedo}
                className="p-1.5 rounded-lg text-stone-300 hover:text-white hover:bg-stone-800 disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer"
                title="↷ Redo Perubahan"
              >
                <Redo2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right: Preview/Editor Mode & Close */}
          <div className="flex items-center gap-2 shrink-0">
            {activeStudioTab === 'visual_editor' && (
              <div className="flex items-center bg-stone-950 p-0.5 rounded-xl border border-stone-800 text-xs">
                <button
                  type="button"
                  onClick={() => setEditorPreviewMode('editor')}
                  className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                    editorPreviewMode === 'editor'
                      ? 'bg-amber-600 text-stone-950 font-bold'
                      : 'text-stone-400 hover:text-white'
                  }`}
                  title="Mode Pengeditan Visual"
                >
                  ✏ Editor
                </button>
                <button
                  type="button"
                  onClick={() => setEditorPreviewMode('preview')}
                  className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                    editorPreviewMode === 'preview'
                      ? 'bg-amber-600 text-stone-950 font-bold'
                      : 'text-stone-400 hover:text-white'
                  }`}
                  title="Mode Preview Uji Fungsi"
                >
                  👁 Preview
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={() => {
                showToast('💾 Seluruh konfigurasi telah tersimpan');
              }}
              className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow transition-all active:scale-95"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Simpan</span>
            </button>

            <button
              type="button"
              onClick={closeRootApkModal}
              className="p-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white transition-colors cursor-pointer"
              title="Tutup Studio"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* =========================================================================
            MAIN WORKSPACE BODY
           ========================================================================= */}
        <div className="flex-1 flex overflow-hidden">
          {/* TAB 1: VISUAL APP EDITOR */}
          {activeStudioTab === 'visual_editor' && (
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
              {/* Visual Canvas Area */}
              <div className="flex-1 flex flex-col bg-stone-950/80 overflow-hidden relative border-r border-stone-800">
                {/* Canvas Toolbar */}
                <div className="h-9 px-3 bg-stone-900/60 border-b border-stone-800 flex items-center justify-between text-xs text-stone-400">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] text-amber-400 font-bold">
                      Canvas: {activePage.title}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-stone-800 text-stone-300 font-mono">
                      {activePage.components.length} Elemen
                    </span>
                    <span className="text-[10px] text-stone-500 font-mono">
                      Layout: {activePage.layoutType}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setIsAddElementModalOpen(true)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-[11px] cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Tambah Elemen</span>
                    </button>

                    {!activePage.isHomePage && (
                      <button
                        type="button"
                        onClick={() => setConfirmDeletePage(activePage)}
                        className="p-1 rounded-lg text-stone-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                        title="Hapus Halaman Ini"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Interactive Live Page Canvas Container */}
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex flex-col items-center">
                  <div
                    className="w-full max-w-3xl min-h-[500px] bg-stone-900/70 border border-stone-800 rounded-2xl p-4 sm:p-6 shadow-2xl relative transition-all"
                    style={{
                      fontFamily: rootConfig.globalTheme.fontFamily,
                      fontSize: `${rootConfig.globalTheme.fontSizeValue}px`,
                    }}
                  >
                    {/* Page Header Area */}
                    <div
                      onClick={() => setSelectedElementIdInEditor(null)}
                      className="pb-4 mb-4 border-b border-stone-800/80 cursor-pointer flex items-center justify-between group"
                    >
                      <div>
                        <h2 className="text-xl font-bold text-stone-100 flex items-center gap-2">
                          <span>{activePage.title}</span>
                          {editorPreviewMode === 'editor' && (
                            <span className="text-[10px] font-mono font-normal px-1.5 py-0.5 rounded bg-stone-800 text-stone-400">
                              #{activePage.id}
                            </span>
                          )}
                        </h2>
                        {activePage.description && (
                          <p className="text-xs text-stone-400 mt-0.5">{activePage.description}</p>
                        )}
                      </div>

                      {editorPreviewMode === 'editor' && (
                        <span className="text-[11px] text-amber-400/80 font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                          Klik untuk Setelan Halaman
                        </span>
                      )}
                    </div>

                    {/* Components List Render */}
                    {activePage.components.length === 0 ? (
                      <div className="py-16 text-center border-2 border-dashed border-stone-800 rounded-2xl p-6">
                        <Layers className="w-10 h-10 text-stone-600 mx-auto mb-2" />
                        <h3 className="font-bold text-stone-300 text-sm">Halaman Masih Kosong</h3>
                        <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                          Tambahkan elemen teks, tombol navigasi, form, gambar, atau kontainer kustom ke halaman ini.
                        </p>
                        <button
                          type="button"
                          onClick={() => setIsAddElementModalOpen(true)}
                          className="mt-4 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer shadow"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>+ Tambah Elemen Pertama</span>
                        </button>
                      </div>
                    ) : (
                      <div
                        className={
                          activePage.layoutType === 'grid'
                            ? 'grid grid-cols-1 sm:grid-cols-2 gap-3'
                            : 'space-y-3'
                        }
                      >
                        {[...activePage.components]
                          .sort((a, b) => a.order - b.order)
                          .map((comp, idx) => {
                            const isSelected = selectedElementIdInEditor === comp.id;
                            const s = comp.style || {};

                            return (
                              <div
                                key={comp.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (editorPreviewMode === 'editor') {
                                    setSelectedElementIdInEditor(comp.id);
                                  } else {
                                    executeComponentAction(comp);
                                  }
                                }}
                                className={`relative group transition-all rounded-xl ${
                                  editorPreviewMode === 'editor'
                                    ? `cursor-pointer border-2 ${
                                        isSelected
                                          ? 'border-amber-400 ring-2 ring-amber-400/30 shadow-lg'
                                          : 'border-transparent hover:border-amber-500/50 hover:bg-stone-800/40'
                                      }`
                                    : 'cursor-pointer'
                                }`}
                                style={{
                                  marginTop: s.marginTop !== undefined ? `${s.marginTop}px` : undefined,
                                  marginBottom: s.marginBottom !== undefined ? `${s.marginBottom}px` : undefined,
                                  marginLeft: s.marginLeft !== undefined ? `${s.marginLeft}px` : undefined,
                                  marginRight: s.marginRight !== undefined ? `${s.marginRight}px` : undefined,
                                  zIndex: s.zIndex ?? 1,
                                }}
                              >
                                {/* Editor Overlay Badge */}
                                {editorPreviewMode === 'editor' && (
                                  <div className="absolute -top-3 left-2 z-10 flex items-center gap-1">
                                    <span
                                      className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold ${
                                        isSelected
                                          ? 'bg-amber-400 text-stone-950'
                                          : 'bg-stone-800 text-stone-300 group-hover:bg-amber-600 group-hover:text-stone-950'
                                      }`}
                                    >
                                      #{comp.id} : {comp.type}
                                    </span>
                                    {comp.actionType !== 'none' && (
                                      <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-amber-950/90 text-amber-300 border border-amber-500/40">
                                        ⚡ {comp.actionType}
                                      </span>
                                    )}
                                    {!comp.isEnabled && (
                                      <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800">
                                        Nonaktif
                                      </span>
                                    )}
                                  </div>
                                )}

                                {/* Element Content Render */}
                                <div
                                  className="p-3.5 rounded-xl border flex items-center justify-between gap-3"
                                  style={{
                                    backgroundColor:
                                      s.backgroundColor ||
                                      comp.backgroundColor ||
                                      'rgba(28, 25, 23, 0.85)',
                                    borderColor: s.borderColor || comp.borderColor || '#38322e',
                                    borderWidth: s.borderWidth !== undefined ? `${s.borderWidth}px` : '1px',
                                    borderRadius: s.borderRadius !== undefined ? `${s.borderRadius}px` : '12px',
                                    color: s.textColor || comp.color || '#f5f5f4',
                                    textAlign: s.textAlign || 'left',
                                    fontSize: s.fontSize ? `${s.fontSize}px` : undefined,
                                    fontWeight: s.fontWeight || undefined,
                                    opacity: (s.transparency ?? comp.transparency ?? 100) / 100,
                                  }}
                                >
                                  <div className="flex items-center gap-3 min-w-0 flex-1">
                                    {comp.icon && (
                                      <div className="p-2 rounded-lg bg-stone-950/80 text-amber-400 shrink-0">
                                        {renderIconByName(comp.icon, 'w-4 h-4')}
                                      </div>
                                    )}

                                    <div className="min-w-0 flex-1">
                                      <span className="font-bold block truncate">{comp.name}</span>
                                      {comp.subtitle && (
                                        <span className="text-xs text-amber-400/90 block truncate">
                                          {comp.subtitle}
                                        </span>
                                      )}
                                      {comp.description && (
                                        <p className="text-[11px] text-stone-400 line-clamp-2 mt-0.5">
                                          {comp.description}
                                        </p>
                                      )}
                                    </div>
                                  </div>

                                  {/* Quick Editor Controls on Element Hover */}
                                  {editorPreviewMode === 'editor' && (
                                    <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          moveComponentOrder(activePage.id, comp.id, 'up');
                                        }}
                                        disabled={idx === 0}
                                        className="p-1 rounded bg-stone-800 hover:bg-stone-700 text-stone-300 disabled:opacity-30 cursor-pointer"
                                        title="Geser Naik"
                                      >
                                        <ArrowUp className="w-3 h-3" />
                                      </button>
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          moveComponentOrder(activePage.id, comp.id, 'down');
                                        }}
                                        disabled={idx === activePage.components.length - 1}
                                        className="p-1 rounded bg-stone-800 hover:bg-stone-700 text-stone-300 disabled:opacity-30 cursor-pointer"
                                        title="Geser Turun"
                                      >
                                        <ArrowDown className="w-3 h-3" />
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Property Inspector Panel */}
              <div className="w-full md:w-80 lg:w-96 bg-stone-900/90 flex flex-col overflow-y-auto shrink-0 border-l border-stone-800 text-xs">
                {selectedElement ? (
                  /* ELEMENT PROPERTY EDITOR */
                  <div className="p-4 space-y-4">
                    {/* Header: Element Title & Badges */}
                    <div className="pb-2 border-b border-stone-800 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider block">
                          Inspector Elemen
                        </span>
                        <h4 className="text-sm font-bold text-stone-100 truncate">
                          {selectedElement.name}
                        </h4>
                        <code className="text-[10px] text-stone-400 font-mono">
                          ID: {selectedElement.id}
                        </code>
                      </div>

                      <button
                        type="button"
                        onClick={() => setSelectedElementIdInEditor(null)}
                        className="text-stone-400 hover:text-stone-100 text-xs px-2 py-1 rounded bg-stone-800"
                      >
                        Batal Pilih
                      </button>
                    </div>

                    {/* Section 1: Identitas & Teks */}
                    <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 space-y-2.5">
                      <span className="font-bold text-stone-200 block">1. Identitas & Teks</span>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">ID Elemen (Unik)</label>
                        <input
                          type="text"
                          value={selectedElement.id}
                          onChange={(e) => handleUpdateSelectedElement({ id: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 font-mono text-amber-300 text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Nama / Label *</label>
                        <input
                          type="text"
                          value={selectedElement.name}
                          onChange={(e) => handleUpdateSelectedElement({ name: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-100 text-xs font-semibold"
                        />
                      </div>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Sub-judul (Opsional)</label>
                        <input
                          type="text"
                          value={selectedElement.subtitle || ''}
                          onChange={(e) => handleUpdateSelectedElement({ subtitle: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-100 text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Deskripsi / Teks Isi</label>
                        <textarea
                          rows={2}
                          value={selectedElement.description || ''}
                          onChange={(e) => handleUpdateSelectedElement({ description: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-100 text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Jenis Elemen</label>
                        <select
                          value={selectedElement.type}
                          onChange={(e) => handleUpdateSelectedElement({ type: e.target.value as any })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs"
                        >
                          <option value="button">Tombol Aksi (Button)</option>
                          <option value="text_block">Blok Teks (Text Block)</option>
                          <option value="heading">Judul Besar (Heading)</option>
                          <option value="card_item">Kartu Konten (Card Item)</option>
                          <option value="vertical_card">Kolom Memanjang Vertikal</option>
                          <option value="image">Gambar / Foto (Image)</option>
                          <option value="icon">Ikon (Icon)</option>
                          <option value="input_field">Input Teks (Input)</option>
                          <option value="container">Wadah / Box (Container)</option>
                          <option value="tab_bar">Tab Bar (Tab)</option>
                          <option value="dropdown">Menu Dropdown</option>
                          <option value="search_bar">Search Bar</option>
                          <option value="custom_component">Custom Component</option>
                        </select>
                      </div>
                    </div>

                    {/* Section 2: Fungsi & Aksi Klik */}
                    <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-stone-200 block">2. Fungsi & Aksi Klik</span>
                        <button
                          type="button"
                          onClick={() => detachComponentAction(activePage.id, selectedElement.id)}
                          className="text-[10px] text-rose-400 hover:text-rose-300 font-semibold"
                          title="Hapus fungsi aksi klik tetapi pertahankan tampilan"
                        >
                          [Hapus Fungsi]
                        </button>
                      </div>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Jenis Aksi</label>
                        <select
                          value={selectedElement.actionType}
                          onChange={(e) =>
                            handleUpdateSelectedElement({ actionType: e.target.value as ComponentActionType })
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs font-semibold"
                        >
                          <option value="navigate">Pindah ke Halaman (Navigate)</option>
                          <option value="open_person_detail">Buka Biodata Tokoh Silsilah</option>
                          <option value="toast">Tampilkan Notifikasi Toast</option>
                          <option value="open_popup">Tampilkan Popup Modal</option>
                          <option value="open_url">Buka Link Eksternal (URL)</option>
                          <option value="back">Kembali ke Halaman Sebelumnya</option>
                          <option value="edit_profile">Buka Halaman Profil</option>
                          <option value="custom_js">Jalankan Script JavaScript Kustom</option>
                          <option value="none">Tanpa Fungsi (Fungsi Dilepas / None)</option>
                        </select>
                      </div>

                      {selectedElement.actionType === 'navigate' && (
                        <div>
                          <label className="block text-stone-400 text-[11px] mb-1">Halaman Tujuan</label>
                          <select
                            value={selectedElement.targetPageId || ''}
                            onChange={(e) => handleUpdateSelectedElement({ targetPageId: e.target.value })}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-amber-600 text-amber-300 font-semibold text-xs"
                          >
                            <option value="">-- Pilih Halaman --</option>
                            {rootConfig.pages.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.title} ({p.id})
                              </option>
                            ))}
                          </select>
                        </div>
                      )}

                      {selectedElement.actionType === 'open_person_detail' && (
                        <div>
                          <label className="block text-stone-400 text-[11px] mb-1">Pilih Tokoh Silsilah</label>
                          <select
                            value={selectedElement.targetPersonId || ''}
                            onChange={(e) => handleUpdateSelectedElement({ targetPersonId: e.target.value })}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-amber-600 text-amber-300 text-xs font-semibold"
                          >
                            <option value="">-- Pilih Tokoh --</option>
                            {familyMembers.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name} (Gen {m.generation})
                              </option>
                            ))}
                          </select>
                        </div>
                      )}

                      {(selectedElement.actionType === 'toast' ||
                        selectedElement.actionType === 'open_popup' ||
                        selectedElement.actionType === 'open_url') && (
                        <div>
                          <label className="block text-stone-400 text-[11px] mb-1">
                            {selectedElement.actionType === 'open_url'
                              ? 'Alamat URL Link'
                              : 'Pesan / Teks Notifikasi'}
                          </label>
                          <input
                            type="text"
                            value={selectedElement.actionPayload || ''}
                            onChange={(e) => handleUpdateSelectedElement({ actionPayload: e.target.value })}
                            placeholder="Tulis pesan..."
                            className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-100 text-xs"
                          />
                        </div>
                      )}

                      {selectedElement.actionType === 'custom_js' && (
                        <div>
                          <label className="block text-stone-400 text-[11px] mb-1">Kode JS Kustom</label>
                          <textarea
                            rows={3}
                            value={selectedElement.customJsCode || ''}
                            onChange={(e) => handleUpdateSelectedElement({ customJsCode: e.target.value })}
                            placeholder="showToast('Halo dunia');"
                            className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-amber-300 font-mono text-[11px]"
                          />
                        </div>
                      )}
                    </div>

                    {/* Section 3: Tata Letak & Spasi (Posisi, Margin, Padding) */}
                    <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 space-y-2.5">
                      <span className="font-bold text-stone-200 block">3. Tata Letak & Posisi</span>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-stone-400 text-[11px] mb-1">Alignment</label>
                          <select
                            value={selectedElement.style?.textAlign || 'left'}
                            onChange={(e) =>
                              handleUpdateElementStyle({ textAlign: e.target.value as any })
                            }
                            className="w-full px-2 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs"
                          >
                            <option value="left">Rata Kiri</option>
                            <option value="center">Tengah</option>
                            <option value="right">Rata Kanan</option>
                            <option value="justify">Rata Kanan Kiri</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-stone-400 text-[11px] mb-1">Layer (Z-Index)</label>
                          <input
                            type="number"
                            min="0"
                            max="50"
                            value={selectedElement.style?.zIndex ?? 1}
                            onChange={(e) =>
                              handleUpdateElementStyle({ zIndex: Number(e.target.value) })
                            }
                            className="w-full px-2 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs font-mono"
                          />
                        </div>
                      </div>

                      {/* Margins */}
                      <div>
                        <span className="block text-stone-400 text-[11px] mb-1">Margin (Top / Bottom)</span>
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="number"
                            placeholder="Top (px)"
                            value={selectedElement.style?.marginTop ?? 4}
                            onChange={(e) =>
                              handleUpdateElementStyle({ marginTop: Number(e.target.value) })
                            }
                            className="px-2 py-1 rounded bg-stone-900 border border-stone-700 text-xs font-mono"
                          />
                          <input
                            type="number"
                            placeholder="Bottom (px)"
                            value={selectedElement.style?.marginBottom ?? 4}
                            onChange={(e) =>
                              handleUpdateElementStyle({ marginBottom: Number(e.target.value) })
                            }
                            className="px-2 py-1 rounded bg-stone-900 border border-stone-700 text-xs font-mono"
                          />
                        </div>
                      </div>

                      {/* Padding */}
                      <div>
                        <span className="block text-stone-400 text-[11px] mb-1">Padding (V / H)</span>
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="number"
                            placeholder="V Pad (px)"
                            value={selectedElement.style?.paddingTop ?? 12}
                            onChange={(e) =>
                              handleUpdateElementStyle({
                                paddingTop: Number(e.target.value),
                                paddingBottom: Number(e.target.value),
                              })
                            }
                            className="px-2 py-1 rounded bg-stone-900 border border-stone-700 text-xs font-mono"
                          />
                          <input
                            type="number"
                            placeholder="H Pad (px)"
                            value={selectedElement.style?.paddingLeft ?? 16}
                            onChange={(e) =>
                              handleUpdateElementStyle({
                                paddingLeft: Number(e.target.value),
                                paddingRight: Number(e.target.value),
                              })
                            }
                            className="px-2 py-1 rounded bg-stone-900 border border-stone-700 text-xs font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Section 4: Gaya, Warna, Radius, Border & Transparansi */}
                    <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 space-y-2.5">
                      <span className="font-bold text-stone-200 block">4. Warna, Border & Radius</span>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-stone-400 text-[11px] mb-1">Warna Teks</label>
                          <div className="flex items-center gap-1">
                            <input
                              type="color"
                              value={selectedElement.style?.textColor || selectedElement.color || '#f5f5f4'}
                              onChange={(e) => handleUpdateElementStyle({ textColor: e.target.value })}
                              className="w-7 h-7 rounded border border-stone-700 bg-transparent cursor-pointer"
                            />
                            <input
                              type="text"
                              value={selectedElement.style?.textColor || selectedElement.color || '#f5f5f4'}
                              onChange={(e) => handleUpdateElementStyle({ textColor: e.target.value })}
                              className="w-full px-1.5 py-1 rounded bg-stone-900 border border-stone-700 font-mono text-[10px]"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-stone-400 text-[11px] mb-1">Background</label>
                          <div className="flex items-center gap-1">
                            <input
                              type="color"
                              value={selectedElement.style?.backgroundColor || selectedElement.backgroundColor || '#1c1917'}
                              onChange={(e) => handleUpdateElementStyle({ backgroundColor: e.target.value })}
                              className="w-7 h-7 rounded border border-stone-700 bg-transparent cursor-pointer"
                            />
                            <input
                              type="text"
                              value={selectedElement.style?.backgroundColor || selectedElement.backgroundColor || '#1c1917'}
                              onChange={(e) => handleUpdateElementStyle({ backgroundColor: e.target.value })}
                              className="w-full px-1.5 py-1 rounded bg-stone-900 border border-stone-700 font-mono text-[10px]"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Radius & Border */}
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <div className="flex justify-between text-[11px] text-stone-400 mb-1">
                            <span>Radius</span>
                            <span className="font-mono text-amber-400">
                              {selectedElement.style?.borderRadius ?? 12}px
                            </span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="36"
                            value={selectedElement.style?.borderRadius ?? 12}
                            onChange={(e) =>
                              handleUpdateElementStyle({ borderRadius: Number(e.target.value) })
                            }
                            className="w-full accent-amber-500"
                          />
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] text-stone-400 mb-1">
                            <span>Transparansi</span>
                            <span className="font-mono text-amber-400">
                              {selectedElement.style?.transparency ?? selectedElement.transparency ?? 90}%
                            </span>
                          </div>
                          <input
                            type="range"
                            min="20"
                            max="100"
                            value={selectedElement.style?.transparency ?? selectedElement.transparency ?? 90}
                            onChange={(e) =>
                              handleUpdateElementStyle({ transparency: Number(e.target.value) })
                            }
                            className="w-full accent-amber-500"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Section 5: Visibilitas & Status Aktif */}
                    <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 space-y-2">
                      <span className="font-bold text-stone-200 block">5. Status & Visibilitas</span>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            handleUpdateSelectedElement({ isVisible: !selectedElement.isVisible })
                          }
                          className={`py-1.5 px-2 rounded-lg border flex items-center justify-center gap-1.5 font-semibold ${
                            selectedElement.isVisible
                              ? 'bg-stone-800 text-stone-200 border-stone-700'
                              : 'bg-stone-950 text-stone-500 border-stone-800'
                          }`}
                        >
                          {selectedElement.isVisible ? (
                            <>
                              <Eye className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Tampil</span>
                            </>
                          ) : (
                            <>
                              <EyeOff className="w-3.5 h-3.5 text-stone-500" />
                              <span>Sembunyi</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            handleUpdateSelectedElement({ isEnabled: !selectedElement.isEnabled })
                          }
                          className={`py-1.5 px-2 rounded-lg border flex items-center justify-center gap-1.5 font-semibold ${
                            selectedElement.isEnabled
                              ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800'
                              : 'bg-rose-950/40 text-rose-300 border-rose-800'
                          }`}
                        >
                          <Power className="w-3.5 h-3.5" />
                          <span>{selectedElement.isEnabled ? 'Fungsi Aktif' : 'Nonaktif'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Footer Actions: Duplicate & Delete */}
                    <div className="pt-2 border-t border-stone-800 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => duplicateComponent(activePage.id, selectedElement.id)}
                        className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5 text-amber-400" />
                        <span>Duplikat</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setConfirmDeleteElement(selectedElement)}
                        className="px-3 py-1.5 rounded-xl bg-rose-950/50 hover:bg-rose-900 text-rose-300 border border-rose-800/80 font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Hapus Elemen</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  /* PAGE PROPERTIES WHEN NO ELEMENT IS SELECTED */
                  <div className="p-4 space-y-4">
                    <div className="pb-2 border-b border-stone-800">
                      <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider block">
                        Pengaturan Halaman Aktif
                      </span>
                      <h4 className="text-sm font-bold text-stone-100">{activePage.title}</h4>
                      <code className="text-[10px] text-stone-400 font-mono">
                        ID: {activePage.id}
                      </code>
                    </div>

                    <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 space-y-3">
                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Judul Halaman *</label>
                        <input
                          type="text"
                          value={activePage.title}
                          onChange={(e) => updatePage(activePage.id, { title: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-100 text-xs font-semibold"
                        />
                      </div>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Slug URL / ID</label>
                        <input
                          type="text"
                          value={activePage.slug}
                          onChange={(e) => updatePage(activePage.id, { slug: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Deskripsi Halaman</label>
                        <textarea
                          rows={2}
                          value={activePage.description || ''}
                          onChange={(e) => updatePage(activePage.id, { description: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-100 text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-stone-400 text-[11px] mb-1">Format Tata Letak</label>
                        <select
                          value={activePage.layoutType}
                          onChange={(e) =>
                            updatePage(activePage.id, { layoutType: e.target.value as PageLayoutType })
                          }
                          className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-200 text-xs font-semibold"
                        >
                          <option value="5_vertical_cards">5 Kolom Memanjang Vertikal</option>
                          <option value="flow_list">Daftar Mengalir (Flow List)</option>
                          <option value="grid">Grid 2-3 Kolom Responsif</option>
                          <option value="detail_content">Konten Detail Silsilah</option>
                          <option value="custom_canvas">Kanvas Bebas (Free Canvas)</option>
                        </select>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-xs space-y-2">
                      <span className="font-bold text-amber-300 block">💡 Tips Memilih Elemen:</span>
                      <p className="text-stone-300 text-[11px] leading-relaxed">
                        Klik langsung pada elemen di area kanvas kiri atau gunakan tab <strong>🔍 Inspector</strong> untuk memilih elemen dan mengatur teks, aksi tombol, warna, ukuran, margin, serta posisinya secara presisi.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsAddElementModalOpen(true)}
                      className="w-full py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow"
                    >
                      <Plus className="w-4 h-4" />
                      <span>+ Tambah Elemen ke Halaman Ini</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: INSPECTOR (DOM / COMPONENT TREE HIERARCHY) */}
          {activeStudioTab === 'inspector' && (
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-stone-950">
              {/* Left Tree Explorer */}
              <div className="w-full md:w-80 lg:w-96 border-r border-stone-800 flex flex-col bg-stone-900/60 shrink-0">
                <div className="p-3 border-b border-stone-800 flex items-center gap-2">
                  <Search className="w-3.5 h-3.5 text-stone-400" />
                  <input
                    type="text"
                    placeholder="Cari ID atau nama elemen..."
                    value={inspectorFilter}
                    onChange={(e) => setInspectorFilter(e.target.value)}
                    className="w-full bg-transparent text-xs text-stone-100 placeholder:text-stone-500 focus:outline-none"
                  />
                </div>

                <div className="flex-1 overflow-y-auto p-3 space-y-2">
                  <div className="font-bold text-xs text-amber-400 flex items-center gap-1.5 px-2">
                    <FolderTree className="w-3.5 h-3.5" />
                    <span>Struktur Pohon Komponen: {activePage.title}</span>
                  </div>

                  <div className="space-y-1 pl-1">
                    {/* Root Page Node */}
                    <div
                      onClick={() => setSelectedElementIdInEditor(null)}
                      className={`p-2 rounded-xl flex items-center justify-between cursor-pointer text-xs font-bold transition-colors ${
                        !selectedElementIdInEditor
                          ? 'bg-amber-950/60 text-amber-300 border border-amber-500/40'
                          : 'text-stone-300 hover:bg-stone-800'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Layout className="w-4 h-4 text-amber-400" />
                        <span>{activePage.title}</span>
                      </div>
                      <span className="text-[10px] font-mono text-stone-400">#{activePage.id}</span>
                    </div>

                    {/* Children Component Nodes */}
                    <div className="pl-4 border-l border-stone-800/80 space-y-1 my-1">
                      {activePage.components
                        .filter(
                          (c) =>
                            !inspectorFilter ||
                            c.name.toLowerCase().includes(inspectorFilter.toLowerCase()) ||
                            c.id.toLowerCase().includes(inspectorFilter.toLowerCase()) ||
                            c.type.toLowerCase().includes(inspectorFilter.toLowerCase())
                        )
                        .map((c) => {
                          const isSel = selectedElementIdInEditor === c.id;
                          return (
                            <div
                              key={c.id}
                              onClick={() => {
                                setSelectedElementIdInEditor(c.id);
                              }}
                              className={`p-2 rounded-xl flex items-center justify-between cursor-pointer text-xs transition-colors ${
                                isSel
                                  ? 'bg-amber-600 text-stone-950 font-bold shadow'
                                  : 'text-stone-300 hover:bg-stone-800'
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <div className="text-amber-400 shrink-0">
                                  {renderIconByName(c.icon || 'Sliders', 'w-3.5 h-3.5')}
                                </div>
                                <div className="min-w-0">
                                  <span className="font-semibold block truncate">{c.name}</span>
                                  <span
                                    className={`text-[9px] font-mono block truncate ${
                                      isSel ? 'text-stone-900' : 'text-stone-500'
                                    }`}
                                  >
                                    #{c.id} ({c.type})
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                {c.actionType !== 'none' && (
                                  <span
                                    className={`text-[9px] font-mono px-1 rounded ${
                                      isSel ? 'bg-stone-950 text-amber-400' : 'bg-stone-800 text-amber-400'
                                    }`}
                                  >
                                    ⚡ {c.actionType}
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Detail Pane */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 text-xs">
                {selectedElement ? (
                  <div className="max-w-2xl bg-stone-900/80 border border-stone-800 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                      <div>
                        <span className="text-[10px] font-mono text-amber-400 font-bold uppercase">
                          Elemen Terpilih
                        </span>
                        <h3 className="text-base font-bold text-stone-100">{selectedElement.name}</h3>
                        <p className="text-[11px] text-stone-400 font-mono">
                          ID: {selectedElement.id} · Tipe: {selectedElement.type}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => setActiveStudioTab('visual_editor')}
                        className="px-3 py-1.5 rounded-xl bg-amber-600 text-stone-950 font-bold text-xs cursor-pointer"
                      >
                        Buka di Visual Canvas →
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 space-y-1">
                        <span className="text-stone-400 text-[10px] block">Aksi Klik</span>
                        <span className="font-bold text-amber-400 block font-mono">
                          {selectedElement.actionType}
                        </span>
                        {selectedElement.targetPageId && (
                          <span className="text-stone-300 block text-[11px]">
                            Menuju: {selectedElement.targetPageId}
                          </span>
                        )}
                      </div>

                      <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 space-y-1">
                        <span className="text-stone-400 text-[10px] block">Visibilitas & Status</span>
                        <span className="font-bold text-stone-100 block">
                          {selectedElement.isVisible ? '🟢 Tampil' : '⚪ Sembunyi'} ·{' '}
                          {selectedElement.isEnabled ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => duplicateComponent(activePage.id, selectedElement.id)}
                        className="px-3 py-1.5 rounded-xl bg-stone-800 text-stone-200 font-semibold"
                      >
                        Duplikasi
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteElement(selectedElement)}
                        className="px-3 py-1.5 rounded-xl bg-rose-950 text-rose-300 border border-rose-800 font-semibold"
                      >
                        Hapus Elemen
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="py-16 text-center text-stone-400">
                    <FolderTree className="w-10 h-10 mx-auto text-stone-600 mb-2" />
                    <p className="font-semibold text-sm">Pilih elemen pada pohon hierarki di sebelah kiri</p>
                    <p className="text-xs text-stone-500 mt-1">
                      Inspector memudahkan Anda melacak seluruh struktur komponen dan ID uniknya.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: CODE STUDIO (HTML / CSS / JS) */}
          {activeStudioTab === 'code' && (
            <div className="flex-1 flex flex-col overflow-hidden bg-stone-950">
              {/* Code Sub-Tabs */}
              <div className="h-10 px-4 bg-stone-900/80 border-b border-stone-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-stone-950 p-0.5 rounded-xl border border-stone-800 text-xs font-semibold">
                    <button
                      type="button"
                      onClick={() => setActiveCodeTab('html')}
                      className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                        activeCodeTab === 'html'
                          ? 'bg-amber-600 text-stone-950 font-bold'
                          : 'text-stone-400 hover:text-white'
                      }`}
                    >
                      [HTML]
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveCodeTab('css')}
                      className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                        activeCodeTab === 'css'
                          ? 'bg-amber-600 text-stone-950 font-bold'
                          : 'text-stone-400 hover:text-white'
                      }`}
                    >
                      [CSS]
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveCodeTab('js')}
                      className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                        activeCodeTab === 'js'
                          ? 'bg-amber-600 text-stone-950 font-bold'
                          : 'text-stone-400 hover:text-white'
                      }`}
                    >
                      [JavaScript]
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveCodeTab('bundle')}
                      className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                        activeCodeTab === 'bundle'
                          ? 'bg-amber-600 text-stone-950 font-bold'
                          : 'text-stone-400 hover:text-white'
                      }`}
                    >
                      [Gabungkan Kode]
                    </button>
                  </div>

                  {/* GLOBAL DEPENDENCY MARKER */}
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800/80 font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    <span>GLOBAL DEPENDENCY</span>
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      let code = '';
                      if (activeCodeTab === 'html') code = generatePageHtml();
                      else if (activeCodeTab === 'css') code = generatePageCss();
                      else if (activeCodeTab === 'js') code = generatePageJs();
                      else code = generateCombinedBundle();
                      handleCopyCode(code, `Kode ${activeCodeTab.toUpperCase()}`);
                    }}
                    className="flex items-center gap-1 px-3 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold cursor-pointer"
                  >
                    <Clipboard className="w-3.5 h-3.5 text-amber-400" />
                    <span>Salin Kode</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleExportBundleFile}
                    className="flex items-center gap-1 px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-stone-950 text-xs font-bold cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Ekspor Berkas</span>
                  </button>
                </div>
              </div>

              {/* Code Viewer Panel */}
              <div className="flex-1 overflow-auto p-4 font-mono text-xs text-stone-200 bg-stone-950 selection:bg-amber-500/40">
                <pre className="p-4 rounded-xl bg-stone-900/90 border border-stone-800/80 overflow-x-auto leading-relaxed">
                  <code>
                    {activeCodeTab === 'html' && generatePageHtml()}
                    {activeCodeTab === 'css' && generatePageCss()}
                    {activeCodeTab === 'js' && generatePageJs()}
                    {activeCodeTab === 'bundle' && generateCombinedBundle()}
                  </code>
                </pre>
              </div>
            </div>
          )}

          {/* TAB 4: SNAPSHOT BACKUP & DATA EXPORT */}
          {activeStudioTab === 'backup' && (
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 max-w-5xl mx-auto space-y-6 text-xs text-stone-100">
              {/* Header Info */}
              <div className="p-5 rounded-2xl bg-stone-900/80 border border-stone-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                      <Database className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="text-base font-bold text-stone-100 flex items-center gap-2">
                        <span>Snapshot Backup & Ekspor Data Silsilah</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                          JSON Engine v{rootConfig.version || '2.5.0'}
                        </span>
                      </h2>
                      <p className="text-stone-400 text-xs">
                        Buat cadangan lengkap (snapshot) yang mencakup data anggota silsilah, struktur halaman dinamis, konfigurasi UI, tema global, dan preferensi aplikasi.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={downloadBackupJson}
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg transition-all active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>💾 Unduh Backup JSON</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const jsonStr = exportConfigAsJson();
                      navigator.clipboard.writeText(jsonStr);
                      showToast('📋 Seluruh data snapshot JSON disalin ke clipboard!');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer border border-stone-700 transition-all"
                  >
                    <Clipboard className="w-4 h-4 text-amber-400" />
                    <span>Salin JSON</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => backupFileInputRef.current?.click()}
                    className="px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-amber-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer border border-amber-500/40 transition-all"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Pulihkan dari File</span>
                  </button>
                </div>
              </div>

              {/* Snapshot Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-800 flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-stone-400 block">Data Silsilah</span>
                    <span className="text-base font-extrabold text-stone-100">
                      {familyMembers.length} Orang
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-800 flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400 shrink-0">
                    <Layout className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-stone-400 block">Total Halaman</span>
                    <span className="text-base font-extrabold text-stone-100">
                      {rootConfig.pages.length} Halaman
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-800 flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 shrink-0">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-stone-400 block">Total Elemen UI</span>
                    <span className="text-base font-extrabold text-stone-100">
                      {rootConfig.pages.reduce((acc, p) => acc + p.components.length, 0)} Komponen
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-800 flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-purple-500/10 text-purple-400 shrink-0">
                    <HardDrive className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-stone-400 block">Ukuran Snapshot</span>
                    <span className="text-base font-extrabold text-stone-100 font-mono">
                      ~{(new Blob([exportConfigAsJson()]).size / 1024).toFixed(1)} KB
                    </span>
                  </div>
                </div>
              </div>

              {/* JSON Live Preview & Explorer */}
              <div className="rounded-2xl bg-stone-900/80 border border-stone-800 overflow-hidden flex flex-col">
                <div className="p-3.5 bg-stone-900 border-b border-stone-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileJson className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-stone-200">Pratinjau JSON Snapshot (Live State)</span>
                  </div>
                  <span className="text-[11px] text-stone-400 font-mono">
                    Format: UTF-8 JSON Backup Snapshot
                  </span>
                </div>

                <div className="max-h-96 overflow-y-auto p-4 bg-stone-950 font-mono text-[11px] text-amber-200/90 leading-relaxed selection:bg-amber-500/30">
                  <pre className="whitespace-pre-wrap break-all">
                    <code>{exportConfigAsJson()}</code>
                  </pre>
                </div>

                <div className="p-3 bg-stone-900/90 border-t border-stone-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-stone-400">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Snapshot terverifikasi & siap disimpan atau dipindahkan ke perangkat lain.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={downloadBackupJson}
                      className="px-3 py-1 rounded-lg bg-amber-600 text-stone-950 font-bold hover:bg-amber-500 cursor-pointer"
                    >
                      💾 Unduh Berkas .json
                    </button>
                  </div>
                </div>
              </div>

              {/* Full Source Project ZIP Package Download Card */}
              <div className="p-5 rounded-2xl bg-amber-950/30 border border-amber-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FolderArchive className="w-5 h-5 text-amber-400" />
                    <h3 className="text-sm font-bold text-stone-100">
                      Paket Source Code Final (SilsilahKu-Final-Source.zip)
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                    ZIP COMPLETE ARCHIVE
                  </span>
                </div>

                <p className="text-stone-300 text-xs leading-relaxed">
                  Unduh seluruh kode sumber aplikasi lengkap (React 19 + TypeScript + Vite + Tailwind CSS + Assets + Components) dalam 1 berkas ZIP mandiri yang siap dipindahkan, dijalankan di komputer lain dengan <code>npm install && npm run dev</code>, atau di-build menjadi file APK Android via Capacitor.
                </p>

                <div className="flex items-center gap-3 pt-1">
                  <a
                    href="/SilsilahKu-Final-Source.zip"
                    download="SilsilahKu-Final-Source.zip"
                    className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg transition-all active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>📦 Unduh SilsilahKu-Final-Source.zip</span>
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: GLOBAL SETTINGS & SECURITY */}
          {activeStudioTab === 'global_settings' && (
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 max-w-4xl mx-auto space-y-6 text-xs text-stone-100">
              {/* Section 1: Identitas Aplikasi */}
              <form onSubmit={handleSaveGlobalIdentity} className="p-5 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <h3 className="text-sm font-bold text-amber-400">1. Identitas Aplikasi</h3>
                  <button
                    type="submit"
                    className="px-3.5 py-1 rounded-xl bg-amber-600 text-stone-950 font-bold cursor-pointer"
                  >
                    Simpan Identitas
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">Nama Aplikasi *</label>
                    <input
                      type="text"
                      required
                      value={appTitle}
                      onChange={(e) => setAppTitle(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-xs font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">Sub-judul / Versi</label>
                    <input
                      type="text"
                      value={appSubtitle}
                      onChange={(e) => setAppSubtitle(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Ikon Aplikasi</label>
                  <div className="grid grid-cols-8 sm:grid-cols-12 gap-1.5">
                    {AVAILABLE_ICONS.slice(0, 24).map((item) => {
                      const isSel = appIcon === item.id;
                      const IconComp = item.icon;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setAppIcon(item.id)}
                          className={`p-2 rounded-xl flex items-center justify-center cursor-pointer transition-colors ${
                            isSel ? 'bg-amber-600 text-stone-950 font-bold' : 'bg-stone-950 text-stone-300 hover:bg-stone-800'
                          }`}
                        >
                          <IconComp className="w-4 h-4" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              </form>

              {/* Section 2: Tampilan, Tema & Font */}
              <form onSubmit={handleSaveAppearance} className="p-5 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <h3 className="text-sm font-bold text-amber-400">2. Tampilan, Warna & Font</h3>
                  <button
                    type="submit"
                    className="px-3.5 py-1 rounded-xl bg-amber-600 text-stone-950 font-bold cursor-pointer"
                  >
                    Simpan Tampilan
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <span className="block font-semibold text-stone-300 mb-1">Warna Aksen</span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {PRIMARY_COLOR_OPTIONS.map((col) => {
                        const isSel = primaryColorVal === col.hex;
                        return (
                          <button
                            key={col.hex}
                            type="button"
                            onClick={() => {
                              setPrimaryColorVal(col.hex);
                              setPrimaryColorNameVal(col.name);
                            }}
                            className={`py-1 px-2 rounded-lg border flex items-center gap-1.5 cursor-pointer text-[11px] ${
                              isSel ? 'bg-stone-800 border-amber-400 font-bold' : 'bg-stone-950 border-stone-800'
                            }`}
                          >
                            <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: col.hex }} />
                            <span className="truncate">{col.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <span className="block font-semibold text-stone-300 mb-1">Jenis Huruf</span>
                    <select
                      value={fontFamilyVal}
                      onChange={(e) => setFontFamilyVal(e.target.value as FontFamilyType)}
                      className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-xs font-semibold"
                    >
                      <option value="plus-jakarta">Plus Jakarta Sans</option>
                      <option value="playfair">Playfair Display</option>
                      <option value="cinzel">Cinzel Monarki</option>
                      <option value="lora">Lora Naskah</option>
                      <option value="typewriter">Courier Prime</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex justify-between font-semibold text-stone-300 mb-1">
                      <span>Ukuran Teks</span>
                      <span className="text-amber-400 font-mono">{fontSizeVal}px</span>
                    </div>
                    <input
                      type="range"
                      min="12"
                      max="22"
                      value={fontSizeVal}
                      onChange={(e) => setFontSizeVal(Number(e.target.value))}
                      className="w-full accent-amber-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-stone-800">
                  <div>
                    <div className="flex justify-between font-semibold text-stone-300 mb-1">
                      <span>Blur Wallpaper</span>
                      <span className="text-amber-400 font-mono">{blurVal}px</span>
                    </div>
                    <div className="flex gap-1">
                      {([0, 5, 10, 15, 20] as BlurLevel[]).map((lvl) => (
                        <button
                          key={lvl}
                          type="button"
                          onClick={() => setBlurVal(lvl)}
                          className={`flex-1 py-1 rounded-lg font-semibold cursor-pointer border ${
                            blurVal === lvl ? 'bg-amber-600 text-stone-950 border-amber-400' : 'bg-stone-950 text-stone-300 border-stone-800'
                          }`}
                        >
                          {lvl === 0 ? 'Off' : `${lvl}px`}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="block font-semibold text-stone-300 mb-1">Preset Wallpaper</span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {WALLPAPER_PRESETS.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => setWallpaperPreset(p.url, p.name)}
                          className="p-1.5 rounded-lg border border-stone-800 bg-stone-950 text-left flex items-center gap-1.5 cursor-pointer hover:bg-stone-800"
                        >
                          <img src={p.url} alt={p.name} className="w-6 h-6 rounded object-cover" referrerPolicy="no-referrer" />
                          <span className="truncate text-[10px] font-semibold">{p.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </form>

              {/* Section 3: Profil Pengguna */}
              <form onSubmit={handleSaveProfile} className="p-5 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <h3 className="text-sm font-bold text-amber-400">3. Profil Pemilik Arsip</h3>
                  <button
                    type="submit"
                    className="px-3.5 py-1 rounded-xl bg-amber-600 text-stone-950 font-bold cursor-pointer"
                  >
                    Simpan Profil
                  </button>
                </div>

                <div className="flex items-center gap-3">
                  <img
                    src={rootConfig.profile.photoUrl}
                    alt={profileName}
                    className="w-12 h-12 rounded-full object-cover border border-amber-500/50 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Ganti Foto Profil</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">Nama Pemilik *</label>
                    <input
                      type="text"
                      required
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-xs font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">Gelar / Sebutan</label>
                    <input
                      type="text"
                      value={profileTitle}
                      onChange={(e) => setProfileTitle(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Cabang / Generasi</label>
                  <input
                    type="text"
                    value={profileBranch}
                    onChange={(e) => setProfileBranch(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-xs"
                  />
                </div>
              </form>

              {/* Section 4: Kunci Aplikasi & Sandi Keamanan */}
              <form onSubmit={handleSaveAppLock} className="p-5 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <h3 className="text-sm font-bold text-amber-400">4. Kunci Aplikasi (Passcode)</h3>
                  <button
                    type="submit"
                    className="px-3.5 py-1 rounded-xl bg-amber-600 text-stone-950 font-bold cursor-pointer"
                  >
                    Simpan Kunci Sandi
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-stone-200 block">Aktifkan Kunci Aplikasi</span>
                    <span className="text-[11px] text-stone-400 block mt-0.5">
                      {isLockEnabled ? 'Root APK & Visual Editor memerlukan kode sandi' : 'Pengaturan terbuka tanpa sandi'}
                    </span>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isLockEnabled}
                      onChange={(e) => setIsLockEnabled(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-10 h-5 bg-stone-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-600"></div>
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {rootConfig.appLock.isEnabled && (
                    <div>
                      <label className="block text-stone-300 font-semibold mb-1">Kode Sandi Saat Ini</label>
                      <input
                        type={showPassText ? 'text' : 'password'}
                        value={currentPasscodeAttempt}
                        onChange={(e) => setCurrentPasscodeAttempt(e.target.value)}
                        placeholder="Sandi saat ini..."
                        className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 font-mono text-xs"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">
                      {rootConfig.appLock.isEnabled ? 'Kode Sandi Baru' : 'Buat Kode Sandi'}
                    </label>
                    <input
                      type={showPassText ? 'text' : 'password'}
                      value={newPasscode}
                      onChange={(e) => setNewPasscode(e.target.value)}
                      placeholder="Misal: 1234"
                      className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 font-mono text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">Konfirmasi Sandi Baru</label>
                    <input
                      type={showPassText ? 'text' : 'password'}
                      value={confirmPasscode}
                      onChange={(e) => setConfirmPasscode(e.target.value)}
                      placeholder="Ulangi sandi..."
                      className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 font-mono text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-300 font-semibold mb-1">Petunjuk Sandi (Hint)</label>
                    <input
                      type="text"
                      value={passcodeHint}
                      onChange={(e) => setPasscodeHint(e.target.value)}
                      placeholder="Misal: Tahun berdirinya keluarga"
                      className="w-full px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-stone-100 text-xs"
                    />
                  </div>
                </div>
              </form>

              {/* Section 5: Backup & Ekspor Snapshot Data */}
              <div className="p-5 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <h3 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    <span>5. Backup & Ekspor Snapshot Data</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setActiveStudioTab('backup')}
                    className="text-amber-400 hover:underline text-[11px] font-bold"
                  >
                    Buka Studio Snapshot →
                  </button>
                </div>

                <p className="text-stone-400 text-xs leading-relaxed">
                  Ekspor cadangan instan (snapshot) seluruh data silsilah keluarga ({familyMembers.length} orang), tata letak halaman ({rootConfig.pages.length} halaman), dan konfigurasi tema dalam berkas format JSON.
                </p>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={downloadBackupJson}
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh Snapshot JSON</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const jsonStr = exportConfigAsJson();
                      navigator.clipboard.writeText(jsonStr);
                      showToast('📋 Snapshot JSON berhasil disalin!');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Clipboard className="w-3.5 h-3.5 text-amber-400" />
                    <span>Salin ke Clipboard</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => backupFileInputRef.current?.click()}
                    className="px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-amber-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer border border-amber-500/40"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Pulihkan dari File JSON</span>
                  </button>
                </div>
              </div>

              {/* Section 6: Setelan Pabrik (Factory Reset) */}
              <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-900/60 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-rose-300 flex items-center gap-1.5">
                    <RotateCcw className="w-4 h-4" />
                    <span>6. Kembali ke Setelan Pabrik</span>
                  </h4>
                  <p className="text-stone-400 text-[11px] mt-0.5">
                    Mengembalikan struktur halaman, komponen, tema, dan database silsilah ke kondisi default awal.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setConfirmResetFactory(true)}
                  className="px-4 py-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-200 border border-rose-700 font-bold text-xs cursor-pointer shadow"
                >
                  ↻ Reset Pabrik
                </button>
              </div>
            </div>
          )}
        </div>

        {/* =========================================================================
            DIALOG: TAMBAH ELEMEN MODAL
           ========================================================================= */}
        {isAddElementModalOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="w-full max-w-lg bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                <h3 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  <span>Tambah Elemen ke "{activePage.title}"</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setIsAddElementModalOpen(false)}
                  className="p-1 rounded text-stone-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { type: 'button', label: 'Tombol Aksi', desc: 'Navigasi & klik' },
                  { type: 'text_block', label: 'Blok Teks', desc: 'Paragraf & pengantar' },
                  { type: 'heading', label: 'Judul Besar', desc: 'Header & sub-header' },
                  { type: 'card_item', label: 'Kartu Konten', desc: 'Panel informasi' },
                  { type: 'image', label: 'Gambar/Foto', desc: 'Ilustrasi & avatar' },
                  { type: 'icon', label: 'Ikon', desc: 'Simbol visual' },
                  { type: 'container', label: 'Box Container', desc: 'Wadah pembungkus' },
                  { type: 'tab_bar', label: 'Tab Bar', desc: 'Pengalih tampilan' },
                  { type: 'dropdown', label: 'Menu Dropdown', desc: 'Daftar pilihan' },
                  { type: 'search_bar', label: 'Search Bar', desc: 'Pencarian data' },
                  { type: 'custom_component', label: 'Custom Component', desc: 'HTML/CSS bebas' },
                ].map((item) => (
                  <button
                    key={item.type}
                    type="button"
                    onClick={() => {
                      addComponentToPage(activePage.id, {
                        name: item.label,
                        subtitle: '',
                        description: `Elemen ${item.label} baru`,
                        type: item.type as ComponentType,
                        position: 'center',
                        order: activePage.components.length + 1,
                        size: 'sedang',
                        isVisible: true,
                        isEnabled: true,
                        actionType: item.type === 'button' ? 'navigate' : 'none',
                        targetPageId: rootConfig.homePageId,
                      });
                      setIsAddElementModalOpen(false);
                    }}
                    className="p-3 rounded-xl border border-stone-800 bg-stone-950 hover:bg-amber-950/40 hover:border-amber-500/50 text-left transition-all cursor-pointer group"
                  >
                    <span className="font-bold text-xs text-stone-100 group-hover:text-amber-300 block">
                      {item.label}
                    </span>
                    <span className="text-[10px] text-stone-400 block mt-0.5">{item.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            DIALOG: TAMBAH HALAMAN MODAL
           ========================================================================= */}
        {isAddPageModalOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="w-full max-w-md bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                <h3 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                  <FilePlus className="w-4 h-4" />
                  <span>Tambah Halaman Baru</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setIsAddPageModalOpen(false)}
                  className="p-1 rounded text-stone-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const target = e.target as HTMLFormElement;
                  const titleInput = target.elements.namedItem('pageTitle') as HTMLInputElement;
                  const layoutInput = target.elements.namedItem('layoutType') as HTMLSelectElement;

                  if (titleInput?.value) {
                    const newPageId = addPage({
                      title: titleInput.value.trim(),
                      slug: titleInput.value.toLowerCase().replace(/\s+/g, '-'),
                      description: `Halaman kustom ${titleInput.value}`,
                      layoutType: (layoutInput.value as PageLayoutType) || 'flow_list',
                      components: [],
                    });
                    setIsAddPageModalOpen(false);
                    setSelectedPageIdInEditor(newPageId);
                  }
                }}
                className="space-y-3 text-xs"
              >
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Nama / Judul Halaman *</label>
                  <input
                    name="pageTitle"
                    type="text"
                    required
                    placeholder="Contoh: Galeri Naskah Kuno"
                    className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-stone-300 font-semibold mb-1">Format Tata Letak (Layout)</label>
                  <select
                    name="layoutType"
                    className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-200 text-xs"
                  >
                    <option value="flow_list">Daftar Mengalir (Flow List)</option>
                    <option value="grid">Grid 2-3 Kolom Responsif</option>
                    <option value="detail_content">Konten Detail Silsilah</option>
                    <option value="5_vertical_cards">5 Kolom Memanjang Vertikal</option>
                    <option value="custom_canvas">Kanvas Bebas</option>
                  </select>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddPageModalOpen(false)}
                    className="px-3.5 py-1.5 rounded-xl bg-stone-800 text-stone-300"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-amber-600 text-stone-950 font-bold"
                  >
                    Buat Halaman
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* =========================================================================
            CONFIRM DIALOGS: Hapus Elemen, Hapus Halaman, Reset Pabrik
           ========================================================================= */}
        {confirmDeleteElement && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85 backdrop-blur-xs">
            <div className="w-full max-w-sm bg-stone-900 border border-rose-800/80 rounded-2xl p-5 shadow-2xl space-y-3 text-xs">
              <h4 className="text-sm font-bold text-rose-400 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>Hapus Elemen "{confirmDeleteElement.name}"?</span>
              </h4>
              <p className="text-stone-300">
                Tindakan ini akan menghapus elemen dari halaman. Anda dapat membatalkannya nanti menggunakan tombol Undo.
              </p>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmDeleteElement(null)}
                  className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-300"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    deleteComponent(activePage.id, confirmDeleteElement.id);
                    setConfirmDeleteElement(null);
                  }}
                  className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
                >
                  Hapus Elemen
                </button>
              </div>
            </div>
          </div>
        )}

        {confirmDeletePage && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85 backdrop-blur-xs">
            <div className="w-full max-w-sm bg-stone-900 border border-rose-800/80 rounded-2xl p-5 shadow-2xl space-y-3 text-xs">
              <h4 className="text-sm font-bold text-rose-400 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>Hapus Halaman "{confirmDeletePage.title}"?</span>
              </h4>
              <p className="text-stone-300">
                Seluruh elemen di dalam halaman ini akan dihapus. Lanjutkan penghapusan?
              </p>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmDeletePage(null)}
                  className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-300"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    deletePage(confirmDeletePage.id);
                    setConfirmDeletePage(null);
                  }}
                  className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
                >
                  Hapus Halaman
                </button>
              </div>
            </div>
          </div>
        )}

        {confirmResetFactory && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85 backdrop-blur-xs">
            <div className="w-full max-w-sm bg-stone-900 border border-rose-800/80 rounded-2xl p-5 shadow-2xl space-y-3 text-xs">
              <h4 className="text-sm font-bold text-rose-400 flex items-center gap-1.5">
                <RotateCcw className="w-4 h-4" />
                <span>Konfirmasi Setelan Pabrik</span>
              </h4>
              <p className="text-stone-300">
                Apakah Anda yakin ingin mengembalikan seluruh aplikasi ke setelan standar awal? Kustomisasi halaman dan tata letak akan dikembalikan ke konfigurasi default.
              </p>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmResetFactory(false)}
                  className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-300 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    resetToDefaultConfig();
                    setConfirmResetFactory(false);
                    closeRootApkModal();
                  }}
                  className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold cursor-pointer"
                >
                  Ya, Reset Sekarang
                </button>
              </div>
            </div>
          </div>
        )}

        {/* DIALOG: KONFIRMASI PEMULIHAN SNAPSHOT BACKUP */}
        {backupRestoreConfirmOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-black/85 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="w-full max-w-md bg-stone-900 border border-amber-500/50 rounded-2xl p-5 shadow-2xl space-y-4 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                <h4 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                  <Upload className="w-4 h-4" />
                  <span>Pulihkan Snapshot Backup JSON?</span>
                </h4>
                <button
                  type="button"
                  onClick={() => {
                    setBackupRestoreConfirmOpen(false);
                    setPendingRestoreJson('');
                  }}
                  className="p-1 rounded text-stone-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 text-stone-300 leading-relaxed">
                <p>
                  Sistem akan mengganti konfigurasi UI saat ini dan memuat seluruh data silsilah keluarga dari file snapshot JSON.
                </p>
                <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 font-mono text-[11px] text-amber-300/90 max-h-32 overflow-y-auto">
                  {pendingRestoreJson.slice(0, 300)}...
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => {
                    setBackupRestoreConfirmOpen(false);
                    setPendingRestoreJson('');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (pendingRestoreJson) {
                      const success = importConfigFromJson(pendingRestoreJson);
                      if (success) {
                        setBackupRestoreConfirmOpen(false);
                        setPendingRestoreJson('');
                        showToast('✅ Berhasil memulihkan snapshot cadangan!');
                      }
                    }
                  }}
                  className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold cursor-pointer shadow"
                >
                  Ya, Pulihkan Sekarang
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
