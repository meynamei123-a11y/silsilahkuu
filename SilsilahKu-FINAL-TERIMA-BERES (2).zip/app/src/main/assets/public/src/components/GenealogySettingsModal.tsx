import React from 'react';
import { useApp } from '../context/AppContext';
import { GenealogyDisplayConfig, FontFamilyType } from '../types';
import { DEFAULT_GENEALOGY_CONFIG } from '../data/initialData';
import {
  X,
  Sliders,
  Palette,
  Eye,
  Type,
  RotateCcw,
  Check,
  Layout,
  GitBranch,
  Sparkles,
} from 'lucide-react';

interface GenealogySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const LINE_COLOR_PRESETS = [
  { name: 'Emas Mataram', hex: '#d97706' },
  { name: 'Kuning Amber', hex: '#f59e0b' },
  { name: 'Zamrud Kraton', hex: '#10b981' },
  { name: 'Biru Bangsawan', hex: '#3b82f6' },
  { name: 'Ruby Kerajaan', hex: '#f43f5e' },
  { name: 'Perak Purba', hex: '#94a3b8' },
  { name: 'Putih Murni', hex: '#f8fafc' },
];

const FONT_OPTIONS: { id: FontFamilyType; name: string }[] = [
  { id: 'plus-jakarta', name: 'Plus Jakarta Sans (Modern & Tegas)' },
  { id: 'playfair', name: 'Playfair Display (Serif Anggun)' },
  { id: 'cinzel', name: 'Cinzel (Klasik Prasasti & Kerajaan)' },
  { id: 'lora', name: 'Lora (Pustaka & Naskah Kuno)' },
  { id: 'typewriter', name: 'Courier Prime (Mesin Tik Berkas)' },
  { id: 'amiri', name: 'Amiri (Elegan Kaligrafi Tradisional)' },
];

export const GenealogySettingsModal: React.FC<GenealogySettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { rootConfig, updateRootConfig, showToast } = useApp();

  if (!isOpen) return null;

  const config = {
    ...DEFAULT_GENEALOGY_CONFIG,
    ...(rootConfig.genealogyDisplay || {}),
  };

  const updateConfig = (updates: Partial<GenealogyDisplayConfig>) => {
    updateRootConfig({
      genealogyDisplay: {
        ...config,
        ...updates,
      },
    });
  };

  const handleReset = () => {
    updateConfig({
      orientation: 'outline_tree',
      maxDepth: 'all',
      showSpouse: true,
      showChildrenCount: true,
      showYears: true,
      showPhoto: true,
      showRelation: true,
      nameSize: 'sedang',
      nodeSize: 'normal',
      generationSpacing: 24,
      branchSpacing: 16,
      defaultExpandedLevel: 3,
      lineColor: '#f59e0b',
      transparency: 90,
      fontFamily: 'plus-jakarta',
      fontSize: 14,
    });
    showToast('Pengaturan tampilan silsilah dikembalikan ke default');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl max-h-[92vh] flex flex-col rounded-3xl bg-stone-900 border-2 border-amber-600/40 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-stone-950 border-b border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-stone-100">
                Pengaturan Tampilan Silsilah
              </h3>
              <p className="text-xs text-stone-400">
                Sesuaikan orientasi, kedalaman generasi, ukuran node & warna garis
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-stone-200">
          {/* 1. Mode Tampilan & Orientasi */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Layout className="w-3.5 h-3.5" />
              Format Tampilan & Orientasi Bagan
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => updateConfig({ orientation: 'outline_tree' })}
                className={`p-3 rounded-2xl border text-center transition-all ${
                  config.orientation === 'outline_tree'
                    ? 'bg-amber-600/20 border-amber-400 text-amber-300 shadow font-bold'
                    : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                }`}
              >
                <span className="font-mono text-xs block mb-1">├── Pohon</span>
                <span className="text-[11px] block">Tree Overview (Banyak Nama)</span>
              </button>

              <button
                type="button"
                onClick={() => updateConfig({ orientation: 'vertical' })}
                className={`p-3 rounded-2xl border text-center transition-all ${
                  config.orientation === 'vertical'
                    ? 'bg-amber-600/20 border-amber-400 text-amber-300 shadow font-bold'
                    : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                }`}
              >
                <span className="font-mono text-xs block mb-1">⬇ Vertikal</span>
                <span className="text-[11px] block">Bagan Atas-Bawah</span>
              </button>

              <button
                type="button"
                onClick={() => updateConfig({ orientation: 'horizontal' })}
                className={`p-3 rounded-2xl border text-center transition-all ${
                  config.orientation === 'horizontal'
                    ? 'bg-amber-600/20 border-amber-400 text-amber-300 shadow font-bold'
                    : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                }`}
              >
                <span className="font-mono text-xs block mb-1">➡ Horisontal</span>
                <span className="text-[11px] block">Bagan Kiri-Kanan</span>
              </button>
            </div>
          </div>

          {/* 2. Batas Kedalaman Generasi (Requirement 4) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <GitBranch className="w-3.5 h-3.5" />
                Kedalaman Generasi Maksimal
              </label>
              <span className="text-xs font-mono text-amber-300">
                {config.maxDepth === 'all' ? 'Semua Generasi' : `${config.maxDepth} Generasi`}
              </span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {[1, 2, 3, 4, 5, 'all'].map((val) => (
                <button
                  key={String(val)}
                  type="button"
                  onClick={() => updateConfig({ maxDepth: val as any })}
                  className={`py-2 px-1 rounded-xl text-xs font-bold border transition-all ${
                    config.maxDepth === val
                      ? 'bg-amber-600 border-amber-400 text-stone-950 shadow'
                      : 'bg-stone-950 border-stone-800 text-stone-300 hover:bg-stone-800'
                  }`}
                >
                  {val === 'all' ? 'Semua' : `${val} Gen`}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-stone-400">
              Contoh: jika memilih 3 generasi, bagan menampilkan silsilah dari akar hingga tingkat cicit saja.
            </p>
          </div>

          {/* 3. Jumlah Generasi Awal yang Terbuka (Default Expand Level) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-stone-300">
                Generasi Awal yang Terbuka Otomatis (Default Expand):
              </label>
              <span className="text-xs font-mono text-amber-300">
                {config.defaultExpandedLevel} Tingkat
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={5}
              value={config.defaultExpandedLevel}
              onChange={(e) => updateConfig({ defaultExpandedLevel: Number(e.target.value) })}
              className="w-full accent-amber-500"
            />
            <div className="flex justify-between text-[10px] text-stone-400 font-mono">
              <span>1 (Hanya Anak)</span>
              <span>2 (Hingga Cucu)</span>
              <span>3 (Hingga Cicit)</span>
              <span>4+ (Seluruh Cabang)</span>
            </div>
          </div>

          {/* 4. Visibilitas Field di Kartu / Node */}
          <div className="p-4 rounded-2xl bg-stone-950/70 border border-stone-800 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5" />
              Elemen yang Ditampilkan pada Node / Kartu
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Tampilkan Pasangan */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-stone-900 border border-stone-800 cursor-pointer">
                <span className="text-xs text-stone-300">Tampilkan Pasangan</span>
                <input
                  type="checkbox"
                  checked={config.showSpouse}
                  onChange={(e) => updateConfig({ showSpouse: e.target.checked })}
                  className="rounded accent-amber-500 w-4 h-4 cursor-pointer"
                />
              </label>

              {/* Tampilkan Anak */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-stone-900 border border-stone-800 cursor-pointer">
                <span className="text-xs text-stone-300">Tampilkan Jumlah Anak</span>
                <input
                  type="checkbox"
                  checked={config.showChildrenCount}
                  onChange={(e) => updateConfig({ showChildrenCount: e.target.checked })}
                  className="rounded accent-amber-500 w-4 h-4 cursor-pointer"
                />
              </label>

              {/* Tampilkan Tahun */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-stone-900 border border-stone-800 cursor-pointer">
                <span className="text-xs text-stone-300">Tampilkan Tahun Lahir/Wafat</span>
                <input
                  type="checkbox"
                  checked={config.showYears}
                  onChange={(e) => updateConfig({ showYears: e.target.checked })}
                  className="rounded accent-amber-500 w-4 h-4 cursor-pointer"
                />
              </label>

              {/* Tampilkan Foto */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-stone-900 border border-stone-800 cursor-pointer">
                <span className="text-xs text-stone-300">Tampilkan Foto / Avatar</span>
                <input
                  type="checkbox"
                  checked={config.showPhoto}
                  onChange={(e) => updateConfig({ showPhoto: e.target.checked })}
                  className="rounded accent-amber-500 w-4 h-4 cursor-pointer"
                />
              </label>

              {/* Tampilkan Hubungan */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-stone-900 border border-stone-800 cursor-pointer col-span-1 sm:col-span-2">
                <span className="text-xs text-stone-300">Tampilkan Hubungan & Gelar</span>
                <input
                  type="checkbox"
                  checked={config.showRelation}
                  onChange={(e) => updateConfig({ showRelation: e.target.checked })}
                  className="rounded accent-amber-500 w-4 h-4 cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* 5. Ukuran & Dimensi Node */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                Ukuran Nama Tokoh:
              </label>
              <select
                value={config.nameSize}
                onChange={(e) => updateConfig({ nameSize: e.target.value as any })}
                className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
              >
                <option value="kecil">Kecil (Ringkas & Padat)</option>
                <option value="sedang">Sedang (Standar)</option>
                <option value="besar">Besar (Jelas & Menonjol)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                Ukuran Node / Kartu:
              </label>
              <select
                value={config.nodeSize}
                onChange={(e) => updateConfig({ nodeSize: e.target.value as any })}
                className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
              >
                <option value="compact">Kompak (Banyak Nama Sekaligus)</option>
                <option value="normal">Normal (Seimbang)</option>
                <option value="spacious">Leluasa (Detail Luas)</option>
              </select>
            </div>
          </div>

          {/* 6. Spacing Jarak Antar Generasi & Cabang */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-stone-300">Jarak Antar Generasi:</span>
                <span className="font-mono text-amber-300">{config.generationSpacing}px</span>
              </div>
              <input
                type="range"
                min={12}
                max={56}
                value={config.generationSpacing}
                onChange={(e) => updateConfig({ generationSpacing: Number(e.target.value) })}
                className="w-full accent-amber-500"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-stone-300">Jarak Antar Cabang:</span>
                <span className="font-mono text-amber-300">{config.branchSpacing}px</span>
              </div>
              <input
                type="range"
                min={6}
                max={36}
                value={config.branchSpacing}
                onChange={(e) => updateConfig({ branchSpacing: Number(e.target.value) })}
                className="w-full accent-amber-500"
              />
            </div>
          </div>

          {/* 7. Warna Garis Hubungan */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5" />
              Warna Garis Penghubung Silsilah
            </label>
            <div className="flex flex-wrap items-center gap-2">
              {LINE_COLOR_PRESETS.map((p) => (
                <button
                  key={p.hex}
                  type="button"
                  onClick={() => updateConfig({ lineColor: p.hex })}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs transition-all ${
                    config.lineColor.toLowerCase() === p.hex.toLowerCase()
                      ? 'border-amber-400 bg-stone-800 text-stone-100 font-bold ring-2 ring-amber-500/40'
                      : 'border-stone-800 bg-stone-950 text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <span
                    className="w-3 h-3 rounded-full border border-stone-600"
                    style={{ backgroundColor: p.hex }}
                  />
                  <span>{p.name}</span>
                </button>
              ))}

              <div className="flex items-center gap-2 ml-auto">
                <span className="text-xs text-stone-400">Kustom:</span>
                <input
                  type="color"
                  value={config.lineColor}
                  onChange={(e) => updateConfig({ lineColor: e.target.value })}
                  className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                />
              </div>
            </div>
          </div>

          {/* 8. Tipografi & Font Silsilah */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5" />
              Jenis Font Silsilah
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {FONT_OPTIONS.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => updateConfig({ fontFamily: f.id })}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all ${
                    config.fontFamily === f.id
                      ? 'bg-amber-600/20 border-amber-400 text-amber-300 font-bold'
                      : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                  }`}
                >
                  {f.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-950 border-t border-stone-800 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-400 hover:text-stone-200 text-xs font-medium transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset ke Standar</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs shadow-lg transition-all active:scale-95 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>Terapkan Pengaturan</span>
          </button>
        </div>
      </div>
    </div>
  );
};
