import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { extractPersonFromNote, ExtractedPersonCandidate } from '../utils/noteExtractor';
import { FamilyMember } from '../types';
import {
  X,
  FileText,
  Sparkles,
  ArrowRight,
  Check,
  User,
  Plus,
  Trash2,
  AlertCircle,
  HelpCircle,
  RefreshCw,
  GitBranch,
} from 'lucide-react';

interface NoteImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessAdded?: (newMember: FamilyMember) => void;
}

const NOTE_EXAMPLES = [
  {
    title: 'Contoh Silsilah Purba (Abel)',
    text: 'Abel adalah anak Adam dan Hawa. Lahir pada tahun 3950 SM dan wafat pada tahun 3900 SM di Mesopotamia. Ia adalah seorang gembala domba yang saleh. Sumber: Kitab Kejadian 4:2-8.',
  },
  {
    title: 'Contoh Keturunan Yakub (Ruben)',
    text: 'Ruben adalah putra sulung Yakub dan Lea. Lahir pada tahun 1920 SM di Padan-Aram. Memiliki anak bernama Hanok, Palu, Hezron, dan Karmi. Membela Yusuf saat hendak dicelakai.',
  },
  {
    title: 'Contoh Keluarga Trah Modern (Raden Mas)',
    text: 'Raden Mas Suryo Kusumo adalah anak dari Hendro Kusumo dan Endang Purwaningsih. Menikah dengan Siti Aminah. Memiliki anak bernama Dimas dan Anisa. Lahir tahun 1990 di Yogyakarta. Berprofesi sebagai arsitek dan penggiat budaya.',
  },
];

export const NoteImportModal: React.FC<NoteImportModalProps> = ({
  isOpen,
  onClose,
  onSuccessAdded,
}) => {
  const { familyMembers, addFamilyMember, updateFamilyMember, showToast } = useApp();

  const [rawNote, setRawNote] = useState('');
  const [candidate, setCandidate] = useState<ExtractedPersonCandidate | null>(null);
  const [isParsed, setIsParsed] = useState(false);

  // Form edit fields based on candidate
  const [formData, setFormData] = useState({
    name: '',
    title: '',
    gender: 'Laki-laki' as 'Laki-laki' | 'Perempuan',
    generation: 4,
    relation: 'Keluarga',
    birthYear: '',
    deathYear: '',
    birthPlace: '',
    residence: '',
    lineageBranch: 'Patrilineal (Garis Ayah)' as 'Patrilineal (Garis Ayah)' | 'Matrilineal (Garis Ibu)',
    fatherNameOrId: '',
    motherNameOrId: '',
    spouseNameOrId: '',
    childrenNamesStr: '',
    occupation: '',
    notes: '',
    biography: '',
    sources: '',
  });

  if (!isOpen) return null;

  const handleParse = (textToParse: string) => {
    if (!textToParse.trim()) {
      showToast('Masukkan catatan atau teks narasi silsilah terlebih dahulu!');
      return;
    }

    const extracted = extractPersonFromNote(textToParse);
    setCandidate(extracted);

    // Try finding existing parent in database by name match
    const existingFather = extracted.fatherName
      ? familyMembers.find(
          (m) =>
            m.name.toLowerCase().includes(extracted.fatherName!.toLowerCase()) ||
            extracted.fatherName!.toLowerCase().includes(m.name.toLowerCase())
        )
      : null;

    const existingMother = extracted.motherName
      ? familyMembers.find(
          (m) =>
            m.name.toLowerCase().includes(extracted.motherName!.toLowerCase()) ||
            extracted.motherName!.toLowerCase().includes(m.name.toLowerCase())
        )
      : null;

    const existingSpouse = extracted.spouseName
      ? familyMembers.find(
          (m) =>
            m.name.toLowerCase().includes(extracted.spouseName!.toLowerCase()) ||
            extracted.spouseName!.toLowerCase().includes(m.name.toLowerCase())
        )
      : null;

    // Determine generation: parent generation + 1 if parent found
    const inferredGen = existingFather
      ? existingFather.generation + 1
      : existingMother
      ? existingMother.generation + 1
      : 3;

    setFormData({
      name: extracted.name || 'Tokoh Baru',
      title: extracted.occupation ? `Tokoh ${extracted.occupation}` : '',
      gender: extracted.gender || 'Laki-laki',
      generation: inferredGen,
      relation: existingFather ? `Anak dari ${existingFather.name}` : 'Kerabat Silsilah',
      birthYear: extracted.birthYear || '',
      deathYear: extracted.deathYear || '',
      birthPlace: extracted.birthPlace || '',
      residence: extracted.birthPlace || '',
      lineageBranch:
        extracted.gender === 'Laki-laki'
          ? 'Patrilineal (Garis Ayah)'
          : 'Matrilineal (Garis Ibu)',
      fatherNameOrId: existingFather ? existingFather.id : extracted.fatherName || '',
      motherNameOrId: existingMother ? existingMother.id : extracted.motherName || '',
      spouseNameOrId: existingSpouse ? existingSpouse.id : extracted.spouseName || '',
      childrenNamesStr: (extracted.childrenNames || []).join(', '),
      occupation: extracted.occupation || '',
      notes: extracted.notes || textToParse,
      biography: extracted.biography || textToParse,
      sources: extracted.sources || '',
    });

    setIsParsed(true);
  };

  const handleApplyExample = (text: string) => {
    setRawNote(text);
    handleParse(text);
  };

  const handleCommit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      showToast('Nama tokoh wajib diisi!');
      return;
    }

    const newMemberId = 'mem-' + Date.now();

    // 1. Resolve Father: check if fatherNameOrId matches an existing member ID
    let fatherIdToUse: string | null = null;
    if (formData.fatherNameOrId.trim()) {
      const matchFather = familyMembers.find(
        (m) =>
          m.id === formData.fatherNameOrId ||
          m.name.toLowerCase() === formData.fatherNameOrId.toLowerCase().trim()
      );
      if (matchFather) {
        fatherIdToUse = matchFather.id;
      } else {
        // Auto-create father candidate entity
        const newFatherId = 'mem-gen-f-' + Date.now();
        addFamilyMember({
          name: formData.fatherNameOrId.trim(),
          gender: 'Laki-laki',
          generation: Math.max(1, Number(formData.generation) - 1),
          relation: 'Ayah dari ' + formData.name,
          birthYear: '',
          deathYear: null,
          birthPlace: formData.birthPlace,
          residence: formData.residence,
          lineageBranch: 'Patrilineal (Garis Ayah)',
          notes: `Dibuat otomatis dari catatan silsilah ${formData.name}`,
          fatherId: null,
          motherId: null,
          spouseId: null,
          childrenIds: [newMemberId],
        });
        fatherIdToUse = newFatherId;
      }
    }

    // 2. Resolve Mother:
    let motherIdToUse: string | null = null;
    if (formData.motherNameOrId.trim()) {
      const matchMother = familyMembers.find(
        (m) =>
          m.id === formData.motherNameOrId ||
          m.name.toLowerCase() === formData.motherNameOrId.toLowerCase().trim()
      );
      if (matchMother) {
        motherIdToUse = matchMother.id;
      } else {
        // Auto-create mother candidate entity
        const newMotherId = 'mem-gen-m-' + Date.now();
        addFamilyMember({
          name: formData.motherNameOrId.trim(),
          gender: 'Perempuan',
          generation: Math.max(1, Number(formData.generation) - 1),
          relation: 'Ibu dari ' + formData.name,
          birthYear: '',
          deathYear: null,
          birthPlace: formData.birthPlace,
          residence: formData.residence,
          lineageBranch: 'Matrilineal (Garis Ibu)',
          notes: `Dibuat otomatis dari catatan silsilah ${formData.name}`,
          fatherId: null,
          motherId: null,
          spouseId: null,
          childrenIds: [newMemberId],
        });
        motherIdToUse = newMotherId;
      }
    }

    // 3. Resolve Spouse:
    let spouseIdToUse: string | null = null;
    if (formData.spouseNameOrId.trim()) {
      const matchSpouse = familyMembers.find(
        (m) =>
          m.id === formData.spouseNameOrId ||
          m.name.toLowerCase() === formData.spouseNameOrId.toLowerCase().trim()
      );
      if (matchSpouse) {
        spouseIdToUse = matchSpouse.id;
      } else {
        const newSpouseId = 'mem-gen-s-' + Date.now();
        addFamilyMember({
          name: formData.spouseNameOrId.trim(),
          gender: formData.gender === 'Laki-laki' ? 'Perempuan' : 'Laki-laki',
          generation: Number(formData.generation),
          relation: 'Pasangan dari ' + formData.name,
          birthYear: '',
          deathYear: null,
          birthPlace: formData.birthPlace,
          residence: formData.residence,
          lineageBranch:
            formData.gender === 'Laki-laki'
              ? 'Matrilineal (Garis Ibu)'
              : 'Patrilineal (Garis Ayah)',
          notes: `Dibuat otomatis dari catatan silsilah ${formData.name}`,
          fatherId: null,
          motherId: null,
          spouseId: newMemberId,
          childrenIds: [],
        });
        spouseIdToUse = newSpouseId;
      }
    }

    // 4. Resolve Children from childrenNamesStr:
    const childNames = formData.childrenNamesStr
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    const childrenIds: string[] = [];

    childNames.forEach((cName, idx) => {
      const existingChild = familyMembers.find(
        (m) => m.name.toLowerCase() === cName.toLowerCase()
      );
      if (existingChild) {
        childrenIds.push(existingChild.id);
        // Update reciprocal parent
        if (formData.gender === 'Laki-laki') {
          updateFamilyMember(existingChild.id, { fatherId: newMemberId });
        } else {
          updateFamilyMember(existingChild.id, { motherId: newMemberId });
        }
      } else {
        // Auto create child candidate entity
        const newChildId = `mem-gen-c-${Date.now()}-${idx}`;
        addFamilyMember({
          name: cName,
          gender: 'Laki-laki',
          generation: Number(formData.generation) + 1,
          relation: 'Anak dari ' + formData.name,
          birthYear: '',
          deathYear: null,
          birthPlace: formData.birthPlace,
          residence: formData.residence,
          lineageBranch: formData.lineageBranch,
          notes: `Dibuat otomatis sebagai anak dari ${formData.name}`,
          fatherId: formData.gender === 'Laki-laki' ? newMemberId : fatherIdToUse,
          motherId: formData.gender === 'Perempuan' ? newMemberId : motherIdToUse,
          spouseId: null,
          childrenIds: [],
        });
        childrenIds.push(newChildId);
      }
    });

    // 5. Create New Member
    const finalNewMember: FamilyMember = {
      id: newMemberId,
      name: formData.name.trim(),
      title: formData.title.trim() || undefined,
      gender: formData.gender,
      generation: Number(formData.generation),
      relation: formData.relation.trim() || 'Anggota Silsilah',
      birthYear: formData.birthYear.trim() || 'Tahun -',
      deathYear: formData.deathYear.trim() ? formData.deathYear.trim() : null,
      birthPlace: formData.birthPlace.trim() || '-',
      residence: formData.residence.trim() || '-',
      lineageBranch: formData.lineageBranch,
      notes: formData.notes.trim() || 'Ditambahkan via ekstraksi catatan otomatis.',
      biography: formData.biography.trim() || undefined,
      sources: formData.sources.trim() ? [formData.sources.trim()] : undefined,
      fatherId: fatherIdToUse,
      motherId: motherIdToUse,
      spouseId: spouseIdToUse,
      childrenIds: childrenIds,
      occupation: formData.occupation.trim() || undefined,
    };

    addFamilyMember(finalNewMember);

    // 6. Reciprocal update: update father's children list
    if (fatherIdToUse) {
      const fatherObj = familyMembers.find((m) => m.id === fatherIdToUse);
      if (fatherObj) {
        const updatedChildren = Array.from(
          new Set([...(fatherObj.childrenIds || []), newMemberId])
        );
        updateFamilyMember(fatherIdToUse, { childrenIds: updatedChildren });
      }
    }

    // Reciprocal update: update mother's children list
    if (motherIdToUse) {
      const motherObj = familyMembers.find((m) => m.id === motherIdToUse);
      if (motherObj) {
        const updatedChildren = Array.from(
          new Set([...(motherObj.childrenIds || []), newMemberId])
        );
        updateFamilyMember(motherIdToUse, { childrenIds: updatedChildren });
      }
    }

    // Reciprocal update: update spouse's spouseId
    if (spouseIdToUse) {
      updateFamilyMember(spouseIdToUse, { spouseId: newMemberId });
    }

    showToast(
      `🎉 "${formData.name}" berhasil dibuat & relasi otomatis 2-arah tersambung!`
    );

    if (onSuccessAdded) {
      onSuccessAdded(finalNewMember);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-3xl max-h-[92vh] flex flex-col rounded-3xl bg-stone-900 border-2 border-amber-600/40 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-stone-950 border-b border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-stone-100 flex items-center gap-2">
                <span>+ Tambah Silsilah dari Catatan</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-600/50 text-emerald-300">
                  Relasi 2-Arah Otomatis
                </span>
              </h3>
              <p className="text-xs text-stone-400">
                Ketik atau tempel paragraf narasi bebas. Sistem akan mengekstrak tokoh & menghubungkan silsilah.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-stone-200">
          {/* Note Input Box */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" />
                Catatan Narasi Silsilah:
              </label>
              <button
                type="button"
                onClick={() => handleParse(rawNote)}
                disabled={!rawNote.trim()}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-stone-950 text-xs font-bold shadow transition-all cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>⚡ Ekstraksi Otomatis</span>
              </button>
            </div>

            <textarea
              rows={3}
              value={rawNote}
              onChange={(e) => setRawNote(e.target.value)}
              placeholder="Contoh: 'Abel adalah anak Adam dan Hawa. Lahir pada tahun 3950 SM dan meninggal 3900 SM...'"
              className="w-full p-3.5 rounded-2xl bg-stone-950 border border-stone-700 text-stone-100 text-sm focus:border-amber-500 focus:outline-none leading-relaxed"
            />

            {/* Quick Example Buttons */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] text-stone-400 flex items-center gap-1 mr-1">
                <HelpCircle className="w-3 h-3" /> Coba Contoh Cepat:
              </span>
              {NOTE_EXAMPLES.map((ex, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleApplyExample(ex.text)}
                  className="px-2.5 py-1 rounded-lg bg-stone-850 hover:bg-stone-800 border border-stone-700 text-[11px] text-amber-300 transition-colors"
                >
                  {ex.title}
                </button>
              ))}
            </div>
          </div>

          {/* Extracted Candidates Review Form (Editable) */}
          {isParsed && (
            <div className="p-4 sm:p-5 rounded-2xl bg-stone-950/80 border-2 border-amber-600/30 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                    Hasil Ekstraksi & Pratinjau Relasi Silsilah
                  </span>
                </div>
                <span className="text-[11px] text-stone-400">
                  Periksa dan ubah field bila diperlukan sebelum disimpan
                </span>
              </div>

              {/* Form Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Nama */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                    Nama Tokoh: *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs font-bold focus:border-amber-500 focus:outline-none"
                  />
                </div>

                {/* Gelar / Peran */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                    Gelar / Peran:
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Contoh: Gembala Saleh, Putra Sulung"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>

                {/* Gender & Generasi */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                      Jenis Kelamin:
                    </label>
                    <select
                      value={formData.gender}
                      onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                      className="w-full px-2.5 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                    >
                      <option value="Laki-laki">Laki-laki</option>
                      <option value="Perempuan">Perempuan</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                      Generasi:
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={formData.generation}
                      onChange={(e) => setFormData({ ...formData, generation: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Tahun Lahir & Wafat */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                      Tahun Lahir:
                    </label>
                    <input
                      type="text"
                      value={formData.birthYear}
                      onChange={(e) => setFormData({ ...formData, birthYear: e.target.value })}
                      placeholder="e.g. 3950 SM"
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                      Tahun Wafat:
                    </label>
                    <input
                      type="text"
                      value={formData.deathYear}
                      onChange={(e) => setFormData({ ...formData, deathYear: e.target.value })}
                      placeholder="Kosongkan jika masih hidup"
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Ayah (Relasi Otomatis) */}
                <div>
                  <label className="block text-[11px] font-semibold text-amber-300 mb-1 flex items-center justify-between">
                    <span>Ayah (Relasi 2-Arah):</span>
                    <span className="text-[10px] text-stone-400 font-normal">Pilih / Masukkan Nama</span>
                  </label>
                  <input
                    type="text"
                    value={formData.fatherNameOrId}
                    onChange={(e) => setFormData({ ...formData, fatherNameOrId: e.target.value })}
                    placeholder="Nama Ayah (akan dihubungkan timbal-balik)"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-amber-600/40 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  />
                  {formData.fatherNameOrId && (
                    <span className="text-[10px] text-amber-400/90 mt-1 block">
                      🔗 {formData.fatherNameOrId} ➔ Anak: {formData.name} & {formData.name} ➔ Ayah: {formData.fatherNameOrId}
                    </span>
                  )}
                </div>

                {/* Ibu (Relasi Otomatis) */}
                <div>
                  <label className="block text-[11px] font-semibold text-pink-300 mb-1 flex items-center justify-between">
                    <span>Ibu (Relasi 2-Arah):</span>
                    <span className="text-[10px] text-stone-400 font-normal">Pilih / Masukkan Nama</span>
                  </label>
                  <input
                    type="text"
                    value={formData.motherNameOrId}
                    onChange={(e) => setFormData({ ...formData, motherNameOrId: e.target.value })}
                    placeholder="Nama Ibu (akan dihubungkan timbal-balik)"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-pink-600/40 text-stone-100 text-xs focus:border-pink-500 focus:outline-none"
                  />
                </div>

                {/* Pasangan */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                    Pasangan:
                  </label>
                  <input
                    type="text"
                    value={formData.spouseNameOrId}
                    onChange={(e) => setFormData({ ...formData, spouseNameOrId: e.target.value })}
                    placeholder="Nama Istri / Suami"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>

                {/* Anak-anak */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                    Anak-anak (Pisahkan dengan koma):
                  </label>
                  <input
                    type="text"
                    value={formData.childrenNamesStr}
                    onChange={(e) => setFormData({ ...formData, childrenNamesStr: e.target.value })}
                    placeholder="e.g. Hanok, Palu, Hezron, Karmi"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>

                {/* Tempat Lahir */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                    Tempat Lahir / Tinggal:
                  </label>
                  <input
                    type="text"
                    value={formData.birthPlace}
                    onChange={(e) => setFormData({ ...formData, birthPlace: e.target.value })}
                    placeholder="e.g. Mesopotamia, Kanaan, Yogyakarta"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>

                {/* Sumber */}
                <div>
                  <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                    Sumber / Rujukan Naskah:
                  </label>
                  <input
                    type="text"
                    value={formData.sources}
                    onChange={(e) => setFormData({ ...formData, sources: e.target.value })}
                    placeholder="e.g. Kitab Kejadian, Naskah Keraton, Arsip Akta"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Biografi / Catatan Sejarah */}
              <div>
                <label className="block text-[11px] font-semibold text-stone-300 mb-1">
                  Biografi / Catatan Sejarah:
                </label>
                <textarea
                  rows={2}
                  value={formData.biography}
                  onChange={(e) => setFormData({ ...formData, biography: e.target.value })}
                  className="w-full p-2.5 rounded-xl bg-stone-900 border border-stone-700 text-stone-100 text-xs focus:border-amber-500 focus:outline-none leading-relaxed"
                />
              </div>

              {/* Save Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={handleCommit}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-stone-950 font-bold text-xs shadow-xl transition-all active:scale-95 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Simpan ke Database Silsilah</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-950 border-t border-stone-800 flex items-center justify-between">
          <span className="text-[11px] text-stone-400">
            Total Anggota Saat Ini: {familyMembers.length} Tokoh
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
