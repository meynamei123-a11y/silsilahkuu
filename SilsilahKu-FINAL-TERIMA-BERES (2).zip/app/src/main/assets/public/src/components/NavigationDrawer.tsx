import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { X, ChevronDown, ChevronRight, Eye, Globe, Lock, Check, FolderArchive, Download, Settings } from 'lucide-react';
import { LANGUAGES } from '../utils/i18n';
import { LanguageCode } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

export const NavigationDrawer: React.FC = () => {
  const {
    isMenuOpen,
    closeMenu,
    navigateToPage,
    openRootApkModal,
    openNoteImportModal,
    openBasicFontModal,
    openBasicThemeModal,
    openBasicWallpaperModal,
    openMainSettingsModal,
    rootConfig,
    setLanguage,
    appMode,
    toggleAppMode,
    isAppLocked,
    lockNow,
    showToast,
    t,
  } = useApp();

  // Accordion open states
  const [openSection, setOpenSection] = useState<string | null>(null);

  // Local state for selecting language inside drawer before clicking Simpan
  const [tempLanguage, setTempLanguage] = useState<LanguageCode>(rootConfig.language || 'id');

  useEffect(() => {
    if (isMenuOpen) {
      setTempLanguage(rootConfig.language || 'id');
    }
  }, [isMenuOpen, rootConfig.language]);

  const toggleSection = (section: string) => {
    setOpenSection((prev) => (prev === section ? null : section));
  };

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMenuOpen) {
        closeMenu();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMenuOpen, closeMenu]);

  if (!isMenuOpen) return null;

  const handleSelectPage = (pageId: string) => {
    navigateToPage(pageId);
    closeMenu();
  };

  const handleSaveLanguage = () => {
    setLanguage(tempLanguage);
    const langObj = LANGUAGES.find((l) => l.code === tempLanguage);
    showToast(`✅ ${t('languageSaved')}: ${langObj?.nativeName || tempLanguage}`);
  };

  const handleOpenRootApk = () => {
    closeMenu();
    openRootApkModal('visual_editor');
  };

  const handleDownloadZip = async (e: React.MouseEvent) => {
    e.preventDefault();
    closeMenu();
    showToast('⏳ Memulai pengunduhan SilsilahKu-Final-Source.zip...');
    try {
      const response = await fetch('/SilsilahKu-Final-Source.zip', { headers: { 'Cache-Control': 'no-cache' } });
      if (!response.ok) throw new Error('Download failed');
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const tempLink = document.createElement('a');
      tempLink.style.display = 'none';
      tempLink.href = blobUrl;
      tempLink.setAttribute('download', 'SilsilahKu-Final-Source.zip');
      document.body.appendChild(tempLink);
      tempLink.click();
      setTimeout(() => {
        document.body.removeChild(tempLink);
        window.URL.revokeObjectURL(blobUrl);
      }, 500);
      showToast('✅ File SilsilahKu-Final-Source.zip berhasil diunduh!');
    } catch {
      window.location.href = '/SilsilahKu-Final-Source.zip';
    }
  };

  const currentLangObj = LANGUAGES.find((l) => l.code === (rootConfig.language || 'id')) || LANGUAGES[0];

  return (
    <div className="fixed inset-0 z-50 flex" role="dialog" aria-modal="true" aria-label="Menu Navigasi">
      {/* Minimal Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-xs transition-opacity animate-in fade-in duration-150"
        onClick={closeMenu}
        aria-hidden="true"
      />

      {/* Minimal Drawer Container */}
      <div className="relative w-64 sm:w-72 bg-stone-900 text-stone-100 flex flex-col h-full shadow-2xl border-r border-stone-800/80 animate-in slide-in-from-left duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-800 bg-stone-950/90">
          <span className="text-sm font-extrabold tracking-tight text-amber-400">
            {rootConfig.appTitle}
          </span>
          <button
            onClick={closeMenu}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition-colors cursor-pointer"
            title={t('close')}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Minimal Expandable Text List */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1 text-sm font-semibold">
          {/* PWA Mobile Install Banner */}
          <PWAInstallButton variant="drawer" />

          {/* 1. Bahasa (Directly in Menu ☰ as required) */}
          <div>
            <button
              type="button"
              onClick={() => toggleSection('bahasa')}
              className="w-full text-left px-3 py-2 rounded-lg text-stone-200 hover:text-amber-300 hover:bg-stone-800/60 transition-colors cursor-pointer flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{t('language')}</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-amber-400/80">
                <span className="text-[11px] font-mono">{currentLangObj.nativeName}</span>
                {openSection === 'bahasa' ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              </div>
            </button>

            {openSection === 'bahasa' && (
              <div className="ml-3 pl-2 border-l border-stone-800 space-y-1.5 my-1.5 animate-in fade-in duration-150">
                <div className="space-y-1">
                  {LANGUAGES.map((lang) => {
                    const isSelected = tempLanguage === lang.code;
                    return (
                      <button
                        key={lang.code}
                        type="button"
                        onClick={() => setTempLanguage(lang.code)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center justify-between ${
                          isSelected
                            ? 'bg-amber-950/60 text-amber-300 font-bold border border-amber-500/50'
                            : 'text-stone-300 hover:text-white hover:bg-stone-800/50'
                        }`}
                      >
                        <div>
                          <span className="block">{lang.nativeName}</span>
                          <span className="block text-[9px] text-stone-500 font-normal">{lang.name}</span>
                        </div>
                        {isSelected && <Check className="w-3.5 h-3.5 text-amber-400" />}
                      </button>
                    );
                  })}
                </div>

                {/* Explicit Simpan Button for Language Selection as requested */}
                <button
                  type="button"
                  onClick={handleSaveLanguage}
                  className="w-full py-1.5 px-3 mt-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs cursor-pointer shadow transition-all active:scale-95 flex items-center justify-center gap-1"
                >
                  <span>{t('save')}</span>
                </button>
              </div>
            )}
          </div>

          {/* 2. Silsilah (Expandable Accordion) */}
          <div>
            <button
              type="button"
              onClick={() => toggleSection('silsilah')}
              className="w-full text-left px-3 py-2 rounded-lg text-stone-200 hover:text-amber-300 hover:bg-stone-800/60 transition-colors cursor-pointer flex items-center justify-between"
            >
              <span>{t('genealogy')}</span>
              {openSection === 'silsilah' ? <ChevronDown className="w-3.5 h-3.5 text-stone-400" /> : <ChevronRight className="w-3.5 h-3.5 text-stone-400" />}
            </button>

            {openSection === 'silsilah' && (
              <div className="ml-4 pl-2 border-l border-stone-800 space-y-0.5 my-1 animate-in fade-in duration-150">
                <button
                  type="button"
                  onClick={() => handleSelectPage('page_genealogy')}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('genealogy')}
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectPage('page_family_tree')}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('familyTree')}
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectPage('page_ancestry')}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('ancestry')}
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectPage('page_lineage')}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('lineage')}
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectPage('page_family_data')}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('familyData')}
                </button>
              </div>
            )}
          </div>

          {/* 3. Pengaturan (Expandable Accordion) */}
          <div>
            <button
              type="button"
              onClick={() => toggleSection('pengaturan')}
              className="w-full text-left px-3 py-2 rounded-lg text-stone-200 hover:text-amber-300 hover:bg-stone-800/60 transition-colors cursor-pointer flex items-center justify-between"
            >
              <span>{t('settings')}</span>
              {openSection === 'pengaturan' ? <ChevronDown className="w-3.5 h-3.5 text-stone-400" /> : <ChevronRight className="w-3.5 h-3.5 text-stone-400" />}
            </button>

            {openSection === 'pengaturan' && (
              <div className="ml-4 pl-2 border-l border-stone-800 space-y-0.5 my-1 animate-in fade-in duration-150">
                <button
                  type="button"
                  onClick={() => handleSelectPage('page_profile')}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('profile')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    openBasicThemeModal();
                  }}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('display')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    openBasicFontModal();
                  }}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('fontAndText')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    openBasicThemeModal();
                  }}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('colorAndTheme')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    openBasicWallpaperModal();
                  }}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer"
                >
                  {t('wallpaper')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    openRootApkModal('kunci_aplikasi');
                  }}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-300 hover:text-amber-300 hover:bg-stone-800/50 cursor-pointer flex items-center justify-between"
                >
                  <span>{t('appLock')}</span>
                  <span className="text-[10px] font-mono">{rootConfig.appLock?.isEnabled ? '🔒' : '🔓'}</span>
                </button>

                {/* ⭐ SATU ZIP PROJECT LENGKAP inside Pengaturan */}
                <a
                  href="/SilsilahKu-Capacitor-Android-FullProject.zip"
                  download="SilsilahKu-Capacitor-Android-FullProject.zip"
                  onClick={() => showToast('Mengunduh SATU ZIP PROJECT LENGKAP...')}
                  className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-black text-amber-200 bg-gradient-to-r from-amber-600/50 to-amber-700/50 hover:from-amber-600/70 hover:to-amber-700/70 border-2 border-amber-400 cursor-pointer flex items-center justify-between transition-all my-1.5 shadow"
                >
                  <div className="flex items-center gap-2">
                    <FolderArchive className="w-4 h-4 text-amber-300 shrink-0" />
                    <div>
                      <span className="block font-black text-amber-200">⭐ SATU ZIP MASTER</span>
                      <span className="block text-[9px] text-amber-300/80 font-mono">Capacitor Full Project</span>
                    </div>
                  </div>
                  <Download className="w-4 h-4 text-amber-300" />
                </a>

                {/* 📱 Unduh ZIP Siap Jadi APK inside Pengaturan */}
                <a
                  href="/SilsilahKu-App-Ready.zip"
                  download="SilsilahKu-App-Ready.zip"
                  onClick={() => showToast('Mengunduh SilsilahKu-App-Ready.zip...')}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs font-bold text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/40 cursor-pointer flex items-center justify-between transition-colors my-1"
                >
                  <div className="flex items-center gap-1.5">
                    <Download className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>📱 Web App Build (dist)</span>
                  </div>
                  <Download className="w-3 h-3 text-emerald-400" />
                </a>

                {/* 📦 Unduh Source Project ZIP inside Pengaturan */}
                <a
                  href="/SilsilahKu-Final-Source.zip"
                  download="SilsilahKu-Final-Source.zip"
                  onClick={handleDownloadZip}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs font-medium text-stone-300 bg-stone-900/60 hover:bg-stone-800 border border-stone-700/40 cursor-pointer flex items-center justify-between transition-colors my-1"
                >
                  <div className="flex items-center gap-1.5">
                    <FolderArchive className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                    <span>📦 Source Code</span>
                  </div>
                  <Download className="w-3 h-3 text-stone-400" />
                </a>

                {/* Buka Pengaturan Lengkap */}
                <button
                  type="button"
                  onClick={() => {
                    closeMenu();
                    openMainSettingsModal();
                  }}
                  className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-stone-400 hover:text-stone-200 cursor-pointer flex items-center gap-1.5"
                >
                  <Settings className="w-3 h-3 text-stone-400" />
                  <span>Semua Pengaturan...</span>
                </button>
              </div>
            )}
          </div>

          {/* 4. Tambah dari Catatan */}
          <button
            type="button"
            onClick={() => {
              closeMenu();
              openNoteImportModal();
            }}
            className="w-full text-left px-3 py-2 rounded-lg text-stone-200 hover:text-amber-300 hover:bg-stone-800/60 transition-colors cursor-pointer"
          >
            {t('noteImport')}
          </button>

          {/* 5. Mode Editor / Preview Toggle with Eye Icon 👁️ */}
          <button
            type="button"
            onClick={() => {
              toggleAppMode();
            }}
            className={`w-full text-left px-3 py-2 rounded-lg transition-colors cursor-pointer flex items-center justify-between ${
              appMode === 'editor'
                ? 'bg-amber-950/60 text-amber-300 border border-amber-500/40'
                : 'text-stone-300 hover:text-white hover:bg-stone-800/60'
            }`}
          >
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{appMode === 'editor' ? t('editorMode') + ' (ON)' : t('preview')}</span>
            </div>
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-stone-800 text-amber-300 font-mono">
              {appMode === 'editor' ? 'EDIT' : 'VIEW'}
            </span>
          </button>

          <div className="my-2 border-t border-stone-800/80" />

          {/* 6. Special Advanced Item: Pengaturan Root APK (Single red highlighted column/row) */}
          <button
            type="button"
            onClick={handleOpenRootApk}
            className="w-full text-left px-3 py-2 rounded-lg bg-rose-950/50 hover:bg-rose-900/70 text-rose-300 hover:text-rose-100 border border-rose-800/60 transition-colors cursor-pointer flex items-center justify-between"
          >
            <span className="font-bold">{t('rootSettings')}</span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800/80">
              {isAppLocked ? '🔒' : '⚙'}
            </span>
          </button>

          {!isAppLocked && rootConfig.appLock?.isEnabled && (
            <button
              type="button"
              onClick={lockNow}
              className="w-full text-left px-3 py-1.5 rounded-lg text-xs font-semibold text-stone-400 hover:text-stone-200 transition-colors cursor-pointer mt-1"
            >
              🔒 {t('locked')}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
