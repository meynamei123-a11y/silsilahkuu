#!/bin/bash
# ==============================================================================
# SilsilahKu - Android APK Build Automation Script
# Package: com.silsilahku.app | Version: 1.0.0
# ==============================================================================

set -e

echo "========================================================"
echo "  🌳 SilsilahKu - Memulai Build Android APK Standalone"
echo "========================================================"

echo "[1/4] Menginstal dependensi project..."
npm install

echo "[2/4] Melakukan build production web bundle..."
npm run build

echo "[3/4] Menyiapkan struktur distribusi Android (dist)..."
node scripts/package-dist.js

echo "[4/4] Mengemas seluruh source code ke dalam archive master..."
npm run package:zip

echo "========================================================"
echo "  ✅ Build Berhasil Disiapkan!"
echo "  - Web App Bundle: ./dist"
echo "  - App Ready ZIP: ./public/SilsilahKu-App-Ready.zip"
echo "  - Master Source ZIP: ./public/SilsilahKu-Final-Source.zip"
echo "========================================================"
