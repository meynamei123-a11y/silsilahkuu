# SilsilahKu - Android APK Project Specification

## 📱 Ringkasan Identitas Aplikasi
- **Nama Aplikasi (App Name)**: SilsilahKu
- **Package ID / Application ID**: `com.silsilahku.app`
- **Versi Aplikasi (Version)**: `1.0.0` (Version Code: `1`)
- **Tipe Aplikasi**: Standalone Single Page Application (SPA / React 19 + TypeScript + Vite + Tailwind CSS)
- **Minimum Android SDK**: Android 5.0 (API Level 21 / 22)
- **Target Android SDK**: Android 14 (API Level 34)
- **Orientasi Layar**: Portrait
- **Tema Status Bar / Background**: `#0c0a09` (Dark Heritage Parchment & Gold)

---

## 🔒 Izin Android (Android Permissions)
- `android.permission.INTERNET` (Untuk sinkronisasi dan font online)
- `android.permission.ACCESS_NETWORK_STATE` (Untuk deteksi mode offline)
- `android.permission.READ_MEDIA_IMAGES` (Untuk memilih foto profil keluarga dari galeri HP)
- `android.permission.READ_EXTERNAL_STORAGE` (Kompatibilitas Android lawas)
- `android.permission.WRITE_EXTERNAL_STORAGE` (Ekspor/unduh silsilah data keluarga)

---

## 📁 Struktur File Project
```
/
├── android/
│   └── app/src/main/AndroidManifest.xml
├── public/
│   ├── icon.svg
│   ├── pwa-192x192.png
│   ├── pwa-512x512.png
│   ├── pwa-maskable-512x512.png
│   ├── apple-touch-icon.png
│   ├── SilsilahKu-App-Ready.zip
│   └── SilsilahKu-Final-Source.zip
├── src/
│   ├── assets/
│   ├── components/
│   ├── context/
│   ├── data/
│   ├── utils/
│   ├── views/
│   ├── App.tsx
│   ├── index.css
│   ├── main.tsx
│   └── types.ts
├── capacitor.config.json
├── config.xml
├── build-apk.sh
├── BUILD-APK.bat
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```
