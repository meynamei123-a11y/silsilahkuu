@echo off
REM ==============================================================================
REM SilsilahKu - Android APK Build Automation Script for Windows
REM Package: com.silsilahku.app | Version: 1.0.0
REM ==============================================================================

echo ========================================================
echo   SilsilahKu - Memulai Build Android APK Standalone
echo ========================================================

echo [1/4] Menginstal dependensi project...
call npm install

echo [2/4] Melakukan build production web bundle...
call npm run build

echo [3/4] Menyiapkan struktur distribusi Android (dist)...
call node scripts/package-dist.js

echo [4/4] Mengemas seluruh source code ke dalam archive master...
call npm run package:zip

echo ========================================================
echo   Build Berhasil Disiapkan!
echo   - Web App Bundle: ./dist
echo   - App Ready ZIP: ./public/SilsilahKu-App-Ready.zip
echo   - Master Source ZIP: ./public/SilsilahKu-Final-Source.zip
echo ========================================================
pause
